#!/usr/bin/env python3
"""
Recompute the paper's analyses (findings.json "paper") from a frozen snapshot, without full texts, content vectors or network
access, and compare the result with the frozen report value by value.

  python scripts/recompute_paper.py --snapshot <snapshot folder>       (run from anywhere; needs numpy)
The snapshot's paper-inputs/ hold the analysed works in analysis order with the fields the analyses read, the research lines
and algorithmic clusters, benchmark relations, the model-assisted labels and readings as produced, the citations whose intent
was read, and the repository records (see paper_snapshot.py in the platform repository).
"""
import argparse
import datetime as dt
import json
import os
import sys
from collections import Counter


class FrozenUniverse:
    """The part of build_findings.Universe that paper_analysis reads, rebuilt from paper-inputs/works.jsonl"""

    def __init__(self, folder):
        rows = [json.loads(l) for l in open(os.path.join(folder, "works.jsonl"), encoding="utf-8")]
        meta = json.load(open(os.path.join(folder, "lines.json"), encoding="utf-8"))
        self.ids = [r["id"] for r in rows]
        self.n = len(self.ids)
        self.pos = {pid: i for i, pid in enumerate(self.ids)}
        self.title = [r["title"] for r in rows]
        self.date = [dt.date.fromisoformat(r["date"]) if r["date"] else None for r in rows]
        self.prec = [r["prec"] for r in rows]
        self.year = [r["year"] for r in rows]
        self.cites = [r["cites"] for r in rows]
        self.byid = {r["id"]: {"authors": r["authors"]} for r in rows}
        self.ptopics = [r["lines"] for r in rows]
        self.topics = meta["lines"]
        self.asof = dt.date.fromisoformat(meta["asOf"])
        # only the matched phrases of title and abstract are kept; the text rules give the same answers on them
        self.s2 = [{"abstract": r["text"]} for r in rows]
        self.refs = [set() for _ in range(self.n)]
        for i, r in enumerate(rows):
            for pid in r["refs"]:
                j = self.pos.get(pid)
                if j is not None and j != i:
                    self.refs[i].add(j)
        self.cited_by = [set() for _ in range(self.n)]
        for i in range(self.n):
            for j in self.refs[i]:
                self.cited_by[j].add(i)
        self.links = [(i, j) for i in range(self.n) for j in self.refs[i]]
        self.sm_map = list(range(self.n))
        self.threads = [{"id": t["id"], "label": t["label"], "topic": t["topic"], "members": [self.pos[p] for p in t["members"] if p in self.pos]}
                        for t in meta["clusters"]]
        # reference lists as the inheritance analysis reads them: classic titles up to its cut-off year, other years only
        self.works = {}
        for r in rows:
            years = Counter(r["refYears"])
            refs = []
            for c in r["classicRefs"]:
                refs.append({"title": c["title"], "year": c["year"]})
                years[c["year"]] -= 1
            for y, k in years.items():
                refs += [{"year": y}] * max(0, k)
            self.works[r["id"]] = {"references": refs}


def load_labels(path):
    out = {}
    for l in open(path, encoding="utf-8"):
        r = json.loads(l)
        if r.get("labels"):
            out[r["id"]] = r["labels"]
    return out


def diff(a, b, path="", out=None, limit=40):
    out = [] if out is None else out
    if len(out) >= limit:
        return out
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b), key=str):
            diff(a.get(k), b.get(k), f"{path}.{k}", out, limit)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(f"{path}: length {len(a)} != {len(b)}")
        for k, (x, y) in enumerate(zip(a, b)):
            diff(x, y, f"{path}[{k}]", out, limit)
    elif isinstance(a, float) and isinstance(b, (int, float)) or isinstance(b, float) and isinstance(a, (int, float)):
        if abs(a - b) > 1e-9:
            out.append(f"{path}: {a} != {b}")
    elif a != b:
        out.append(f"{path}: {str(a)[:80]} != {str(b)[:80]}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshot", required=True)
    a = ap.parse_args()
    snap = os.path.abspath(a.snapshot)
    sys.path.insert(0, os.path.join(snap, "scripts"))
    import paper_analysis as pa
    import protocol_analysis as pr
    import cites_analysis as ci
    pin = os.path.join(snap, "paper-inputs")
    lab = os.path.join(pin, "labels")
    U = FrozenUniverse(pin)
    facets = {U.pos[k]: v for k, v in load_labels(os.path.join(lab, "facets.jsonl")).items() if k in U.pos and v.get("role_primary")}
    axes = {U.pos[k]: v for k, v in load_labels(os.path.join(lab, "axes.jsonl")).items() if k in U.pos}
    ppath = os.path.join(lab, "protocol.jsonl")
    both = {**pr._load(ppath), **pr._load(os.path.join(lab, "protocol_older.jsonl"))}
    prot = pr._filled(pr._judgecheck(pr._adaptive(both, ppath), ppath), os.path.join(lab, "fill_v1.jsonl"))
    chains = pr._load(os.path.join(lab, "chains_v2.jsonl"))
    items = {json.loads(l)["id"]: json.loads(l) for l in open(os.path.join(pin, "citations.jsonl"), encoding="utf-8")}
    labels = {**ci._load(os.path.join(lab, "cites_first.jsonl")), **ci._load(os.path.join(lab, "cites_verify_flag.jsonl")), **ci._load(os.path.join(lab, "cites_verify_bg.jsonl"))}
    names = {n: U.pos[pid] for n, pid in json.load(open(os.path.join(pin, "benchmarks.json"), encoding="utf-8")).items() if pid in U.pos}
    routes = {}
    for l in open(os.path.join(pin, "benchmark-routes.jsonl"), encoding="utf-8"):
        r = json.loads(l)
        if r["from"] in U.pos and r["to"] in U.pos:
            routes[(U.pos[r["from"]], U.pos[r["to"]])] = {"kind": r["kind"], "evidence": r["sentence"], "name": r["name"]}
    inherit = {}
    for l in open(os.path.join(lab, "inherit_v1.jsonl"), encoding="utf-8"):
        r = json.loads(l)
        if r.get("labels"):
            inherit[r["id"]] = {**r["labels"], "family": r.get("family")}
    findings = json.load(open(os.path.join(snap, "findings.json"), encoding="utf-8"))
    rep = os.path.join(pin, "repositories")
    got = pa.paper_section(U, routes, names, facets, axes, prot, chains, items, labels, U.works, json.load(open(os.path.join(rep, "oss.json"), encoding="utf-8")),
                           os.path.join(rep, "meta.jsonl"), findings, novelty=load_labels(os.path.join(lab, "novelty_v1.jsonl")),
                           bounds=load_labels(os.path.join(lab, "boundary_v1.jsonl")), inherit=inherit, upkeep=os.path.join(rep, "upkeep_v1.jsonl"))
    got.pop("_records", None)
    got = json.loads(json.dumps(got, default=str))
    d = diff(findings["paper"], got)
    print(json.dumps({"compared": "findings.json paper", "differences": len(d), "first": d[:20]}, ensure_ascii=False, indent=1))
    sys.exit(1 if d else 0)


if __name__ == "__main__":
    main()
