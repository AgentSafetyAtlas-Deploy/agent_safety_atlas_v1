#!/usr/bin/env python3
"""
Observation report: measured evidence for the paper's four fractures and research questions RQ1-RQ4 (outline v0.4).

Every figure is computed from the current snapshot (release in meta) with one fixed procedure, so the next snapshot can
be compared with this one. Figures are preliminary observations, not tested results: hypothesis rows carry a status
(supported so far / not supported / mixed / not testable yet) and the reason.

Inputs
  dist/data/atlas.json, topic-taxonomy.json, insights.json (ROR institutions), oss.json (repository stars), updates.json
  research-paths/citation-graph/works.jsonl     Semantic Scholar records and reference lists (collect_citation_graph.py)
  research-paths/starmap/embeddings.npy (+ids) SPECTER2 vectors (embed_specter2.py); starmap.json candidate clusters
  ../../intake/screening/fulltext/*.txt.gz      cached full texts, read locally (nothing is sent anywhere)

Relations used ("routes"; a route is only ever an observed relation, never layout proximity)
  cites          A's Semantic Scholar reference list contains B (both in the Atlas)
  benchmark use  A's full text (before the reference list) names benchmark B (an Atlas benchmark-form work whose title
                 starts with a distinctive name, e.g. "AgentDojo:") in a sentence where the authors speak in the first
                 person about evaluating/testing/adopting, or that reports results on B (table captions); negated
                 sentences ("rather than", "unlike") and sentences that open with the name (descriptions of B) do not
                 count. The sentence is kept as evidence. Name matching is exact and case-sensitive; works dated more
                 than a month before the benchmark are ignored (name collisions). Precision is spot-checked (audit).
  mention        the same name appears, but no sentence qualifies (related work, comparison tables)

Clusters are the 19 editorial topics (星团), galaxies the 8 theme groups (星系); a work can sit in several clusters.
Candidate clusters are the automatic threads of the star map (HDBSCAN on SPECTER2 vectors), labelled as candidates.

Two kinds of output, updated on different clocks (2026-10-16, see analysis-releases/README.md):
  per-work navigation data, with every data release (run_update.py):
    python build_findings.py --data-only
    -> dist/data/starmap-bands.json, facets.json, starmap-ctx-<n>.json (citing sentences); benchmark-routes.jsonl
  the observation report, as an analysis version (monthly candidate, published after the owner's approval):
    python build_findings.py --analysis-version A2 --out analysis-releases/A2/findings.json   (release_analysis.py)
    -> findings.json labelled with its analysis version; per-work data files are left as they are
  (needs numpy and scipy: run with the papersearch environment)
"""
import ast
import datetime as dt
import glob
import gzip
import hashlib
import json
import math
import os
import random
import re
import shutil
import sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:] = [p for p in sys.path if os.path.abspath(p or ".") != HERE]  # platform/coverage.py shadows the coverage package
import numpy as np  # noqa: E402
from scipy.stats import kendalltau, spearmanr  # noqa: E402

DATA = os.path.join(HERE, "dist", "data")
SM = os.path.join(HERE, "research-paths", "starmap")
CG = os.path.join(HERE, "research-paths", "citation-graph")
FULLTEXT = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "fulltext"))
ROR_CACHE = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "meta", "ror_cache.jsonl"))
NOVA_MONTHS = 6          # "new star" window tau (proposed; see the report's open definitions)
MIN_GROUP = 8            # smallest reference group g(p) before falling back to a coarser one
MIN_USERS = 8            # works with benchmark use needed on each side before the shared-benchmark layer is read
SEED = 20261011

FIRST_PERSON_USE = re.compile(
    r"\b(we|our)\b[^.;]{0,160}?\b(evaluat\w*|test\w*|experiment\w*|use[ds]?|using|adopt\w*|benchmark\w*|run|ran|report\w*|"
    r"measur\w*|conduct\w*|select\w*|follow\w*|employ\w*|train\w*|construct\w*|build\w*|built|sampl\w*|extend\w*|"
    r"compar\w*|validat\w*|consider\w*|draw\w*|derive\w*|deriv\w*)\b", re.I)
OWN_NEW = re.compile(r"\b(?:new|novel)\s+(?:\w+\s+)?benchmark", re.I)  # "we release a new benchmark (suite)": the authors' own resource
# a result reported for another work ("Glazunov and Brand (2024) improved performance on X", "Smith et al. report ...")
OTHERS_RESULT = re.compile(r"\bet al\.?|\b[A-Z][\w\-]+ (?:and|&) [A-Z][\w\-]+,? \(?(?:19|20)\d\d|\b[A-Z][\w\-]+,? \((?:19|20)\d\d\)")
NEGATED = re.compile(r"\b(rather than|instead of|unlike|in contrast|beyond|do not|does not|did not|without|not use|cannot)\b", re.I)
RESULT_ON = r"\b(results?|performance|accuracy|ASR|attack success rates?|utility|evaluations?|scores?|experiments?|tested|evaluated)\s+(on|in|across|using|with)\s+(the\s+)?([\w\-]+\s+){0,2}"


def use_cue(sentence, name):
    """A sentence counts as use when the authors speak in the first person about evaluating, testing, adopting ... (and
    the sentence is not negated), or when it reports results/performance on the named benchmark (table captions) without
    attributing them to another work (rules revised 2026-10-22 after an outside check found two such misreadings)."""
    if NEGATED.search(sentence):
        return False
    if re.match(r"\s*" + re.escape(name) + r"\b", sentence):   # "AgentDojo [6] introduces ..." describes the benchmark itself
        return False
    # first person, unless the verb sits in a relative clause about something else ("... CyberSecEval 3, which extends X")
    for m in FIRST_PERSON_USE.finditer(sentence):
        span = m.group(0)
        if "which" in span.lower().split() or (m.group(2).lower().startswith("benchmark") and OWN_NEW.search(span)):
            continue
        return True
    m = re.search(RESULT_ON + re.escape(name) + r"(?![\w\-])", sentence, re.I)
    return bool(m) and not OTHERS_RESULT.search(sentence[:m.start()])


EMAIL = re.compile(r"[A-Za-z0-9._%+-]+(?:@|%40)[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
CJK = re.compile(r"[\u3400-\u9fff\uf900-\ufaff]")
REF_ENTRY = re.compile(r"\bet al\.?,?\s*\(?(19|20)\d\d|arXiv preprint|In Proceedings|abs/\d{4}\.\d{4,5}|Cited by:", re.I)
REFS_HEAD = re.compile(r"\n\s*(References|REFERENCES|Bibliography|BIBLIOGRAPHY)\s*\n")
TOKEN = re.compile(r"[A-Za-z0-9][\w\-\.\+]*")
NAME = re.compile(r"^\s*([A-Za-z][\w\-\.\+]{2,30}(?:\s[A-Z0-9][\w\-\+]{0,12})?)\s*:\s")
ATTACK = re.compile(r"\b(attack\w*|jailbreak\w*|exploit\w*|poison\w*|backdoor\w*|hijack\w*|trojan\w*|red[- ]team\w*|adversarial|"
                    r"compromis\w*|manipulat\w*|exfiltrat\w*|steal\w*|break\w*)\b", re.I)
DEFENSE = re.compile(r"\b(defen[cs]\w*|defend\w*|mitigat\w*|guard\w*|detect\w*|protect\w*|safeguard\w*|shield\w*|firewall\w*|"
                     r"secur(e|ing)|robustif\w*|sanitiz\w*|filter\w*|monitor\w*|prevent\w*|harden\w*|align\w*)\b", re.I)


# ---------------------------------------------------------------------------------------------------------------- utils
def load_json(name):
    return json.load(open(os.path.join(DATA, name), encoding="utf-8"))


def parse_date(s):
    """(date, precision) from 'YYYY-MM-DD', 'YYYY-MM' or 'YYYY'; month dates sit mid-month, year dates mid-year."""
    s = (s or "").strip()
    try:
        if len(s) >= 10:
            return dt.date.fromisoformat(s[:10]), "day"
        if len(s) == 7:
            return dt.date(int(s[:4]), int(s[5:7]), 15), "month"
        if len(s) == 4:
            return dt.date(int(s), 7, 1), "year"
    except ValueError:
        pass
    return None, None


ARXIV_ID = re.compile(r"^(\d{2})(\d{2})\.\d{4,5}$")
FIRST_V1 = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "arxiv_first", "first_v1.json"))
_V1 = None


def arxiv_v1(aid):
    """first-version date of an arXiv id (arxiv_first/fetch_first.py, arXiv API), or None"""
    global _V1
    if _V1 is None:
        _V1 = json.load(open(FIRST_V1, encoding="utf-8")) if os.path.exists(FIRST_V1) else {}
    return _V1.get(aid or "")


def first_public(rec):
    """(date, precision) of a work's first public version, the date every timing analysis uses (owner, 2026-10-22): the
    recorded date unless the arXiv record shows an earlier version, from its first submission or v1 date, else the month
    of its identifier. Curated works carry their proceedings date, so a benchmark posted as a preprint months before the
    proceedings would otherwise start its life late (InjecAgent: proceedings 2024-08, arXiv 2024-03)."""
    best = parse_date(rec.get("date") or rec.get("displayYear"))
    a = rec.get("attributes") or {}
    cands = []
    if a.get("arxiv_first_published_at"):
        cands.append(parse_date(str(a["arxiv_first_published_at"])[:10]))
    pv = a.get("preprint_versions")
    if isinstance(pv, str):
        try:
            pv = ast.literal_eval(pv)
        except (ValueError, SyntaxError):
            pv = None
    if isinstance(pv, dict) and pv.get("v1"):
        cands.append(parse_date(str(pv["v1"])[:10]))
    if arxiv_v1(a.get("arxiv_id")):
        cands.append(parse_date(arxiv_v1(a.get("arxiv_id"))))
    m = ARXIV_ID.match(a.get("arxiv_id") or "")
    if m and 1 <= int(m.group(2)) <= 12:
        cands.append((dt.date(2000 + int(m.group(1)), int(m.group(2)), 15), "month"))

    def earlier(c, r):
        (cd, cp), (rd, rp) = c, r
        if cd is None:
            return False
        if rd is None:
            return True
        if rp == "year":  # a dated version in the same year or before is more precise
            return cd.year <= rd.year and cp != "year"
        if rp == "month":
            return (cd.year, cd.month) < (rd.year, rd.month) or ((cd.year, cd.month) == (rd.year, rd.month) and cp == "day")
        return cd < rd if cp == "day" else (cd.year, cd.month) < (rd.year, rd.month)
    for c in sorted(cands, key=lambda c: c[1] != "day"):
        if earlier(c, best):
            best = c
    return best


def months(a, b):
    return (a - b).days / 30.4375


def quarter(d):
    return f"{d.year}Q{(d.month - 1) // 3 + 1}"


def pct(a, b, nd=1):
    return round(100 * a / b, nd) if b else None


def r3(x):
    return None if x is None or (isinstance(x, float) and math.isnan(x)) else round(float(x), 3)


def median(xs):
    xs = sorted(xs)
    return xs[len(xs) // 2] if xs else None


def wilson(k, n, z=1.96):
    if not n:
        return None, None
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return round(100 * (c - h), 1), round(100 * (c + h), 1)


# ---------------------------------------------------------------------------------------------------------------- load
def load():
    atlas, tax = load_json("atlas.json"), load_json("topic-taxonomy.json")
    ids = json.load(open(os.path.join(SM, "embedding-ids.json")))
    emb = np.load(os.path.join(SM, "embeddings.npy")).astype(np.float32)
    byid = {p["id"]: p for p in atlas["papers"]}
    works = {}
    for line in open(os.path.join(CG, "works.jsonl"), encoding="utf-8"):
        r = json.loads(line)
        works[r["id"]] = r
    return atlas, tax, ids, emb, byid, works


class Universe:
    """Arrays over the active works in star-map order, plus the observed relations between them."""

    def __init__(self):
        atlas, tax, ids, emb, byid, works = load()
        self.atlas, self.tax, self.ids, self.emb, self.byid = atlas, tax, ids, emb, byid
        self.n = n = len(ids)
        self.pos = {pid: i for i, pid in enumerate(ids)}
        cats = [c for c in tax["categories"] if not c.get("other")]
        self.themes = [{"id": c["id"], "en": c["en"], "color": c["color"], "topics": c["topics"]} for c in cats]
        self.topics = [t for c in cats for t in c["topics"]]
        self.tidx = {t: k for k, t in enumerate(self.topics)}
        self.theme_of_topic = [next(ci for ci, c in enumerate(cats) if t in c["topics"]) for t in self.topics]
        self.ptopics = [sorted({self.tidx[t] for t in tax["paperTopics"].get(pid, []) if t in self.tidx}) for pid in ids]
        self.pthemes = [sorted({self.theme_of_topic[k] for k in ts}) for ts in self.ptopics]
        self.form = [tax["paperForms"].get(pid) for pid in ids]
        self.title = [byid[pid].get("originalTitle") or byid[pid]["title"] for pid in ids]
        self.date, self.prec = [], []
        for pid in ids:
            d, pr = first_public(byid[pid])
            self.date.append(d)
            self.prec.append(pr)
        self.year = [d.year if d else None for d in self.date]
        self.asof = max(d for d, p in zip(self.date, self.prec) if d and p == "day")
        # Semantic Scholar
        self.s2 = [(works.get(pid) or {}).get("s2") or {} for pid in ids]
        self.cites = [s.get("citationCount") if isinstance(s.get("citationCount"), int) else None for s in self.s2]
        self.ref_listed = [bool((works.get(pid) or {}).get("references")) for pid in ids]
        s2pid, ax, doi = {}, {}, {}
        for i, pid in enumerate(ids):
            s = self.s2[i]
            if s.get("paperId"):
                s2pid[s["paperId"]] = i
            ext = s.get("externalIds") or {}
            if ext.get("ArXiv"):
                ax[ext["ArXiv"]] = i
            if ext.get("DOI"):
                doi[ext["DOI"].lower()] = i
            a = byid[pid]["attributes"]
            if a.get("arxiv_id"):
                ax.setdefault(a["arxiv_id"], i)
        self.refs = [set() for _ in range(n)]
        for i, pid in enumerate(ids):
            for ref in (works.get(pid) or {}).get("references") or []:
                j = s2pid.get(ref.get("paperId")) if ref.get("paperId") else None
                if j is None and ref.get("arxiv"):
                    j = ax.get(ref["arxiv"])
                if j is None and ref.get("doi"):
                    j = doi.get(ref["doi"])
                if j is not None and j != i:
                    self.refs[i].add(j)
        self.cited_by = [set() for _ in range(n)]
        for i in range(n):
            for j in self.refs[i]:
                self.cited_by[j].add(i)
        self.links = [(i, j) for i in range(n) for j in self.refs[i]]
        # institutions (ROR identities from the insights builder) and countries
        # wrong registry matches are corrected in the data (corrections.py); a team still carrying a rejected identity
        # is skipped only if some of its evidence is not on the reviewed "keep" list
        rejected = {}
        spec = os.path.join(HERE, "data-sources", "corrections", "ror-rejects.json")
        if os.path.exists(spec):
            for x in json.load(open(spec, encoding="utf-8"))["rejects"]:
                rejected[x["ror_id"]] = {re.sub(r"[^a-z0-9]+", "", k.lower()) for k in x.get("keep", [])}
        team_ror = {}
        for inst in load_json("insights.json")["institutions"]:
            for sid in inst.get("sourceIds") or []:
                team_ror[sid] = (inst["id"], inst["name"])

        def wrong(t):
            rid = (team_ror.get(t["id"]) or ("",))[0] or (t.get("registryIdentity") or {}).get("selected_ror_id")
            if rid not in rejected:
                return False
            labels = {re.sub(r"[^a-z0-9]+", "", ((e.get("sourceLabels") or [""])[0]).lower()) for e in t["evidence"]}
            return not labels <= rejected[rid]
        self.rejected_teams = {t["id"] for t in atlas["teams"] if wrong(t)}
        self.rejected_works = len({p for t in atlas["teams"] if t["id"] in self.rejected_teams for p in t["papers"]})
        self.corrections = atlas["meta"].get("corrections") or {}
        self.inst_name = {}
        self.pinst = [set() for _ in range(n)]
        self.pcountry = [set() for _ in range(n)]
        for t in atlas["teams"]:
            if t["id"] in self.rejected_teams:
                continue
            ror = team_ror.get(t["id"])
            for pid in t["papers"]:
                i = self.pos.get(pid)
                if i is None:
                    continue
                if ror:
                    self.pinst[i].add(ror[0])
                    self.inst_name[ror[0]] = ror[1]
                for loc in t.get("locations") or []:
                    if loc.get("countryCode"):
                        self.pcountry[i].add(loc["countryCode"])
        # repository stars of each work's own linked repositories
        self.stars = [0] * n
        self.has_repo = [False] * n
        for r in load_json("oss.json")["repos"]:
            for link in r.get("papers") or []:
                i = self.pos.get(link.get("paper"))
                if i is not None:
                    self.stars[i] += r.get("stars") or 0
                    self.has_repo[i] = True
        for i, pid in enumerate(ids):
            if any(res for res in byid[pid].get("resources") or []):
                self.has_repo[i] = True
        # candidate clusters from the star map
        sm = load_json("starmap.json")
        self.threads = [t for t in sm["threads"] if t.get("members") and not t.get("unclustered")]  # sectors of unclustered works are not clusters
        sm_pos = {pid: k for k, pid in enumerate(sm["ids"])}
        self.sm_map = [self.pos.get(pid) for pid in sm["ids"]]
        assert all(self.sm_map[sm_pos[pid]] == i for i, pid in enumerate(ids))

    def is_new(self, i, ref=None, window=NOVA_MONTHS):
        ref = ref or self.asof
        d = self.date[i]
        return d is not None and self.prec[i] != "year" and 0 <= months(ref, d) <= window

    def item(self, i):
        return self.ids[i]


# ---------------------------------------------------------------------------------------------------------------- benchmark use
ALIASES = os.path.join(HERE, "research-paths", "findings", "benchmark-aliases.json")
ALIAS_BLOCK = {"SafeSearch", "LODO", "RAGuard"}  # a search-engine setting; "leave one domain out"; also a defence of that name
COMMON_WORDS = {w.strip().lower() for w in open("/usr/share/dict/words", encoding="utf-8", errors="ignore")} if os.path.exists("/usr/share/dict/words") else set()
DISTINCT = re.compile(r"[A-Z].*[A-Z]|\d|[a-z][A-Z]")


def benchmark_names(U, aliases=True):
    cands = defaultdict(list)
    for i in range(U.n):
        m = NAME.match(U.title[i])
        if not m:
            continue
        name = m.group(1).strip()
        if len(name) < 4 or not DISTINCT.search(name):
            continue
        cands[name].append(i)
    out = {k: v[0] for k, v in cands.items() if len(v) == 1 and U.form[v[0]] == "benchmark"}
    if aliases and os.path.exists(ALIASES):
        # names read from the abstracts of benchmarks whose title gives none (intake/screening/name_benchmarks.py, Claude
        # Opus 5.5 with a verbatim phrase): kept when distinctive, at most two words, and given to one benchmark only
        named, extra = set(out.values()), defaultdict(list)
        for pid, a in json.load(open(ALIASES, encoding="utf-8")).items():
            i, n = U.pos.get(pid), (a.get("name") or "").strip()
            if i is None or i in named or U.form[i] != "benchmark" or not 4 <= len(n) <= 30 or len(n.split()) > 2 or not DISTINCT.search(n):
                continue
            if n in ALIAS_BLOCK or all(w.lower() in COMMON_WORDS for w in n.split()):  # CORE, GUARD, "Among Us": ordinary words would match other papers' text
                continue
            extra[n].append(i)
        for n, v in extra.items():
            if len(v) != 1 or n in out or n in cands:  # a name another work carries in its title is ambiguous
                continue
            out[n] = v[0]
    return out


def fulltext_path(U, i):
    a = U.byid[U.ids[i]]["attributes"]
    cid = "arxiv:" + a["arxiv_id"] if a.get("arxiv_id") else a.get("source_candidate_id")
    if not cid:
        return None
    p = os.path.join(FULLTEXT, hashlib.sha1(cid.encode()).hexdigest()[:16] + ".txt.gz")
    return p if os.path.exists(p) else None


def sentence_at(text, start, end):
    a = max(text.rfind(". ", 0, start), text.rfind("\n\n", 0, start), start - 400)
    b = text.find(". ", end)
    b = min(b + 1 if b >= 0 else len(text), end + 400)
    return " ".join(text[a + 1:b].split())


def clean(text):
    """Readability of an evidence excerpt: extraction residue (LaTeX, tables, symbol runs) scores low."""
    bad = len(re.findall(r"[\\{}_^|✓×]", text)) + len(re.findall(r"\d", text)) / 4
    return -bad / max(1, len(text) / 100)


def excerpt(sentence, name, before=150, after=190):
    """The evidence sentence, cut to a window around the benchmark name when it is long."""
    at = sentence.find(name)
    a, b = max(0, at - before), min(len(sentence), at + len(name) + after)
    return ("… " if a else "") + sentence[a:b] + (" …" if b < len(sentence) else "")


def benchmark_routes(U):
    """(user, benchmark) -> {"kind": use|mention, "evidence": sentence}. Reads cached full texts locally."""
    names = benchmark_names(U)
    first = defaultdict(list)
    for k in names:
        first[k.split()[0]].append(k)
    routes, texts = {}, 0
    for i in range(U.n):
        path = fulltext_path(U, i)
        if not path:
            continue
        texts += 1
        text = gzip.open(path, "rt", encoding="utf-8", errors="ignore").read()
        m = REFS_HEAD.search(text, len(text) // 3)
        body = text[:m.start()] if m else text
        found = {}
        for tm in TOKEN.finditer(body):
            w = tm.group(0).rstrip(".")
            for k in first.get(w, ()):
                parts = k.split()
                if len(parts) == 2:
                    nxt = TOKEN.match(body, tm.end() + 1) if tm.end() + 1 < len(body) else None
                    if not nxt or nxt.group(0).rstrip(".") != parts[1]:
                        continue
                j = names[k]
                if j == i or (U.date[i] and U.date[j] and (U.date[j] - U.date[i]).days > 31):
                    continue
                s = sentence_at(body, tm.start(), tm.end())
                # a survey that lists benchmarks reviews them; it does not use them
                kind = "use" if use_cue(s, k) and not REF_ENTRY.search(s) and U.form[i] != "survey" else "mention"
                ex = excerpt(s, k)
                prev = found.get(j)
                if prev is None or (kind == "use" and prev[0] != "use") or (kind == prev[0] and clean(ex) > clean(prev[1])):
                    found[j] = (kind, ex, k)
        for j, (kind, s, k) in found.items():
            routes[(i, j)] = {"kind": kind, "evidence": s, "name": k}
    return names, routes, texts


# ---------------------------------------------------------------------------------------------------------------- signals
def reference_groups(U, members):
    """In-group citation percentile C^ for the given works: group g(p) = (cluster, publication year, form), falling back
    to (cluster, year) and then (year) when a group has fewer than MIN_GROUP works with a citation count. A work in
    several clusters takes its best percentile."""
    fine, coarse, year_only = defaultdict(set), defaultdict(set), defaultdict(set)
    for i in members:
        if U.cites[i] is None or U.year[i] is None:
            continue
        year_only[U.year[i]].add(i)
        for k in U.ptopics[i] or [-1]:
            fine[(k, U.year[i], U.form[i])].add(i)
            coarse[(k, U.year[i])].add(i)
    cache = {}

    def sorted_vals(key, g):
        if key not in cache:
            cache[key] = np.sort(np.array([U.cites[j] for j in g]))
        return cache[key]
    out = {}
    for i in members:
        if U.cites[i] is None or U.year[i] is None:
            continue
        best = None
        for k in U.ptopics[i] or [-1]:
            key, g = ("f", k, U.year[i], U.form[i]), fine[(k, U.year[i], U.form[i])]
            if len(g) < MIN_GROUP:
                key, g = ("c", k, U.year[i]), coarse[(k, U.year[i])]
            if len(g) < MIN_GROUP:
                key, g = ("y", U.year[i]), year_only[U.year[i]]
            v = sorted_vals(key, g)
            c = U.cites[i]
            p = (np.searchsorted(v, c, "left") + 0.5 * (np.searchsorted(v, c, "right") - np.searchsorted(v, c, "left"))) / len(v)
            best = p if best is None else max(best, p)
        out[i] = float(best)
    return out


def participation(U, i, nodes=None):
    """Participation coefficient of a work's observed citation links across clusters: 1 - sum_t (k_t / k)^2, each linked
    work's clusters counted fractionally. None when the work has fewer than 3 links (signal not observed)."""
    nb = (U.refs[i] | U.cited_by[i]) if nodes is None else nodes
    if len(nb) < 3:
        return None
    k = Counter()
    for j in nb:
        ts = U.ptopics[j]
        for t in ts:
            k[t] += 1 / len(ts)
    tot = sum(k.values())
    return 1 - sum((v / tot) ** 2 for v in k.values()) if tot else None


# ---------------------------------------------------------------------------------------------------------------- sections
def universe_section(U, names, routes, texts):
    used = Counter(j for (i, j), r in routes.items() if r["kind"] == "use")
    return {
        "works": U.n, "clusters": len(U.topics), "galaxies": len(U.themes), "candidateClusters": len(U.threads),
        "citationRoutes": len(U.links), "worksWithCitationRoute": sum(1 for i in range(U.n) if U.refs[i] or U.cited_by[i]),
        "onSemanticScholar": sum(1 for s in U.s2 if s.get("paperId")), "referenceListed": sum(U.ref_listed),
        "fullTexts": texts, "benchmarks": len(names), "benchmarksUsedByOthers": len(used),
        "benchmarkUseRoutes": sum(1 for r in routes.values() if r["kind"] == "use"),
        "benchmarkMentions": sum(1 for r in routes.values() if r["kind"] == "mention"),
        "institutions": len(U.inst_name), "worksWithInstitution": sum(1 for s in U.pinst if s),
        "worksWithCountry": sum(1 for s in U.pcountry if s), "countries": len(set().union(*U.pcountry)),
        "asOf": U.asof.isoformat(),
    }


def fractures(U, routes, rq1, rq4):
    n = U.n
    multi = [i for i in range(n) if len(U.ptopics[i]) >= 2]
    multi_g = [i for i in range(n) if len(U.pthemes[i]) >= 2]
    cross = [(i, j) for i, j in U.links if not set(U.ptopics[i]) & set(U.ptopics[j])]
    cross_g = [(i, j) for i, j in U.links if not set(U.pthemes[i]) & set(U.pthemes[j])]
    use = [r for r in routes.values() if r["kind"] == "use"]
    return {
        "scale": {
            "multiCluster": len(multi), "multiClusterPct": pct(len(multi), n), "multiGalaxy": len(multi_g),
            "multiGalaxyPct": pct(len(multi_g), n), "crossClusterRoutes": len(cross), "crossClusterPct": pct(len(cross), len(U.links)),
            "crossGalaxyRoutes": len(cross_g), "crossGalaxyPct": pct(len(cross_g), len(U.links)),
            "examples": [[U.item(i), U.item(j)] for i, j in random.Random(SEED).sample(cross_g, min(12, len(cross_g)))],
        },
        "basis": {
            "citationRoutes": len(U.links), "citationRecordLevel": len(U.links), "benchmarkUseRoutes": len(use),
            "sentenceLevel": len(use), "sentenceLevelPct": pct(len(use), len(U.links) + len(use)),
            "llmBaseline": None,
        },
        "importance": rq1["bands"]["summary"],
        "timeliness": {
            "doublingMonths": rq4["growth"]["doublingMonths"], "doublingWindow": rq4["growth"]["fitWindow"],
            "intake": rq4["intake"], "surveyLag": rq1["surveyLag"],
        },
    }


def rq1_section(U, routes):
    """Navigation: band disagreement, new-star exposure, and a held-out-survey pilot of navigation salience."""
    rng = random.Random(SEED)
    C = reference_groups(U, range(U.n))
    B = {i: participation(U, i) for i in range(U.n)}
    use_count = Counter(j for (i, j), r in routes.items() if r["kind"] == "use")
    # ---- bands per cluster
    per_topic, taus_cb, taus_gc, overlap = [], [], [], []
    for k, name in enumerate(U.topics):
        mem = [i for i in range(U.n) if k in U.ptopics[i]]
        indeg = {i: len(U.cited_by[i]) for i in mem}
        both = [i for i in mem if i in C and B[i] is not None]
        tau_cb = kendalltau([C[i] for i in both], [B[i] for i in both])[0] if len(both) >= 20 else None
        withc = [i for i in mem if U.cites[i] is not None]
        tau_gc = kendalltau([U.cites[i] for i in withc], [indeg[i] for i in withc])[0] if len(withc) >= 20 else None
        old = [i for i in mem if U.date[i] and months(U.asof, U.date[i]) >= 12]
        influence = sorted([i for i in mem if i in C and not U.is_new(i)], key=lambda i: (-C[i], -(U.cites[i] or 0)))[:10]
        foundation = sorted([i for i in old if i in C], key=lambda i: (-sum(1 for j in U.cited_by[i] if k in U.ptopics[j]), -(U.cites[i] or 0)))[:10]
        bridge = sorted([i for i in mem if B[i] is not None and len(U.refs[i] | U.cited_by[i]) >= 5 and U.form[i] != "survey"],
                        key=lambda i: (-B[i], -len(U.refs[i] | U.cited_by[i])))[:10]
        resource = sorted([i for i in mem if use_count[i]], key=lambda i: (-use_count[i], -(U.cites[i] or 0)))[:10]
        latest = sorted([i for i in mem if U.date[i] and U.prec[i] == "day"], key=lambda i: U.date[i], reverse=True)[:10]
        glob_top = sorted(withc, key=lambda i: -U.cites[i])[:20]
        grp_top = sorted([i for i in mem if i in C], key=lambda i: (-C[i], -(U.cites[i] or 0)))[:20]
        sets = {"foundation": set(foundation), "influence": set(influence), "bridge": set(bridge), "resource": set(resource)}
        jac = [len(sets[a] & sets[b]) / max(1, len(sets[a] | sets[b])) for a in sets for b in sets if a < b and sets[a] and sets[b]]
        overlap.append(float(np.mean(jac)) if jac else None)
        if tau_cb is not None:
            taus_cb.append(tau_cb)
        if tau_gc is not None:
            taus_gc.append(tau_gc)
        per_topic.append({
            "cluster": k, "works": len(mem), "tauCitationBridge": r3(tau_cb), "tauGlobalLocal": r3(tau_gc),
            "bandOverlap": r3(overlap[-1]),
            "novaInGlobalTop20": sum(1 for i in glob_top if U.is_new(i)), "novaInGroupTop20": sum(1 for i in grp_top if U.is_new(i)),
            "novaShare": pct(sum(1 for i in mem if U.is_new(i)), len(mem)),
            "bands": {"foundation": [U.item(i) for i in foundation], "influence": [U.item(i) for i in influence],
                      "bridge": [U.item(i) for i in bridge], "resource": [U.item(i) for i in resource], "latest": [U.item(i) for i in latest]},
            "reasons": {U.item(i): reason(U, i, k, C, B, use_count) for i in set(foundation + influence + bridge + resource + latest)},
        })
    nova_glob = sum(t["novaInGlobalTop20"] for t in per_topic)
    nova_grp = sum(t["novaInGroupTop20"] for t in per_topic)
    summary = {
        "medianTauCitationBridge": r3(median(taus_cb)), "medianTauGlobalLocal": r3(median(taus_gc)),
        "meanBandOverlap": r3(np.mean([o for o in overlap if o is not None])),
        "novaGlobalTop20": nova_glob, "novaGroupTop20": nova_grp, "top20Slots": 20 * len(U.topics),
        "novaShareCorpus": pct(sum(1 for i in range(U.n) if U.is_new(i)), U.n),
        "coverageC": len(C), "coverageB": sum(1 for v in B.values() if v is not None), "coverageU": len(use_count),
    }
    pilot = survey_pilot(U, routes)
    return {"bands": {"summary": summary, "perCluster": per_topic}, "pilot": pilot["pilot"], "surveyLag": pilot["lag"]}


def reason(U, i, k, C, B, use_count):
    """Short, checkable reasons for a work's place in a band (each one a count or a recorded fact)."""
    out = []
    inside = sum(1 for j in U.cited_by[i] if k in U.ptopics[j])
    if inside:
        out.append(["citedInCluster", inside])
    if U.cites[i] is not None:
        out.append(["citations", U.cites[i]])
    if i in C:
        out.append(["groupPercentile", round(100 * C[i])])
    if B.get(i) is not None:
        out.append(["clustersLinked", len({t for j in U.refs[i] | U.cited_by[i] for t in U.ptopics[j]})])
    if use_count[i]:
        out.append(["usedBy", use_count[i]])
    if U.has_repo[i]:
        out.append(["code", 1])
    if U.is_new(i):
        out.append(["nova", 1])
    return out


def survey_pilot(U, routes):
    """Held-out surveys as reference sets: for each survey s, the works it cites inside the Atlas that existed before s are
    the relevant set; rankers see only works dated before s and citation counts as of s (citations by works dated
    before s, so s's own edges and later citations are excluded)."""
    surveys = [s for s in range(U.n) if U.form[s] == "survey" and U.prec[s] == "day" and U.date[s] >= dt.date(2024, 7, 1)]
    order = np.array([U.date[i].toordinal() if U.date[i] else 10 ** 9 for i in range(U.n)])
    dayish = np.array([U.prec[i] in ("day", "month") for i in range(U.n)])
    res = defaultdict(list)
    lag, details = [], []
    for s in surveys:
        ds = U.date[s].toordinal()
        pool = np.where(((order < ds) & dayish) | ((order < ds - 365) & ~dayish))[0]
        pool = pool[pool != s]
        pset = set(pool.tolist())
        rel = [j for j in U.refs[s] if j in pset]
        refs_dated = sorted(U.date[j] for j in U.refs[s] if U.date[j] and U.prec[j] == "day" and U.date[j] < U.date[s])
        if len(refs_dated) >= 10:
            # works on the survey's own question: its 300 nearest neighbours (SPECTER2), the same distance gate as below
            near = [int(j) for j in np.argsort(-(U.emb @ U.emb[s]))[:301] if j != s][:300]
            p90 = refs_dated[int(0.9 * (len(refs_dated) - 1))]
            gap = [j for j in near if U.prec[j] == "day" and p90 < U.date[j] < U.date[s]]
            since = [j for j in near if U.prec[j] == "day" and U.date[j] >= U.date[s]]
            lag.append((months(U.date[s], refs_dated[-1]), months(U.date[s], p90), len(gap), sum(1 for j in gap if j in U.refs[s]),
                        len(since), months(U.asof, U.date[s])))
        if len(rel) < 20 or len(pool) < 200:
            continue
        relset = set(rel)
        # citations as of s: citing works dated before s, inside the pool
        c_asof = np.zeros(U.n)
        for j in pool:
            c_asof[j] = sum(1 for q in U.cited_by[j] if q in pset)
        cos = U.emb[pool] @ U.emb[s]
        topical = np.array([bool(set(U.ptopics[j]) & set(U.ptopics[s])) for j in pool])
        kth = np.sort(cos)[-300] if len(cos) > 300 else cos.min()
        relev = np.clip((cos - kth) / max(1e-6, cos.max() - kth), 0, None)
        # in-group percentile of as-of citations within the gated neighbourhood, by (year, form)
        gate = relev > 0
        grp = defaultdict(list)
        for idx in np.where(gate)[0]:
            j = pool[idx]
            grp[(U.year[j], U.form[j])].append(idx)
        chat = np.zeros(len(pool))
        for g, members in grp.items():
            if len(members) < 5:
                members = [m for m in np.where(gate)[0] if U.year[pool[m]] == g[0]]
            vals = c_asof[pool[members]]
            for m in grp[g]:
                v = c_asof[pool[m]]
                chat[m] = (np.sum(vals < v) + 0.5 * np.sum(vals == v)) / len(vals)
        bridge = np.zeros(len(pool))
        for idx in np.where(gate)[0]:
            j = pool[idx]
            bridge[idx] = participation(U, j, nodes={q for q in U.refs[j] | U.cited_by[j] if q in pset}) or 0
        cp = c_asof[pool]
        rankers = {
            "citations": np.where(topical, cp + 1e-6 * cos, -1),
            "relevance": cos,
            "relevanceCitations": relev * (cp / max(1, cp.max())) + 1e-6 * cos,
            "salience": relev * (0.75 * chat + 0.25 * bridge) + 1e-6 * cos,
            # weight sensitivity (appendix D): citation signal only, and an even split with the bridge signal
            "salienceC": relev * chat + 1e-6 * cos,
            "salience50": relev * (0.5 * chat + 0.5 * bridge) + 1e-6 * cos,
        }
        newmask = np.array([U.date[j] is not None and 0 <= months(U.date[s], U.date[j]) <= NOVA_MONTHS for j in pool])
        for name, score in rankers.items():
            top = np.argsort(-score)
            for k in (20, 50):
                hits = sum(1 for idx in top[:k] if pool[idx] in relset)
                res[(name, f"recall{k}")].append(hits / len(relset))
            gains = [1 / math.log2(r + 2) for r, idx in enumerate(top[:50]) if pool[idx] in relset]
            ideal = sum(1 / math.log2(r + 2) for r in range(min(50, len(relset))))
            res[(name, "ndcg50")].append(sum(gains) / ideal)
            res[(name, "nova20")].append(float(np.mean(newmask[top[:20]])))
        res[("random", "recall20")].append(20 / len(pool))
        res[("random", "recall50")].append(50 / len(pool))
        res[("random", "nova20")].append(float(np.mean(newmask)))
        details.append({"survey": U.item(s), "relevant": len(rel), "pool": int(len(pool)),
                        "recall50": {name: r3(res[(name, "recall50")][-1]) for name in rankers}})
    table = []
    for name in ("random", "citations", "relevance", "relevanceCitations", "salience", "salienceC", "salience50"):
        row = {"ranker": name}
        for m in ("recall20", "recall50", "ndcg50", "nova20"):
            v = res.get((name, m))
            row[m] = r3(np.mean(v)) if v else None
        table.append(row)
    r1 = lambda v: None if v is None else round(v, 1)  # noqa: E731
    lagm = {"surveys": len(lag), "newestRefMonths": r1(median([x[0] for x in lag])), "p90RefMonths": r1(median([x[1] for x in lag])),
            "nearInGap": median([x[2] for x in lag]), "nearInGapCited": median([x[3] for x in lag]),
            "nearSince": median([x[4] for x in lag]), "surveyAgeMonths": r1(median([x[5] for x in lag]))}
    return {"pilot": {"surveys": len(details), "table": table, "detail": details[:400],
                      "medianRelevant": median([d["relevant"] for d in details]), "medianPool": median([d["pool"] for d in details])},
            "lag": lagm}


def rq2_section(U, routes):
    """What connects clusters: four layers over the same 19 clusters, each pair compared on works that belong to one of
    the two clusters only (shared members would make every layer look connected)."""
    K = len(U.topics)
    mem = [set(i for i in range(U.n) if k in U.ptopics[i]) for k in range(K)]
    users = defaultdict(set)   # benchmark -> users (use routes)
    for (i, j), r in routes.items():
        if r["kind"] == "use":
            users[j].add(i)
    bench_of = defaultdict(set)  # work -> benchmarks it uses
    for j, us in users.items():
        for i in us:
            bench_of[i].add(j)
    total_links = len(U.links)
    outdeg = Counter(i for i, j in U.links)
    indeg = Counter(j for i, j in U.links)
    pairs = []
    for a in range(K):
        for b in range(a + 1, K):
            A, Bm = mem[a] - mem[b], mem[b] - mem[a]
            if len(A) < 20 or len(Bm) < 20:
                continue
            ia, ib = np.fromiter(A, int), np.fromiter(Bm, int)
            sem = float(U.emb[ia].mean(0) @ U.emb[ib].mean(0))
            obs = sum(1 for i in A for j in U.refs[i] if j in Bm) + sum(1 for i in Bm for j in U.refs[i] if j in A)
            exp = (sum(outdeg[i] for i in A) * sum(indeg[j] for j in Bm) + sum(outdeg[i] for i in Bm) * sum(indeg[j] for j in A)) / total_links
            # profile cosine: how similarly the two clusters draw on institutions (works per ROR institution) and on
            # benchmarks (use routes per benchmark); unlike shared-set counts it does not grow with cluster size
            insA, insB = Counter(r for i in A for r in U.pinst[i]), Counter(r for i in Bm for r in U.pinst[i])
            co = profile_cosine(insA, insB)
            benA, benB = Counter(j for i in A for j in bench_of[i]), Counter(j for i in Bm for j in bench_of[i])
            shared = set(benA) & set(benB)
            usersA, usersB = sum(1 for i in A if bench_of[i]), sum(1 for i in Bm if bench_of[i])
            # too few observed uses on either side: the layer is not observed for this pair (not zero)
            res = profile_cosine(benA, benB) if min(usersA, usersB) >= MIN_USERS else None
            pairs.append({"a": a, "b": b, "semantic": round(sem, 4), "citeObs": obs, "citeExp": round(exp, 1),
                          "citeRatio": round(obs / exp, 3) if exp else None, "collab": round(co, 4), "sharedInst": len(insA & insB),
                          "resource": None if res is None else round(res, 4), "sharedBench": len(shared), "users": [usersA, usersB],
                          "sharedBenchTop": [U.item(j) for j in sorted(shared, key=lambda j: -len(users[j] & (A | Bm)))[:6]]})
    layers = ["semantic", "citeRatio", "collab", "resource"]
    corr = {}
    for x in layers:
        for y in layers:
            if x < y:
                both = [p for p in pairs if p[x] is not None and p[y] is not None]
                corr[f"{x}|{y}"] = r3(spearmanr([p[x] for p in both], [p[y] for p in both])[0])
    for x in layers:
        obs = sorted([p for p in pairs if p[x] is not None], key=lambda p: -p[x])
        for r, p in enumerate(obs):
            p.setdefault("pct", {})[x] = round(100 * (1 - r / max(1, len(obs) - 1)))
        for p in pairs:
            p.setdefault("pct", {}).setdefault(x, None)
    h2a = sorted([p for p in pairs if p["pct"]["semantic"] >= 75 and p["pct"]["citeRatio"] <= 25],
                 key=lambda p: p["pct"]["citeRatio"] - p["pct"]["semantic"])
    h2b = sorted([p for p in pairs if p["resource"] is not None and p["pct"]["citeRatio"] <= 50 and p["pct"]["resource"] >= 75],
                 key=lambda p: p["pct"]["citeRatio"] - p["pct"]["resource"])
    for p in h2a[:8]:
        p["examples"] = pair_examples(U, mem[p["a"]] - mem[p["b"]], mem[p["b"]] - mem[p["a"]])
    for p in h2b[:8]:
        p["examples"] = pair_examples(U, mem[p["a"]] - mem[p["b"]], mem[p["b"]] - mem[p["a"]])
        p["benchEvidence"] = bench_examples(U, routes, p, mem)
    return {"pairs": pairs, "layers": layers, "correlation": corr, "minUsers": MIN_USERS,
            "resourceObserved": sum(1 for p in pairs if p["resource"] is not None),
            "h2a": [[p["a"], p["b"]] for p in h2a], "h2b": [[p["a"], p["b"]] for p in h2b],
            "h2aDetail": h2a[:8], "h2bDetail": h2b[:8]}


def profile_cosine(a, b):
    num = sum(v * b[k] for k, v in a.items() if k in b)
    den = math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values()))
    return num / den if den else 0.0


def pair_examples(U, A, Bm):
    """Closest semantic pairs across two clusters that do not cite each other, plus any citation that does exist."""
    ia, ib = sorted(A), sorted(Bm)
    if len(ia) > 1500:
        ia = random.Random(SEED).sample(ia, 1500)
    if len(ib) > 1500:
        ib = random.Random(SEED).sample(ib, 1500)
    sim = U.emb[ia] @ U.emb[ib].T
    flat = np.argsort(-sim, axis=None)[:200]
    close, used = [], set()
    for f in flat:
        x, y = divmod(int(f), len(ib))
        i, j = ia[x], ib[y]
        if i in used or j in used or j in U.refs[i] or i in U.refs[j]:
            continue
        used |= {i, j}
        close.append([U.item(i), U.item(j), round(float(sim[x, y]), 3)])
        if len(close) == 4:
            break
    cites = [[U.item(i), U.item(j)] for i in A for j in U.refs[i] if j in Bm][:4]
    return {"closeNotCiting": close, "citing": cites}


def bench_examples(U, routes, p, mem):
    """For each of the top shared benchmarks, one use on each side: distinct users, most readable sentence first."""
    out, seen = [], set()
    for bid in p["sharedBenchTop"][:3]:
        j = U.pos[bid]
        for side in ("a", "b"):
            grp = mem[p[side]] - mem[p["b" if side == "a" else "a"]]
            cands = [(clean(r["evidence"]), i, r) for (i, jj), r in routes.items() if jj == j and r["kind"] == "use" and i in grp and i not in seen]
            if cands:
                _, i, r = max(cands, key=lambda c: c[0])
                seen.add(i)
                out.append({"user": U.item(i), "benchmark": bid, "side": side, "evidence": r["evidence"]})
    return out


def rq3_section(U, routes):
    """Centres: attention, connection and supply ranked separately for clusters and institutions (no combined score)."""
    K = len(U.topics)
    users = defaultdict(set)
    for (i, j), r in routes.items():
        if r["kind"] == "use":
            users[j].add(i)
    rows = []
    for k in range(K):
        mem = [i for i in range(U.n) if k in U.ptopics[i]]
        ms = set(mem)
        cit = [U.cites[i] for i in mem if U.cites[i] is not None]
        links = [(i, j) for i in mem for j in U.refs[i]] + [(j, i) for i in mem for j in U.cited_by[i]]
        cross = [1 for i, j in links if k not in U.ptopics[j]]
        other = Counter()
        for i, j in links:
            if k not in U.ptopics[j]:
                for t in U.ptopics[j]:
                    other[t] += 1 / len(U.ptopics[j])
        tot = sum(other.values())
        partic = 1 - sum((v / tot) ** 2 for v in other.values()) if tot else None
        supplied = [j for j in mem if U.form[j] == "benchmark" and users[j]]
        outside = {(i, j) for j in supplied for i in users[j] if i not in ms}
        rows.append({"cluster": k, "works": len(mem), "citations": int(sum(cit)), "medianCitations": median(cit),
                     "stars": int(sum(U.stars[i] for i in mem)), "crossShare": pct(len(cross), len(links)),
                     "participation": r3(partic), "benchmarks": sum(1 for j in mem if U.form[j] == "benchmark"),
                     "suppliedOutside": len(outside), "suppliers": len({j for i, j in outside}),
                     "topSupplied": [U.item(j) for j in sorted(supplied, key=lambda j: -len(users[j] - ms))[:5]]})
    def ranks(key):
        order = sorted(rows, key=lambda r: -(r[key] or 0))
        return {r["cluster"]: n + 1 for n, r in enumerate(order)}
    rk = {key: ranks(key) for key in ("works", "citations", "stars", "crossShare", "participation", "suppliedOutside")}
    for r in rows:
        r["rank"] = {key: rk[key][r["cluster"]] for key in rk}
    corr = {f"{a}|{b}": r3(spearmanr([r[a] or 0 for r in rows], [r[b] or 0 for r in rows])[0])
            for a, b in (("works", "suppliedOutside"), ("citations", "suppliedOutside"), ("works", "crossShare"),
                         ("citations", "participation"), ("stars", "suppliedOutside"), ("works", "citations"))}
    # institutions
    inst_works = defaultdict(set)
    for i in range(U.n):
        for r in U.pinst[i]:
            inst_works[r].add(i)
    inst = []
    for r, ws in inst_works.items():
        if len(ws) < 5:
            continue
        supply = {(u, j) for j in ws if U.form[j] == "benchmark" for u in users[j] if not (U.pinst[u] & {r})}
        topics = Counter(t for i in ws for t in U.ptopics[i])
        inst.append({"id": r, "name": U.inst_name[r], "works": len(ws), "citations": int(sum(U.cites[i] or 0 for i in ws)),
                     "supply": len(supply), "benchmarksUsed": len({j for u, j in supply}), "clusters": len(topics),
                     "bridgeWorks": sum(1 for i in ws if len(U.pthemes[i]) >= 2)})
    def top(key, k=15):
        return [x["id"] for x in sorted(inst, key=lambda x: (-x[key], -x["works"]))[:k]]
    tops = {key: top(key) for key in ("works", "citations", "supply")}
    out_rank = {x["id"]: n + 1 for n, x in enumerate(sorted(inst, key=lambda x: (-x["works"], -x["citations"])))}
    for x in inst:
        x["outputRank"] = out_rank[x["id"]]
    inst_keep = {i for v in tops.values() for i in v}
    inst_corr = r3(spearmanr([x["works"] for x in inst], [x["supply"] for x in inst])[0]) if inst else None
    supply_only = [x["id"] for x in sorted(inst, key=lambda x: -x["supply"]) if x["id"] in tops["supply"] and x["id"] not in tops["works"]]
    return {"clusters": rows, "correlation": corr,
            "institutions": {"eligible": len(inst), "top": tops, "rows": sorted([x for x in inst if x["id"] in inst_keep], key=lambda x: x["outputRank"]),  # fixed order (set order varies by run)
                             "overlapWorksSupply": len(set(tops["works"]) & set(tops["supply"])),
                             "overlapWorksCitations": len(set(tops["works"]) & set(tops["citations"])),
                             "supplyNotOutput": supply_only, "corrWorksSupply": inst_corr,
                             "coverage": {"worksWithInstitution": sum(1 for s in U.pinst if s), "works": U.n}}}


def rq4_section(U, routes):
    """Growth, synchrony and lag: quarterly output per galaxy, connection density, benchmark supply, onset gaps,
    entry of young candidate clusters, preprint-to-publication lag, intake delay of scheduled updates."""
    qs = [f"{y}Q{q}" for y in range(2020, U.asof.year + 1) for q in range(1, 5)]
    qs = qs[:qs.index(quarter(U.asof)) + 1]
    last_complete = qs[-2]  # the quarter holding the snapshot date is incomplete
    G = len(U.themes)
    series = [[0] * len(qs) for _ in range(G)]
    total = [0] * len(qs)
    for i in range(U.n):
        d = U.date[i]
        if not d or U.prec[i] == "year" or quarter(d) not in qs:
            continue
        q = qs.index(quarter(d))
        total[q] += 1
        for g in U.pthemes[i]:
            series[g][q] += 1
    # doubling time: log-linear fit on complete quarters 2023Q1 .. last complete quarter
    lo, hi = qs.index("2023Q1"), qs.index(last_complete)
    x = np.arange(hi - lo + 1)

    def doubling(vals):
        v = np.array(vals[lo:hi + 1], dtype=float)
        if (v <= 0).any():
            return None
        slope = np.polyfit(x, np.log(v), 1)[0]
        return round(3 * math.log(2) / slope, 1) if slope > 0 else None
    growth = {"quarters": qs, "total": total, "byGalaxy": series, "doublingMonths": doubling(total),
              "doublingByGalaxy": [doubling(s) for s in series], "fitWindow": [qs[lo], qs[hi]], "incomplete": qs[hi + 1:]}
    # connection density and cross-cluster share by citing year
    years = list(range(2021, U.asof.year + 1))
    conn = []
    for y in years:
        L = [(i, j) for i, j in U.links if U.year[i] == y]
        cr = [1 for i, j in L if not set(U.ptopics[i]) & set(U.ptopics[j])]
        works_y = sum(1 for i in range(U.n) if U.year[i] == y)
        conn.append({"year": y, "routes": len(L), "perWork": round(len(L) / max(1, works_y), 2), "crossPct": pct(len(cr), len(L))})
    # benchmark supply by year and galaxy (benchmark-form works) and use routes by year
    bench_year = [[sum(1 for i in range(U.n) if U.form[i] == "benchmark" and U.year[i] == y and g in U.pthemes[i]) for y in years] for g in range(G)]
    use_year = [sum(1 for (i, j), r in routes.items() if r["kind"] == "use" and U.year[i] == y) for y in years]
    # onset: attack (title rule) vs benchmark-form vs defence (title rule) per cluster
    # (counted from 2023, the LLM-agent period; older RL and adversarial-ML work would otherwise set every onset)
    onset = []
    for k, name in enumerate(U.topics):
        mem = [i for i in range(U.n) if k in U.ptopics[i] and U.date[i] and U.prec[i] != "year" and U.date[i] >= dt.date(2023, 1, 1)]
        att = sorted(U.date[i] for i in mem if ATTACK.search(U.title[i]) and not DEFENSE.search(U.title[i]) and U.form[i] != "benchmark")
        dfn = sorted(U.date[i] for i in mem if DEFENSE.search(U.title[i]) and U.form[i] == "method")
        ev = sorted(U.date[i] for i in mem if U.form[i] == "benchmark")
        nth = lambda xs, n=5: xs[n - 1].isoformat() if len(xs) >= n else None  # noqa: E731
        row = {"cluster": k, "attack": nth(att), "defense": nth(dfn), "benchmark": nth(ev),
               "counts": [len(att), len(dfn), len(ev)]}
        if row["attack"] and row["benchmark"]:
            row["benchLagMonths"] = round(months(dt.date.fromisoformat(row["benchmark"]), dt.date.fromisoformat(row["attack"])), 1)
        if row["attack"] and row["defense"]:
            row["defenseLagMonths"] = round(months(dt.date.fromisoformat(row["defense"]), dt.date.fromisoformat(row["attack"])), 1)
        # recent ratio: attacks per benchmark in the last 12 months
        rec = lambda xs: sum(1 for d in xs if months(U.asof, d) <= 12)  # noqa: E731
        row["recent"] = [rec(att), rec(dfn), rec(ev)]
        onset.append(row)
    # young candidate clusters: how do they connect?
    thread_rows = []
    for t in U.threads:
        mem = [U.sm_map[m] for m in t["members"] if U.sm_map[m] is not None]
        ds = sorted(U.date[i] for i in mem if U.date[i] and U.prec[i] != "year")
        if len(ds) < 6:
            continue
        k = U.tidx.get(t["topic"])
        refs = [(i, j) for i in mem for j in U.refs[i]]
        cross = sum(1 for i, j in refs if k not in U.ptopics[j])
        thread_rows.append({"id": t["id"], "topic": k, "label": t.get("label"), "size": len(mem), "start": ds[len(ds) // 10].isoformat(),
                            "median": ds[len(ds) // 2].isoformat(),
                            "crossRefPct": pct(cross, len(refs)) if refs else None, "refs": len(refs)})
    young = [r for r in thread_rows if months(U.asof, dt.date.fromisoformat(r["median"])) <= 9]
    old = [r for r in thread_rows if months(U.asof, dt.date.fromisoformat(r["median"])) > 18]
    def agg(rows, key):
        v = [r[key] for r in rows if r[key] is not None and r["refs"] >= 10] if key == "crossRefPct" else [r[key] for r in rows if r[key] is not None]
        return r3(median(v)) if v else None
    h4b = {"young": len(young), "old": len(old), "youngCross": agg(young, "crossRefPct"), "oldCross": agg(old, "crossRefPct"),
           "youngWithRefs": sum(1 for r in young if r["refs"] >= 10), "oldWithRefs": sum(1 for r in old if r["refs"] >= 10),
           "youngList": [r["id"] for r in sorted(young, key=lambda r: -r["size"])[:10]]}
    # preprint -> publication: arXiv month from the identifier (YYMM.NNNNN) against the earliest verified publication
    # date with at least month precision; works first posted and published in the same month stay undetermined
    lag = defaultdict(list)
    order_count = Counter()
    for i, pid in enumerate(U.ids):
        p = U.byid[pid]
        m = re.match(r"^(\d{2})(\d{2})\.\d{4,5}$", p["attributes"].get("arxiv_id") or "")
        pubs = [v for v in p.get("publicationVersions") or [] if v.get("status") == "published" and len(v.get("date") or "") >= 7]
        if not m or not pubs:
            continue
        ax = 12 * (2000 + int(m.group(1))) + int(m.group(2)) - 1
        first = min(pubs, key=lambda v: v["date"])
        pm = 12 * int(first["date"][:4]) + int(first["date"][5:7]) - 1
        if pm > ax:
            order_count["preprintFirst"] += 1
            lag[first.get("venueGroup") or "other"].append(pm - ax)
        elif pm == ax:
            order_count["sameMonth"] += 1
        else:
            order_count["publishedFirst"] += 1
    lag_all = [x for v in lag.values() for x in v]
    n_pub = sum(order_count.values())
    pub = {"withPublicationAndPreprint": n_pub, **order_count, "preprintFirstPct": pct(order_count["preprintFirst"], n_pub),
           "medianLagMonths": median(lag_all), "byVenueGroup": {k: [len(v), median(v)] for k, v in lag.items() if len(v) >= 10}}
    status = Counter(U.byid[pid]["publication"]["status"] for pid in U.ids)
    by_year_status = {y: [sum(1 for i in range(U.n) if U.year[i] == y and U.byid[U.ids[i]]["publication"]["status"] == s)
                          for s in ("published", "accepted", "unverified")] for y in years}
    ft = [fulltext_path(U, i) is not None for i in range(U.n)]
    ft_year = [[sum(1 for i in range(U.n) if U.year[i] == y and ft[i]), sum(1 for i in range(U.n) if U.year[i] == y)] for y in years]
    return {"growth": growth, "connection": conn, "benchYear": bench_year, "useYear": use_year, "years": years, "fullTextByYear": ft_year,
            "onset": onset, "threads": {"h4b": h4b, "rows": sorted(thread_rows, key=lambda r: r["median"], reverse=True)[:60]},
            "publication": pub, "status": dict(status), "statusByYear": by_year_status, "intake": intake(U)}


def intake(U):
    """Days from arXiv first submission to the release that added the work, for releases made by scheduled updates that
    read new arXiv records (release date as recorded in updates.json)."""
    upd = load_json("updates.json")
    sched = {r["release"]: r["date"] for r in upd["releases"]
             if (r.get("run") or {}).get("kind") == "scheduled" and ((r["run"].get("arxiv") or {}).get("records") or 0) > 0}
    lags = []
    for i, pid in enumerate(U.ids):
        rel = U.byid[pid]["attributes"].get("curation_release")
        if rel in sched and U.date[i] and U.prec[i] == "day" and U.byid[pid]["attributes"].get("arxiv_id"):
            lags.append((dt.date.fromisoformat(sched[rel]) - U.date[i]).days)
    lags.sort()
    return {"releases": sorted(sched), "works": len(lags), "medianDays": median(lags),
            "p75Days": lags[int(0.75 * (len(lags) - 1))] if lags else None, "within14": pct(sum(1 for x in lags if x <= 14), len(lags))}


# ---------------------------------------------------------------------------------------------------------------- trends
STOP = set("""a an the and or of for in on to with via by from as at into under over towards toward through against beyond
without within across using use based is are be can do does not how what when why which who their its your our we you it this
that these those vs versus new large language model models llm llms agent agents agentic ai system systems study approach
framework frameworks benchmark benchmarks evaluation evaluating evaluate toward analysis safety safe secure security towards
learning method methods paper case more less than via multi one two three all any each per between enhancing deep
generation state evidence boundary recovery heterogeneous efficient robust novel real world aware driven level scale
understanding improving rethinking empirical comprehensive survey review perspective position challenges opportunities
lessons large-scale under toward beyond only make making through after before while their them they it's""".split())
TERM = re.compile(r"[A-Za-z][A-Za-z0-9\-\+]*")


def half(d):
    return f"{d.year}H{1 if d.month <= 6 else 2}"


def window(U, i, lo, hi):
    """True when work i was first posted in the window (lo, hi] months before the snapshot (day/month precision)."""
    d = U.date[i]
    return d is not None and U.prec[i] != "year" and lo <= months(U.asof, d) < hi


def title_terms(title, singular=None):
    toks = [t for t in TERM.findall(re.sub(r"(?i)fine-tun", "finetun", title).replace("-", " "))]
    low = [(singular or {}).get(t.lower(), t.lower()) for t in toks]
    keep = [(t, l) for t, l in zip(toks, low) if l not in STOP and len(l) > 2 and not l.isdigit()]
    terms = {l for t, l in keep}
    for (t1, l1), (t2, l2) in zip(keep, keep[1:]):
        terms.add(l1 + " " + l2)
    return terms, {l: t for t, l in keep}


def trends_section(U, routes):
    """Time, place and concentration: how topic shares, title vocabulary, countries, institutions, citations, benchmarks
    and industry participation change. Recent = the 12 (or 6) months before the snapshot, compared with the 12 (or 18)
    before that; only works with a day or month date take part in time windows."""
    out = {}
    K = len(U.topics)
    recent = [i for i in range(U.n) if window(U, i, 0, 12)]
    before = [i for i in range(U.n) if window(U, i, 12, 24)]
    # ---- cluster shares, last 12 months vs the 12 before
    # fractional credit: a work splits one unit over its clusters, so shares sum to 100% even though recent works carry
    # more labels (labels per work are reported alongside)
    def frac(ws, k):
        return sum(1 / len(U.ptopics[i]) for i in ws if k in U.ptopics[i])
    rec_l = [i for i in recent if U.ptopics[i]]
    bef_l = [i for i in before if U.ptopics[i]]
    rows = []
    for k in range(K):
        a, b = frac(bef_l, k), frac(rec_l, k)
        rows.append({"cluster": k, "before": sum(1 for i in before if k in U.ptopics[i]), "recent": sum(1 for i in recent if k in U.ptopics[i]),
                     "shareBefore": pct(a, len(bef_l)), "shareRecent": pct(b, len(rec_l))})
    halves = sorted({half(U.date[i]) for i in range(U.n) if U.date[i] and U.prec[i] != "year" and U.date[i].year >= 2022})
    hs = {h: [i for i in range(U.n) if U.date[i] and U.prec[i] != "year" and half(U.date[i]) == h] for h in halves}
    for r in rows:
        r["series"] = [pct(frac([i for i in hs[h] if U.ptopics[i]], r["cluster"]), sum(1 for i in hs[h] if U.ptopics[i])) for h in halves]
    lab = lambda ws: round(sum(len(U.ptopics[i]) for i in ws) / max(1, len(ws)), 2)  # noqa: E731
    out["clusterShares"] = {"rows": rows, "recentWorks": len(recent), "beforeWorks": len(before), "halves": halves,
                            "halfWorks": [len(hs[h]) for h in halves], "labelsRecent": lab(rec_l), "labelsBefore": lab(bef_l)}
    # ---- title terms: last 6 months vs the 18 months before
    r6 = [i for i in range(U.n) if window(U, i, 0, 6)]
    e18 = [i for i in range(U.n) if window(U, i, 6, 24)]
    vocab = {t.lower() for i in r6 + e18 for t in TERM.findall(U.title[i].replace("-", " "))}
    singular = {w: w[:-1] for w in vocab if w.endswith("s") and not w.endswith("ss") and w[:-1] in vocab}
    tset = {}
    show_case = defaultdict(Counter)
    for i in r6 + e18:
        ts, case = title_terms(U.title[i], singular)
        tset[i] = ts
        for l, t in case.items():
            show_case[l][t] += 1
    cr = Counter(t for i in r6 for t in tset[i])
    ce = Counter(t for i in e18 for t in tset[i])
    qs = sorted({quarter(U.date[i]) for i in r6 + e18})
    def lift(t):
        return ((cr[t] + 1) / (len(r6) + 1)) / ((ce[t] + 1) / (len(e18) + 1))
    def display(t):
        return " ".join(show_case[w].most_common(1)[0][0] if show_case[w] else w for w in t.split())
    def term_row(t):
        ids = [i for i in r6 if t in tset[i]]
        return {"term": display(t), "recent": cr[t], "earlier": ce[t], "lift": round(lift(t), 2),
                "quarters": [sum(1 for i in r6 + e18 if quarter(U.date[i]) == q and t in tset[i]) for q in qs],
                "ids": [U.item(i) for i in sorted(ids, key=lambda i: U.date[i], reverse=True)[:300]]}
    rising = sorted([t for t in cr if cr[t] >= 15 and lift(t) >= 1.8], key=lambda t: -lift(t) * math.log(cr[t]))
    # a bigram whose words are both listed adds nothing; a unigram fully explained by one bigram is dropped too
    picked = []
    for t in rising:
        if any(t in p.split() or p in t.split() for p in picked if " " in p or " " in t):
            if any(cr[p] >= 0.8 * cr[t] for p in picked):
                continue
        picked.append(t)
        if len(picked) == 16:
            break
    fading = sorted([t for t in ce if ce[t] >= 25 and lift(t) <= 0.6], key=lambda t: lift(t) / math.log(ce[t]))[:8]
    out["terms"] = {"quarters": qs, "recentWorks": len(r6), "earlierWorks": len(e18), "rising": [term_row(t) for t in picked],
                    "fading": [term_row(t) for t in fading]}
    # ---- emerging candidate clusters
    em = []
    for t in U.threads:
        mem = [U.sm_map[m] for m in t["members"] if U.sm_map[m] is not None]
        ds = sorted(U.date[i] for i in mem if U.date[i] and U.prec[i] != "year")
        if len(mem) < 15 or len(ds) < 10:
            continue
        new6 = sum(1 for i in mem if window(U, i, 0, 6))
        em.append({"id": t["id"], "topic": U.tidx.get(t["topic"]), "label": t.get("label"), "size": len(mem), "recent6": new6,
                   "recentShare": pct(new6, len(mem)), "start": ds[len(ds) // 10].isoformat(), "median": ds[len(ds) // 2].isoformat(),
                   "ids": [U.item(i) for i in sorted(mem, key=lambda i: U.date[i] or dt.date(1900, 1, 1), reverse=True)[:200]]})
    out["emerging"] = sorted([e for e in em if e["recentShare"] >= 60 and e["label"]], key=lambda e: -e["recent6"])[:12]
    # ---- geography: fractional country credit by year and by cluster
    years = list(range(2020, U.asof.year + 1))
    cy = defaultdict(Counter)
    located = Counter()
    multi, uscn = Counter(), Counter()
    total_y = Counter()
    for i in range(U.n):
        y = U.year[i]
        if y not in years:
            continue
        total_y[y] += 1
        cs = U.pcountry[i]
        if not cs:
            continue
        located[y] += 1
        for c in cs:
            cy[y][c] += 1 / len(cs)
        multi[y] += len(cs) >= 2
        uscn[y] += {"US", "CN"} <= cs
    overall = Counter()
    for y in years:
        overall.update(cy[y])
    top = [c for c, _ in overall.most_common(8)]
    out["geography"] = {
        "years": years, "countries": top,
        "share": {c: [pct(cy[y][c], located[y]) for y in years] for c in top},
        "other": [pct(located[y] - sum(cy[y][c] for c in top), located[y]) for y in years],
        "located": [located[y] for y in years], "works": [total_y[y] for y in years],
        "international": [pct(multi[y], located[y]) for y in years], "usCn": [pct(uscn[y], located[y]) for y in years],
        "usCnWorks": [uscn[y] for y in years]}
    since = [i for i in range(U.n) if U.year[i] and U.year[i] >= 2023 and U.pcountry[i]]
    tot = Counter()
    for i in since:
        for c in U.pcountry[i]:
            tot[c] += 1 / len(U.pcountry[i])
    n_since = len(since)
    lean = []
    for k in range(K):
        mem = [i for i in since if k in U.ptopics[i]]
        cc = Counter()
        for i in mem:
            for c in U.pcountry[i]:
                cc[c] += 1 / len(U.pcountry[i])
        lean.append({"cluster": k, "works": len(mem), **{c: pct(cc[c], len(mem)) for c in top[:4]}})
    out["geography"]["byCluster"] = lean
    out["geography"]["overallSince2023"] = {c: pct(tot[c], n_since) for c in top[:4]}
    # ---- concentration
    inst_year = defaultdict(Counter)
    first_year = {}
    for i in sorted(range(U.n), key=lambda i: (U.year[i] or 9999)):
        y = U.year[i]
        for r in U.pinst[i]:
            if y in years:
                inst_year[y][r] += 1 / len(U.pinst[i])
            if y and r not in first_year:
                first_year[r] = y
    conc = []
    for y in years:
        c = inst_year[y]
        totc = sum(c.values())
        top10 = sum(v for _, v in c.most_common(10))
        hh = sum((v / totc) ** 2 for v in c.values()) if totc else None
        tcount = Counter(t for i in range(U.n) if U.year[i] == y for t in U.ptopics[i])
        tt = sum(tcount.values())
        conc.append({"year": y, "institutions": len(c), "top10Share": pct(top10, totc), "hhi": r3(hh),
                     "newInstitutions": sum(1 for r, fy in first_year.items() if fy == y),
                     "effectiveClusters": round(1 / sum((v / tt) ** 2 for v in tcount.values()), 1) if tt else None})
    cites = sorted((c for c in U.cites if c is not None), reverse=True)
    tc = sum(cites)
    cite_conc = {"works": len(cites), "top1Share": pct(sum(cites[:max(1, len(cites) // 100)]), tc),
                 "top10Share": pct(sum(cites[:max(1, len(cites) // 10)]), tc),
                 "zeroShare": pct(sum(1 for c in cites if c == 0), len(cites))}
    users = defaultdict(list)
    for (i, j), r in routes.items():
        if r["kind"] == "use":
            users[j].append(i)
    uses_h = defaultdict(Counter)
    for j, us in users.items():
        for i in us:
            if U.date[i] and U.prec[i] != "year" and U.date[i].year >= 2024:
                uses_h[half(U.date[i])][j] += 1
    bench_h = []
    for h in sorted(uses_h):
        c = uses_h[h]
        t = sum(c.values())
        bench_h.append({"half": h, "uses": t, "distinct": len(c), "top1Share": pct(c.most_common(1)[0][1], t),
                        "top5Share": pct(sum(v for _, v in c.most_common(5)), t),
                        "top1": U.item(c.most_common(1)[0][0])})
    named = benchmark_names(U)
    old = [j for j in named.values() if U.date[j] and months(U.asof, U.date[j]) >= 6]
    reuse = {"benchmarks": len(old), "usedOnce": sum(1 for j in old if len(users.get(j, [])) >= 1),
             "usedThree": sum(1 for j in old if len(users.get(j, [])) >= 3),
             "benchmarkWorksByYear": [sum(1 for i in range(U.n) if U.form[i] == "benchmark" and U.year[i] == y) for y in years]}
    reuse["unusedPct"] = pct(reuse["benchmarks"] - reuse["usedOnce"], reuse["benchmarks"])
    # ---- industry, team size, code, venues
    types = {}
    if os.path.exists(ROR_CACHE):
        for line in open(ROR_CACHE, encoding="utf-8"):
            r = json.loads(line)
            if r.get("ror_id") and r.get("types"):
                types[r["ror_id"]] = r["types"]
    def sector(rid):
        t = types.get(rid) or []
        return "industry" if "company" in t else "academia" if "education" in t else "public" if set(t) & {"government", "facility", "nonprofit", "healthcare", "archive"} else None
    ind = []
    for y in years:
        ws = [i for i in range(U.n) if U.year[i] == y and any(sector(r) for r in U.pinst[i])]
        withco = [i for i in ws if any(sector(r) == "industry" for r in U.pinst[i])]
        only = [i for i in ws if all(sector(r) in ("industry", None) for r in U.pinst[i]) and withco and i in withco]
        ind.append({"year": y, "typed": len(ws), "industry": pct(len(withco), len(ws)), "industryOnly": pct(len(only), len(ws))})
    comp = Counter()
    for i in range(U.n):
        for r in U.pinst[i]:
            if sector(r) == "industry":
                comp[r] += 1
    ind_cluster = []
    for k in range(K):
        ws = [i for i in range(U.n) if k in U.ptopics[i] and U.year[i] and U.year[i] >= 2023 and any(sector(r) for r in U.pinst[i])]
        ind_cluster.append({"cluster": k, "typed": len(ws), "industry": pct(sum(1 for i in ws if any(sector(r) == "industry" for r in U.pinst[i])), len(ws))})
    team = []
    for y in years:
        ns = sorted(len(U.byid[U.ids[i]].get("authors") or []) for i in range(U.n) if U.year[i] == y and U.byid[U.ids[i]].get("authors"))
        team.append({"year": y, "median": median(ns), "large": pct(sum(1 for x in ns if x >= 10), len(ns))})
    code = [{"year": y, "share": pct(sum(1 for i in range(U.n) if U.year[i] == y and U.has_repo[i]), sum(1 for i in range(U.n) if U.year[i] == y))} for y in years]
    venues = []
    for y in years:
        pubs = [U.byid[U.ids[i]]["publication"] for i in range(U.n) if U.year[i] == y and U.byid[U.ids[i]]["publication"]["status"] in ("published", "accepted")]
        g = Counter(p.get("venueGroup") or "other" for p in pubs)
        venues.append({"year": y, "verified": len(pubs), **{k: pct(g[k], len(pubs)) for k in ("ml3", "security4", "journals", "other")}})
    out["concentration"] = {"institutions": conc, "citations": cite_conc, "benchmarkUses": bench_h, "benchmarkReuse": reuse,
                            "industry": ind, "industryByCluster": ind_cluster,
                            "topCompanies": [{"id": r, "name": U.inst_name.get(r, r), "works": n} for r, n in comp.most_common(12)],
                            "typedInstitutions": sum(1 for r in U.inst_name if sector(r)), "institutionsTotal": len(U.inst_name),
                            "rejectedMatches": len(U.rejected_teams), "rejectedWorks": U.rejected_works, "corrections": U.corrections,
                            "team": team, "code": code, "venues": venues, "years": years}
    return out


# ---------------------------------------------------------------------------------------------------------------- lenses
MODEL_FAMILIES = {"GPT": r"\bGPT-?(?:3\.5|4o?|4\.1|4-turbo|5)\b|\bChatGPT\b", "Claude": r"\bClaude\b", "Gemini": r"\bGemini\b",
                  "Llama": r"\bL[Ll]a[Mm][Aa][- ]?\d|\bLlama\b", "Qwen": r"\bQwen", "DeepSeek": r"\bDeepSeek", "Mistral": r"\bM[iy]stral\b|\bMixtral\b",
                  "Gemma": r"\bGemma\b", "GLM": r"\bGLM-?\d|\bChatGLM\b", "Kimi": r"\bKimi\b"}
SETTING_RULES = {  # keyword rules on title + abstract until the LLM facet labels replace them
    "web_browser": r"\b(web|browser|website|webpage)s?\b", "computer_gui_mobile": r"\b(GUI|computer[- ]use|desktop|mobile|smartphone|android|OS agent)s?\b",
    "coding": r"\b(cod(e|ing)|software engineering|SWE|programming|repository)\b", "mcp_skills": r"\b(MCP|model context protocol|agent skills?|skills?)\b",
    "rag_memory": r"\b(RAG|retrieval[- ]augmented|memory|memories)\b", "multi_agent": r"\b(multi[- ]agent|MAS|agent swarm|agents? communicat)",
    "embodied_robot": r"\b(robot\w*|embodied|manipulat\w+|humanoid)\b", "driving_drone": r"\b(driving|autonomous vehicle|drone|UAV)s?\b",
}


FACETS = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "facets", "all_v2.jsonl"))
# per-work labels on the two axes of the Positioning chapter (intake/screening/label_axes.py, rules axes-v3)
AXES = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "axes", "all_v3.claude-opus-5-5.jsonl"))
AXES2 = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "axes", "all_v3.deepseek-flash.jsonl"))
# what each model does in 2026 papers (intake/screening/label_roles.py, rules roles-v2): Opus, DeepSeek as a second reader
ROLES_LABELS = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "roles", "all_v2.claude-opus-5-5.jsonl"))
ROLES_LABELS2 = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "roles", "all_v2.deepseek-flash.jsonl"))
PROTOCOL_LABELS = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "protocol", "all_v1.claude-opus-5-5.jsonl"))
PROTOCOL_SECOND = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "protocol", "all_v1.deepseek-flash.jsonl"))
PROTOCOL_CANON = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "protocol", "canon_v1.json"))
CLAIMS_LABELS = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "claims", "all_v1.claude-opus-5-5.jsonl"))
CLAIMS_SECOND = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "claims", "all_v1.deepseek-flash.jsonl"))
CITES_CORPUS = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "cites", "corpus.jsonl"))
CITES_LABELS = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "cites", "all_v1.deepseek-flash.jsonl"))
CITES_VERIFY = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "cites", "verify_flag.claude-opus-5-5.jsonl"))
CITES_VERIFY_BG = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "cites", "verify_bg.claude-opus-5-5.jsonl"))
CITES_SECOND = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "cites", "pilot200.claude-opus-5-5.jsonl"))
# the paper's question structure (paper_analysis.py, owner 2026-10-21): protocol cards of the 2020-2025 defences and three readings
SCREEN = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening"))
PROTOCOL_OLDER = os.path.join(SCREEN, "protocol", "older_v1.claude-opus-5-5.jsonl")
NOVELTY = os.path.join(SCREEN, "novelty", "novelty_v1.jsonl")
BOUNDARY = os.path.join(SCREEN, "boundary", "boundary_v1.jsonl")
INHERIT = os.path.join(SCREEN, "inherit", "inherit_v1.jsonl")
OSS_DIR = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "oss"))
FACET_SETTINGS = ["web_browser", "computer_gui_mobile", "coding", "general_tool_assistant", "mcp_skills_ecosystem", "rag_memory_assistant",
                  "multi_agent", "embodied_robot", "driving_drone", "rl_simulator", "enterprise_workflow", "science_research"]
FACET_SURFACES = ["direct_instruction", "web_external_content", "tool_output", "tool_description_mcp_skills", "memory_retrieval",
                  "multi_agent_communication", "code_system_execution", "permissions_credentials", "training_data_weights",
                  "physical_sensing_environment", "human_interface_oversight"]
FACET_SOURCES = ["external_attacker", "malicious_user", "agent_itself", "non_adversarial"]
FACET_MECHANISMS = ["detection_filtering", "prompt_architecture_design", "training_alignment", "isolation_least_privilege",
                    "information_flow_formal", "runtime_monitoring", "human_approval"]
FACET_EVALS = ["static_dataset", "simulated_environment", "real_system", "no_experiment"]
# DeepSeek facet labels (intake/screening/label_facets.py, rules v2) against Opus on the same 97 pilot works
FACET_AUDIT = {"model": "deepseek-flash", "rules": "v2", "checkModel": "claude-opus-5-5", "checked": 97, "roleAgree": 81,
               "surfacesJaccard": 0.643, "settingsJaccard": 0.792, "riskJaccard": 0.708, "mechanismsJaccard": 0.854, "evaluationAgree": 81}


def load_facets(U):
    """Facet labels by work index, from the full labelling run (missing works fall back to the keyword rules)."""
    if not os.path.exists(FACETS):
        return {}
    out = {}
    for line in open(FACETS, encoding="utf-8"):
        r = json.loads(line)
        i = U.pos.get(r["id"])
        if i is not None and r.get("labels") and r["labels"].get("role_primary"):
            out[i] = r["labels"]
    return out


def write_facets(U):
    """Per-work facet labels for the page (dist/data/facets.json): option lists once, then per work the option indices,
    so the explorer and the time map can filter by role, entry channel, agent kind and risk source."""
    facets = load_facets(U)
    fields = {"role": ["attack", "defense", "benchmark", "measurement", "analysis_theory", "system_tool", "survey_position"],
              "surface": FACET_SURFACES, "setting": FACET_SETTINGS, "risk": FACET_SOURCES, "mechanism": FACET_MECHANISMS, "evaluation": FACET_EVALS}
    rows = {}
    for i, f in facets.items():
        roles = [f.get("role_primary")] + [r for r in f.get("role_secondary") or [] if r != f.get("role_primary")]
        rows[U.ids[i]] = [[fields["role"].index(r) for r in roles if r in fields["role"]],
                          [fields["surface"].index(x) for x in f.get("surfaces") or [] if x in fields["surface"]],
                          [fields["setting"].index(x) for x in f.get("settings") or [] if x in fields["setting"]],
                          [fields["risk"].index(x) for x in f.get("risk_sources") or [] if x in fields["risk"]],
                          [fields["mechanism"].index(x) for x in f.get("mechanisms") or [] if x in fields["mechanism"]],
                          fields["evaluation"].index(f["evaluation"]) if f.get("evaluation") in fields["evaluation"] else -1,
                          1 if f.get("adaptive_attacks") == "yes" else 0, 1 if f.get("release") else 0]
    with open(os.path.join(DATA, "facets.json"), "w", encoding="utf-8") as fh:
        json.dump({"fields": fields, "order": ["role", "surface", "setting", "risk", "mechanism", "evaluation", "adaptive", "release"],
                   "audit": FACET_AUDIT, "works": rows}, fh, separators=(",", ":"))


def lens_section(U, routes):
    """Data for the redesign's lenses: milestone dates per cluster (attack / defence / benchmark / survey; the page picks the
    threshold), attack-defence balance, models named in experiments (full texts), agent settings (keyword rules) and the
    comparability of defences over time. Attack and defence come from title keywords until the facet labels exist."""
    out = {}
    K = len(U.topics)
    facets = load_facets(U)
    if facets:
        def role(i, r):
            f = facets.get(i)
            return bool(f) and (f.get("role_primary") == r or r in (f.get("role_secondary") or []))
        kinds = {"attack": lambda i: role(i, "attack"), "defense": lambda i: role(i, "defense"),
                 "benchmark": lambda i: role(i, "benchmark") or (i not in facets and U.form[i] == "benchmark"),
                 "survey": lambda i: (facets.get(i) or {}).get("role_primary") == "survey_position" or (i not in facets and U.form[i] == "survey")}
    else:
        kinds = {
            "attack": lambda i: bool(ATTACK.search(U.title[i])) and not DEFENSE.search(U.title[i]) and U.form[i] != "benchmark",
            "defense": lambda i: bool(DEFENSE.search(U.title[i])) and U.form[i] == "method",
            "benchmark": lambda i: U.form[i] == "benchmark",
            "survey": lambda i: U.form[i] == "survey"}
    out["labels"] = {"source": "facet labels" if facets else "title keywords", "labelled": len(facets), "works": U.n, **FACET_AUDIT}
    ms = []
    for k in range(K):
        row = {"cluster": k}
        for name, f in kinds.items():
            row[name] = sorted(U.date[i].isoformat()[:7] for i in range(U.n) if k in U.ptopics[i] and U.date[i] and U.prec[i] != "year" and f(i))
        ms.append(row)
    out["milestones"] = {"basis": "facet labels" if facets else "title keywords (attack, defence) and paper form (benchmark, survey)", "rows": ms}
    bal = []
    for k in range(K):
        r = {"cluster": k}
        for lo, hi, key in ((0, 12, "recent"), (12, 24, "before")):
            mem = [i for i in range(U.n) if k in U.ptopics[i] and window(U, i, lo, hi)]
            r[key] = [sum(1 for i in mem if kinds["attack"](i)), sum(1 for i in mem if kinds["defense"](i)), sum(1 for i in mem if kinds["benchmark"](i))]
        bal.append(r)
    out["balance"] = bal
    # models named in the experiments (local full texts, before the reference list)
    pat = {k: re.compile(v) for k, v in MODEL_FAMILIES.items()}
    years = list(range(2023, U.asof.year + 1))
    by_year, n_year, by_c, n_c, any_year = defaultdict(Counter), Counter(), defaultdict(Counter), Counter(), Counter()
    for i in range(U.n):
        y = U.year[i]
        if y not in years:
            continue
        path = fulltext_path(U, i)
        if not path:
            continue
        any_year[y] += 1
        t = gzip.open(path, "rt", encoding="utf-8", errors="ignore").read()
        m = REFS_HEAD.search(t, len(t) // 3)
        body = t[:m.start()] if m else t
        fams = {k for k, p in pat.items() if p.search(body)}
        if not fams:
            continue
        n_year[y] += 1
        for f in fams:
            by_year[y][f] += 1
        for c in ("US", "CN"):
            if U.pcountry[i] == {c}:
                n_c[c] += 1
                for f in fams:
                    by_c[c][f] += 1
    out["models"] = {"years": years, "families": list(MODEL_FAMILIES), "papers": [n_year[y] for y in years], "fullTexts": [any_year[y] for y in years],
                     "share": {f: [pct(by_year[y][f], n_year[y]) for y in years] for f in MODEL_FAMILIES},
                     "byCountry": {c: {"papers": n_c[c], "share": {f: pct(by_c[c][f], n_c[c]) for f in MODEL_FAMILIES}} for c in ("US", "CN")}}
    # agent settings by half-year (keyword rules on title + abstract)
    tx = {}
    tpath = os.path.join(SM, "texts.jsonl")
    if os.path.exists(tpath):
        for line in open(tpath, encoding="utf-8"):
            r = json.loads(line)
            tx[r["id"]] = r["title"] + " . " + r["text"]
    rules = {k: re.compile(v, re.I if k not in ("mcp_skills",) else 0) for k, v in SETTING_RULES.items()}
    halves = sorted({half(U.date[i]) for i in range(U.n) if U.date[i] and U.prec[i] != "year" and U.date[i].year >= 2023})
    hs = {h: [i for i in range(U.n) if U.date[i] and U.prec[i] != "year" and half(U.date[i]) == h] for h in halves}
    out["settings"] = {"halves": halves, "works": [len(hs[h]) for h in halves], "basis": "keyword rules",
                       "share": {k: [pct(sum(1 for i in hs[h] if r.search(tx.get(U.ids[i], ""))), len(hs[h])) for h in halves] for k, r in rules.items()}}
    if facets:
        # label-based facets per half-year, over the labelled works of that half-year
        lab = {h: [i for i in hs[h] if i in facets] for h in halves}

        def shares(field, options, pool=None):
            res = {}
            for o in options:
                vals = []
                for h in halves:
                    ws = [i for i in lab[h] if pool is None or pool(i)]
                    v = facets
                    vals.append(pct(sum(1 for i in ws if o in (v[i].get(field) if isinstance(v[i].get(field), list) else [v[i].get(field)])), len(ws)) if len(ws) >= 20 else None)
                res[o] = vals
            return res
        out["settings"] = {"halves": halves, "works": [len(lab[h]) for h in halves], "basis": "facet labels", "share": shares("settings", FACET_SETTINGS)}
        out["surfaces"] = {"halves": halves, "works": [sum(1 for i in lab[h] if kinds["attack"](i)) for h in halves],
                           "share": shares("surfaces", FACET_SURFACES, pool=kinds["attack"])}
        out["risk"] = {"halves": halves, "share": shares("risk_sources", FACET_SOURCES)}
        out["evaluation"] = {"halves": halves, "share": shares("evaluation", FACET_EVALS, pool=lambda i: kinds["attack"](i) or kinds["defense"](i) or kinds["benchmark"](i))}
        defs = [i for i in facets if (facets[i].get("role_primary") == "defense")]
        rec_d = [i for i in defs if window(U, i, 0, 12)]
        bef_d = [i for i in defs if window(U, i, 12, 24)]
        mech = {}
        for o in FACET_MECHANISMS:
            mech[o] = [pct(sum(1 for i in bef_d if o in (facets[i].get("mechanisms") or [])), len(bef_d)), pct(sum(1 for i in rec_d if o in (facets[i].get("mechanisms") or [])), len(rec_d))]
        out["mechanisms"] = {"before": len(bef_d), "recent": len(rec_d), "share": mech}
        adapt = []
        for h in halves:
            d = [i for i in lab[h] if facets[i].get("role_primary") == "defense"]
            adapt.append({"half": h, "defenses": len(d), "yes": pct(sum(1 for i in d if facets[i].get("adaptive_attacks") == "yes"), len(d)) if len(d) >= 20 else None,
                          "ids": [U.item(i) for i in d if facets[i].get("adaptive_attacks") == "yes"][:200]})
        out["adaptive"] = {"byHalf": adapt, "overall": pct(sum(1 for i in defs if facets[i].get("adaptive_attacks") == "yes"), len(defs)), "defenses": len(defs),
                           "byCluster": sorted([{"cluster": k, "defenses": len(dk), "yes": pct(sum(1 for i in dk if facets[i].get("adaptive_attacks") == "yes"), len(dk))}
                                                for k in range(K) for dk in [[i for i in defs if k in U.ptopics[i]]] if len(dk) >= 25], key=lambda r: -(r["yes"] or 0))}
        out["release"] = {"years": years, "share": [pct(sum(1 for i in facets if U.year[i] == y and facets[i].get("release")), sum(1 for i in facets if U.year[i] == y)) for y in years]}
    # comparability of defences over time: share of defence pairs (same half-year) sharing at least one benchmark
    bench_of = defaultdict(set)
    for (i, j), r in routes.items():
        if r["kind"] == "use":
            bench_of[i].add(j)
    comp = []
    for h in halves:
        d = [i for i in hs[h] if kinds["defense"](i) and (facets or U.form[i] == "method") and bench_of[i]]
        pairs = [bool(bench_of[a] & bench_of[b]) for x, a in enumerate(d) for b in d[x + 1:]]
        comp.append({"half": h, "defenses": len(d), "pairShare": pct(sum(pairs), len(pairs)) if len(d) >= 8 else None})
    out["comparability"] = comp
    return out


def web_section(U, routes):
    hosts = Counter()
    for r in U.atlas["resources"]:
        u = r.get("url") or ""
        h = re.sub(r"^https?://(www\.)?", "", u).split("/")[0].lower()
        hosts["github.com" if h.endswith("github.com") or h.endswith("github.io") else "huggingface.co" if "huggingface" in h else "other"] += 1
    arx = sum(1 for pid in U.ids if U.byid[pid]["attributes"].get("arxiv_id"))
    unv = sum(1 for pid in U.ids if U.byid[pid]["publication"]["status"] == "unverified")
    oss = load_json("oss.json")
    linked = [r for r in oss["repos"] if r.get("papers")]
    return {"arxiv": arx, "arxivPct": pct(arx, U.n), "unverified": unv, "unverifiedPct": pct(unv, U.n),
            "resourceHosts": dict(hosts), "paperRepos": len(linked), "paperReposArchived": sum(1 for r in linked if r.get("archived")),
            "paperReposUnavailable": sum(1 for r in linked if r.get("unavailableSince")),
            "worksWithCode": sum(U.has_repo), "worksWithCodePct": pct(sum(U.has_repo), U.n)}


def fragmentation(U, routes, facets=None):
    """Defences in a cluster: how many benchmarks they are evaluated on and how often two defences share one."""
    bench_of = defaultdict(set)
    for (i, j), r in routes.items():
        if r["kind"] == "use":
            bench_of[i].add(j)
    out = []
    for k, name in enumerate(U.topics):
        is_def = (lambda i: i in facets and (facets[i].get("role_primary") == "defense" or "defense" in (facets[i].get("role_secondary") or []))) if facets \
            else (lambda i: U.form[i] == "method" and DEFENSE.search(U.title[i]))
        d = [i for i in range(U.n) if k in U.ptopics[i] and is_def(i) and bench_of[i]]
        if len(d) < 10:
            continue
        allb = Counter(j for i in d for j in bench_of[i])
        share = [bool(bench_of[a] & bench_of[b]) for x, a in enumerate(d) for b in d[x + 1:]]
        out.append({"cluster": k, "defenses": len(d), "benchmarks": len(allb), "topBenchmark": U.item(allb.most_common(1)[0][0]),
                    "topShare": pct(allb.most_common(1)[0][1], len(d)), "pairShare": pct(sum(share), len(share))})
    return out


def benchmark_table(U, routes, k=30):
    """The most used Atlas benchmarks: users, clusters the users come from, first use, and evidence sentences."""
    users = defaultdict(list)
    for (i, j), r in routes.items():
        if r["kind"] == "use":
            users[j].append(i)
    rows = []
    for j, us in sorted(users.items(), key=lambda kv: -len(kv[1]))[:k]:
        outside = [i for i in us if not set(U.ptopics[i]) & set(U.ptopics[j])]
        clusters = Counter(t for i in us for t in U.ptopics[i])
        dated = sorted((U.date[i], i) for i in us if U.date[i] and U.prec[i] != "year")
        recent = sorted(dated[-12:], key=lambda d: clean(routes[(d[1], j)]["evidence"]), reverse=True)[:3]
        ev = [{"user": U.item(i), "evidence": routes[(i, j)]["evidence"]} for _, i in sorted(recent)]
        rows.append({"id": U.item(j), "name": routes[(us[0], j)]["name"], "users": len(us), "usersOutside": len(outside),
                     "clusters": len(clusters), "topClusters": [t for t, _ in clusters.most_common(4)],
                     "firstUse": dated[0][0].isoformat() if dated else None, "userIds": [U.item(i) for i in us][:400], "evidence": ev})
    return rows


def hypotheses(rq1, rq2, rq3, rq4):
    """Status of each hypothesis on this snapshot. The rule behind each status is fixed here and shown on the page; a
    status is "supported so far" at best: these are observations on one snapshot, not tests with held-out data."""
    t = {r["ranker"]: r for r in rq1["pilot"]["table"]}
    sal, cit = t.get("salience") or {}, t.get("citations") or {}
    h = []
    if sal.get("recall50") is not None and cit.get("recall50") is not None:
        better = sal["recall50"] > cit["recall50"]
        newer = (sal.get("nova20") or 0) > (cit.get("nova20") or 0)
        h.append({"id": "H1", "status": "supported" if better and newer else "mixed" if better or newer else "notSupported",
                  "values": {"salienceRecall50": sal["recall50"], "citationRecall50": cit["recall50"], "salienceNova20": sal.get("nova20"),
                             "citationNova20": cit.get("nova20"), "bestRecall50": max(r["recall50"] or 0 for r in t.values()),
                             "surveys": rq1["pilot"]["surveys"]}})
    else:
        h.append({"id": "H1", "status": "untestable", "values": {}})
    h.append({"id": "H2a", "status": "supported" if len(rq2["h2a"]) >= 2 else "mixed" if rq2["h2a"] else "notSupported",
              "values": {"pairs": len(rq2["h2a"]), "of": len(rq2["pairs"]), "rhoSemanticCitation": rq2["correlation"].get("citeRatio|semantic")}})
    h.append({"id": "H2b", "status": "supported" if len(rq2["h2b"]) >= 2 else "mixed" if rq2["h2b"] else "notSupported",
              "values": {"pairs": len(rq2["h2b"]), "of": len(rq2["pairs"]), "rhoCitationResource": rq2["correlation"].get("citeRatio|resource")}})
    c = rq3["correlation"].get("works|suppliedOutside")
    ins = rq3["institutions"]
    ok = c is not None and c < 0.6 and len(ins["supplyNotOutput"]) >= 3
    h.append({"id": "H3", "status": "supported" if ok else "mixed" if c is not None and c < 0.8 else "notSupported",
              "values": {"rhoWorksSupply": c, "instOverlap": ins["overlapWorksSupply"], "instCorr": ins["corrWorksSupply"],
                         "supplyNotOutput": len(ins["supplyNotOutput"])}})
    lags = [r.get("benchLagMonths") for r in rq4["onset"] if r.get("benchLagMonths") is not None]
    late = sum(1 for x in lags if x >= 6)
    h.append({"id": "H4a", "status": "supported" if late >= 3 else "mixed" if late else "notSupported",
              "values": {"clustersLate6": late, "clusters": len(lags), "medianLag": r3(median(lags))}})
    hb = rq4["threads"]["h4b"]
    if hb["youngCross"] is None or hb["oldCross"] is None:
        h.append({"id": "H4b", "status": "untestable", "values": hb})
    else:
        d = hb["youngCross"] - hb["oldCross"]
        h.append({"id": "H4b", "status": "supported" if d >= 10 else "mixed" if d > 0 else "notSupported", "values": {**hb, "difference": r3(d)}})
    return h


def citation_contexts(U, write=True):
    """Citing sentences for citation routes (collect_citation_contexts.py): shards for the star map's paper view
    (dist/data/starmap-ctx-<n>.json, keyed by citing and cited star-map index) and coverage figures. Semantic Scholar has a
    sentence only where it parsed the citing paper; a route without one stays record-level, not unsupported."""
    path, meta_path = os.path.join(CG, "contexts.jsonl"), os.path.join(CG, "contexts-meta.json")
    for old in glob.glob(os.path.join(DATA, "starmap-ctx-*.json")) if write else []:  # report-only runs leave the shards alone
        os.remove(old)
    if not os.path.exists(path):
        return None
    sm = load_json("starmap.json")
    sm_pos = {pid: k for k, pid in enumerate(sm["ids"])}
    shard = sm["meta"].get("shardSize", 600)
    s2pid = {s.get("paperId"): i for i, s in enumerate(U.s2) if s.get("paperId")}
    shards = defaultdict(dict)
    intents = Counter()
    n = with_ctx = influential = 0
    method_in = Counter()
    for line in open(path, encoding="utf-8"):
        r = json.loads(line)
        i = U.pos.get(r["id"])
        if i is None:
            continue
        for x in r["refs"]:
            j = s2pid.get(x["paperId"])
            if j is None or j not in U.refs[i]:
                continue
            n += 1
            influential += bool(x["influential"])
            for it in x["intents"] or ["none"]:
                intents[it] += 1
            if "methodology" in (x["intents"] or []):
                method_in[j] += 1
            # the first citing sentence in English: paper-level data stays English (a Chinese drafting note left in one paper)
            sentence = next((c for c in x["contexts"] or [] if not CJK.search(c)), None)
            if sentence:
                with_ctx += 1
                a, b = sm_pos[U.ids[i]], sm_pos[U.ids[j]]
                code = "".join(c for c, k in (("m", "methodology"), ("r", "result"), ("b", "background")) if k in (x["intents"] or []))
                shards[a // shard].setdefault(str(a), {})[str(b)] = [EMAIL.sub("[e-mail removed]", sentence)[:300], code, int(bool(x["influential"]))]
    for k in range((len(sm["ids"]) + shard - 1) // shard if write else 0):  # every shard exists (empty until its citing works are fetched)
        d = shards.get(k, {})
        with open(os.path.join(DATA, f"starmap-ctx-{k}.json"), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, separators=(",", ":"))
    meta = json.load(open(meta_path)) if os.path.exists(meta_path) else {}
    return {"routes": n, "withSentence": with_ctx, "influential": influential, "intents": dict(intents), "shardSize": shard,
            "citingFetched": meta.get("citingWorksFetched"), "citingTotal": meta.get("citingWorksWithReferences"), "observedOn": meta.get("observedOn"),
            "methodologyTop": [[U.item(j), c] for j, c in method_in.most_common(15)]}


def star_bands(U, routes):
    """Per-work band signals for the star map (dist/data/starmap-bands.json), in starmap.json order: in-group citation
    percentile C^ (influence), bridging participation B, benchmark uses by other works (resource), months since first
    posted (latest) and the new-star flag. -1 = not observed (never zero)."""
    C = reference_groups(U, range(U.n))
    use = Counter(j for (i, j), r in routes.items() if r["kind"] == "use")
    sm_ids = load_json("starmap.json")["ids"]
    out = {"c": [], "b": [], "u": [], "age": [], "nova": []}
    for pid in sm_ids:
        i = U.pos[pid]
        b = participation(U, i)
        out["c"].append(round(100 * C[i]) if i in C else -1)
        out["b"].append(round(100 * b) if b is not None else -1)
        out["u"].append(use[i])
        out["age"].append(round(months(U.asof, U.date[i]), 1) if U.date[i] and U.prec[i] != "year" else -1)
        out["nova"].append(1 if U.is_new(i) else 0)
    out["meta"] = {"release": load_json("updates.json")["releases"][0]["release"], "asOf": U.asof.isoformat(), "novaMonths": NOVA_MONTHS,
                   "minGroup": MIN_GROUP, "group": "(cluster, year, form)"}
    with open(os.path.join(DATA, "starmap-bands.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, separators=(",", ":"))


def audit_summary(U, routes):
    """The benchmark-use spot check (research-paths/findings/benchmark-use-audit.json). Each judged sentence is
    re-evaluated against the current routes: a judged use counts only while it is still a use route, a judged mention
    only while it is still a mention, so a later rule change never reuses verdicts on routes it no longer produces."""
    path = os.path.join(HERE, "research-paths", "findings", "benchmark-use-audit.json")
    if not os.path.exists(path):
        return None
    a = json.load(open(path, encoding="utf-8"))

    def kind(x):
        i, j = U.pos.get(x["user"]), U.pos.get(x["benchmark"])
        r = routes.get((i, j)) if i is not None and j is not None else None
        return r["kind"] if r else None
    use = [x for r in a["rounds"] if r["kind"] == "use" for x in r["items"] if kind(x) == "use"]
    men = [x for r in a["rounds"] if r["kind"] == "mention" for x in r["items"] if kind(x) == "mention"]
    judged = sum(len(r["items"]) for r in a["rounds"])
    k, n = sum(1 for x in use if x["verdict"] == "use"), len(use)
    km, nm = sum(1 for x in men if x["verdict"] == "use"), len(men)
    return {"reviewer": a["reviewer"], "date": a["date"], "judged": judged, "stillApplicable": n + nm,
            "precision": pct(k, n), "precisionCI": wilson(k, n), "checked": n, "correct": k,
            "mentionsChecked": nm, "mentionsUse": km, "mentionUsePct": pct(km, nm),
            "wrong": [x for x in use if x["verdict"] != "use"]}



# ---------------------------------------------------------------------------------------------------------------- phase 3
TERM_ALIASES = {"context protocol": "mcp", "vla": "vision action", "rag": "retrieval augmented"}

def deeper_section(U, routes):
    """Second-round analyses (redesign phase 3): country share against influence within publication-year cohorts; who
    opened each cluster and who leads it now; how concentrated each cluster is by country; who builds on whom (one-way
    citation flows between clusters); the life of a benchmark (first outside use, time to five users, still in use);
    how fast new title terms spread across clusters."""
    out = {}
    K = len(U.topics)
    dated = [i for i in range(U.n) if U.date[i] and U.prec[i] != "year"]
    facets = load_facets(U)

    # ---- share against influence, by publication-year cohort (citations need time, so compare like with like)
    cohorts = [y for y in (2023, 2024, 2025) if y < U.asof.year]
    overall = Counter()
    for i in range(U.n):
        if U.year[i] and U.year[i] >= 2023 and U.pcountry[i]:
            for c in U.pcountry[i]:
                overall[c] += 1 / len(U.pcountry[i])
    top = [c for c, _ in overall.most_common(6)]
    rows = {c: [] for c in top}
    for y in cohorts:
        ws = [i for i in range(U.n) if U.year[i] == y and U.pcountry[i] and U.cites[i] is not None]
        if len(ws) < 100:
            continue
        cut = sorted((U.cites[i] for i in ws), reverse=True)[max(0, len(ws) // 10 - 1)]
        topd = [i for i in ws if U.cites[i] >= cut]
        tot_c = sum(U.cites[i] for i in ws) or 1
        tot_in = sum(len(U.cited_by[i]) for i in ws) or 1
        for c in top:
            cr = lambda i: (1 / len(U.pcountry[i])) if c in U.pcountry[i] else 0  # noqa: E731
            rows[c].append({"year": y, "works": len(ws), "workShare": pct(sum(cr(i) for i in ws), len(ws)),
                            "citeShare": pct(sum(cr(i) * U.cites[i] for i in ws), tot_c),
                            "top10Share": pct(sum(cr(i) for i in topd), len(topd)),
                            "atlasCiteShare": pct(sum(cr(i) * len(U.cited_by[i]) for i in ws), tot_in)})
    out["influence"] = {"countries": top, "cohorts": cohorts, "rows": rows}

    # ---- pioneers: the leader among a cluster's first 30 located works, and the leader of the last 12 months
    recent = {i for i in dated if window(U, i, 0, 12)}
    pioneers = []
    for k in range(K):
        ws = sorted((U.date[i], i) for i in dated if k in U.ptopics[i] and U.pcountry[i])
        if len(ws) < 60:
            continue
        first = [i for _, i in ws[:30]]
        now = [i for _, i in ws if i in recent]
        if len(now) < 30:
            continue
        def lead(ids):
            cnt = Counter()
            for i in ids:
                for c in U.pcountry[i]:
                    cnt[c] += 1 / len(U.pcountry[i])
            (c, v), = cnt.most_common(1)
            return c, pct(v, len(ids)), cnt
        fc, fs, fcnt = lead(first)
        nc, ns, ncnt = lead(now)
        pioneers.append({"cluster": k, "from": ws[0][0].isoformat()[:7], "to": ws[29][0].isoformat()[:7], "first": fc, "firstShare": fs,
                         "firstIds": [U.item(i) for i in first], "now": nc, "nowShare": ns, "nowWorks": len(now),
                         "firstNowShare": pct(ncnt[fc], len(now)), "nowFirstShare": pct(fcnt[nc], len(first))})
    out["pioneers"] = pioneers

    # ---- concentration by country per cluster, works since 2023
    conc = []
    for k in range(K):
        ws = [i for i in range(U.n) if k in U.ptopics[i] and U.year[i] and U.year[i] >= 2023 and U.pcountry[i]]
        if len(ws) < 50:
            continue
        cnt = Counter()
        for i in ws:
            for c in U.pcountry[i]:
                cnt[c] += 1 / len(U.pcountry[i])
        shares = [v / len(ws) for v in cnt.values()]
        (c1, v1), = cnt.most_common(1)
        conc.append({"cluster": k, "works": len(ws), "hhi": round(sum(s * s for s in shares), 3), "countries": len(cnt),
                     "top": c1, "topShare": pct(v1, len(ws)), "international": pct(sum(1 for i in ws if len(U.pcountry[i]) >= 2), len(ws))})
    out["geoConcentration"] = conc

    # ---- who builds on whom: citations between clusters, each link split over the citing and cited clusters
    flow = defaultdict(float)
    cited_in = defaultdict(Counter)
    for i, j in U.links:
        a, b = U.ptopics[i], U.ptopics[j]
        if not a or not b:
            continue
        w = 1 / (len(a) * len(b))
        for x in a:
            for y in b:
                if x != y:
                    flow[(x, y)] += w
                    cited_in[(x, y)][j] += 1
    pairs = []
    for x in range(K):
        for y in range(x + 1, K):
            f, g = flow[(x, y)], flow[(y, x)]
            if f + g < 40:
                continue
            src, dst, hi, lo = (x, y, f, g) if f >= g else (y, x, g, f)
            pairs.append({"from": src, "to": dst, "forward": round(hi, 1), "back": round(lo, 1), "ratio": round((hi + 1) / (lo + 1), 2),
                          "examples": [[U.item(j), n] for j, n in cited_in[(src, dst)].most_common(3)]})
    pairs.sort(key=lambda p: -p["ratio"] * math.log(p["forward"] + p["back"]))
    supply = []
    for k in range(K):
        inn = sum(v for (x, y), v in flow.items() if y == k)
        outf = sum(v for (x, y), v in flow.items() if x == k)
        ages = [months(U.asof, U.date[i]) for i in dated if k in U.ptopics[i]]
        if inn + outf >= 50:
            supply.append({"cluster": k, "in": round(inn, 1), "out": round(outf, 1), "net": round((inn - outf) / (inn + outf), 3),
                           "medianAgeMonths": round(median(ages), 1) if ages else None})
    supply.sort(key=lambda r: -r["net"])
    out["buildsOn"] = {"pairs": pairs[:12], "pairsConsidered": len(pairs), "supply": supply}

    # ---- the life of a benchmark: uses found in full texts, users dated by month or day
    uses = defaultdict(list)
    for (i, j), r in routes.items():
        if r["kind"] == "use" and U.date[i] and U.prec[i] != "year":
            uses[j].append(i)
    life = []
    for j, us in uses.items():
        if len(us) < 5 or not U.date[j]:
            continue
        ds = sorted(U.date[i] for i in us)
        outside = sorted(U.date[i] for i in us if not set(U.ptopics[i]) & set(U.ptopics[j]))
        lag = lambda d: round(max(0, months(d, U.date[j])), 1)  # noqa: E731
        last6 = sum(1 for d in ds if months(U.asof, d) < 6)
        prev6 = sum(1 for d in ds if 6 <= months(U.asof, d) < 12)
        age = round(months(U.asof, U.date[j]), 1)
        life.append({"id": U.item(j), "name": routes[(us[0], j)]["name"], "users": len(us), "ageMonths": age,
                     "firstUse": lag(ds[0]), "fifthUse": lag(ds[4]), "firstOutside": lag(outside[0]) if outside else None,
                     "approxDate": U.prec[j] == "year", "last6": last6, "prev6": prev6, "lastUseMonthsAgo": round(months(U.asof, ds[-1]), 1), "userIds": [U.item(i) for i in us][:200]})
    old = [b for b in life if b["ageMonths"] >= 18]
    out["benchmarkLife"] = {
        "benchmarks": len(life), "medianFirstUse": median([b["firstUse"] for b in life]), "medianFifthUse": median([b["fifthUse"] for b in life]),
        "medianFirstOutside": median([b["firstOutside"] for b in life if b["firstOutside"] is not None]),
        "withOutside": sum(1 for b in life if b["firstOutside"] is not None),
        "oldBenchmarks": len(old), "oldStillUsed": sum(1 for b in old if b["last6"] > 0), "oldGrowing": sum(1 for b in old if b["last6"] > b["prev6"]),
        "fastest": sorted(life, key=lambda b: (b["fifthUse"], -b["users"]))[:6],
        "faded": sorted([b for b in old if b["lastUseMonthsAgo"] >= 9], key=lambda b: -b["users"])[:6],
        "rows": sorted(life, key=lambda b: -b["users"])[:40]}

    # ---- industry: share of works against share of the most-cited tenth, and where academic works send their references
    types = {}
    if os.path.exists(ROR_CACHE):
        for line in open(ROR_CACHE, encoding="utf-8"):
            r = json.loads(line)
            if r.get("ror_id") and r.get("types"):
                types[r["ror_id"]] = r["types"]
    typed = {i for i in range(U.n) if any(types.get(r) for r in U.pinst[i])}
    ind = {i for i in typed if any("company" in types.get(r, []) for r in U.pinst[i])}
    rows = []
    for y in cohorts:
        ws = [i for i in typed if U.year[i] == y and U.cites[i] is not None]
        if len(ws) < 100:
            continue
        cut = sorted((U.cites[i] for i in ws), reverse=True)[max(0, len(ws) // 10 - 1)]
        topd = [i for i in ws if U.cites[i] >= cut]
        rows.append({"year": y, "works": len(ws), "workShare": pct(sum(i in ind for i in ws), len(ws)), "top10Share": pct(sum(i in ind for i in topd), len(topd)),
                     "citeShare": pct(sum(U.cites[i] for i in ws if i in ind), sum(U.cites[i] for i in ws) or 1)})
    fl = Counter(("I" if i in ind else "A", "I" if j in ind else "A") for i, j in U.links if i in typed and j in typed)
    top_ind = sorted(ind, key=lambda i: -(U.cites[i] or 0))[:8]
    out["industry"] = {"typed": len(typed), "industryWorks": len(ind), "cohorts": rows,
                       "academicRefsToIndustry": pct(fl[("A", "I")], fl[("A", "I")] + fl[("A", "A")]),
                       "industryRefsToIndustry": pct(fl[("I", "I")], fl[("I", "I")] + fl[("I", "A")]),
                       "industryShareTyped": pct(len(ind), len(typed)), "topCited": [U.item(i) for i in top_ind]}

    # ---- newcomers: works whose institutions all appear for the first time that year, against works whose institutions
    # all appeared before; how much of the field they cite and whether they cite one of its 50 most-cited works up to 2023
    first_year = {}
    for i in sorted((i for i in range(U.n) if U.year[i]), key=lambda i: U.year[i]):
        for r in U.pinst[i]:
            first_year.setdefault(r, U.year[i])
    classics = set(sorted((j for j in range(U.n) if U.year[j] and U.year[j] <= 2023 and U.cites[j] is not None), key=lambda j: -U.cites[j])[:50])
    newc = []
    for y in (U.asof.year - 1, U.asof.year):
        ws = [i for i in range(U.n) if U.year[i] == y and U.pinst[i] and U.ref_listed[i]]
        groups = {"new": [i for i in ws if all(first_year.get(r) == y for r in U.pinst[i])],
                  "established": [i for i in ws if all((first_year.get(r) or y) < y for r in U.pinst[i])]}
        for name, g in groups.items():
            newc.append({"year": y, "group": name, "works": len(g), "anyAtlasRef": pct(sum(1 for i in g if U.refs[i]), len(g)),
                         "meanAtlasRefs": round(sum(len(U.refs[i]) for i in g) / max(1, len(g)), 1),
                         "citesClassic": pct(sum(1 for i in g if U.refs[i] & classics), len(g)),
                         "ids": [U.item(i) for i in g][:200] if name == "new" else []})
    out["newcomers"] = {"rows": newc, "classics": [U.item(j) for j in sorted(classics, key=lambda j: -U.cites[j])]}

    # ---- global: the two largest producers, who is rising, how many countries take part
    years = list(range(2020, U.asof.year + 1))
    usCn = []
    for y in years:
        ws = [i for i in range(U.n) if U.year[i] == y and U.pcountry[i]]
        cn = [i for i in ws if "CN" in U.pcountry[i]]
        us = [i for i in ws if "US" in U.pcountry[i]]
        both = [i for i in ws if {"US", "CN"} <= U.pcountry[i]]
        usCn.append({"year": y, "located": len(ws), "cn": len(cn), "us": len(us), "both": len(both),
                     "cnWithUs": pct(len(both), len(cn)), "usWithCn": pct(len(both), len(us)),
                     "cnDomestic": pct(sum(1 for i in cn if U.pcountry[i] == {"CN"}), len(cn)),
                     "usDomestic": pct(sum(1 for i in us if U.pcountry[i] == {"US"}), len(us)),
                     "bothIds": [U.item(i) for i in both][:200]})
    partners = {}
    for c in ("CN", "US"):
        for span, lo, hi in (("before", 2020, 2023), ("recent", 2025, U.asof.year)):
            cnt, n = Counter(), 0
            for i in range(U.n):
                if U.year[i] and lo <= U.year[i] <= hi and c in U.pcountry[i] and len(U.pcountry[i]) >= 2:
                    n += 1
                    cnt.update(U.pcountry[i] - {c})
            partners[f"{c}_{span}"] = {"works": n, "top": [[k, pct(v, n)] for k, v in cnt.most_common(6)]}
    full = [y for y in years if y < U.asof.year][-2:]
    cy = defaultdict(Counter)
    for i in range(U.n):
        if U.year[i] in years and U.pcountry[i]:
            for c in U.pcountry[i]:
                cy[U.year[i]][c] += 1 / len(U.pcountry[i])
    a, b = full
    rising = sorted(([c, round(cy[a][c], 1), round(cy[b][c], 1), round(cy[b][c] / cy[a][c], 2)] for c in cy[a] if cy[a][c] >= 15), key=lambda r: -r[3])
    out["global"] = {"usCn": usCn, "partners": partners, "growthYears": full, "rising": rising[:10],
                     "fieldGrowth": round(sum(cy[b].values()) / max(1, sum(cy[a].values())), 2),
                     "countries": [{"year": y, "countries": sum(1 for v in cy[y].values() if v > 0),
                                    "effective": round(1 / sum((v / sum(cy[y].values())) ** 2 for v in cy[y].values()), 1) if cy[y] else None} for y in years]}

    # ---- where the field publishes: venue groups over time and per cluster (verified publications)
    def pubs_of(ws):
        return [U.byid[U.ids[i]]["publication"] for i in ws if U.byid[U.ids[i]]["publication"]["status"] in ("published", "accepted")]
    groups = ("ml3", "security4", "journals", "other")
    vy = []
    for y in years:
        ps = pubs_of([i for i in range(U.n) if U.year[i] == y])
        g = Counter(p.get("venueGroup") or "other" for p in ps)
        vy.append({"year": y, "verified": len(ps), **{k: pct(g[k], len(ps)) for k in groups}})
    vc = []
    for k in range(K):
        ws = [i for i in range(U.n) if k in U.ptopics[i] and U.year[i] and U.year[i] >= 2024]
        ps = pubs_of(ws)
        if len(ps) < 50:
            continue
        g = Counter(p.get("venueGroup") or "other" for p in ps)
        vc.append({"cluster": k, "verified": len(ps), **{x: pct(g[x], len(ps)) for x in groups},
                   "securityIds": [U.item(i) for i in ws if U.byid[U.ids[i]]["publication"].get("venueGroup") == "security4"][:120]})
    out["venues"] = {"byYear": vy, "byCluster": vc}

    # ---- team size: works with ten or more authors, and their share of the most-cited tenth
    tm = []
    for y in years:
        ws = [i for i in range(U.n) if U.year[i] == y and U.byid[U.ids[i]].get("authors")]
        big = lambda i: len(U.byid[U.ids[i]]["authors"]) >= 10  # noqa: E731
        row = {"year": y, "works": len(ws), "bigShare": pct(sum(1 for i in ws if big(i)), len(ws)),
               "medianAuthors": median([len(U.byid[U.ids[i]]["authors"]) for i in ws])}
        cw = [i for i in ws if U.cites[i] is not None]
        if y in cohorts and len(cw) >= 100:
            cut = sorted((U.cites[i] for i in cw), reverse=True)[max(0, len(cw) // 10 - 1)]
            topd = [i for i in cw if U.cites[i] >= cut]
            row["bigTop10Share"] = pct(sum(1 for i in topd if big(i)), len(topd))
            row["bigIndustry"] = pct(sum(1 for i in cw if big(i) and i in ind), sum(1 for i in cw if big(i)))
        tm.append(row)
    out["teams"] = {"rows": tm, "bigIds": [U.item(i) for i in sorted((i for i in range(U.n) if U.byid[U.ids[i]].get("authors") and len(U.byid[U.ids[i]]["authors"]) >= 10 and U.cites[i] is not None), key=lambda i: -U.cites[i])[:40]]}

    # ---- diversity: effective number of clusters and of countries per year (inverse Simpson on fractional credit)
    div = []
    for y in years:
        cnt = Counter()
        for i in range(U.n):
            if U.year[i] == y and U.ptopics[i]:
                for k in U.ptopics[i]:
                    cnt[k] += 1 / len(U.ptopics[i])
        tot = sum(cnt.values())
        div.append({"year": y, "clusters": round(1 / sum((v / tot) ** 2 for v in cnt.values()), 1) if tot else None,
                    "countries": next(r["effective"] for r in out["global"]["countries"] if r["year"] == y)})
    out["diversity"] = div

    # ---- one field or two: k-means (k = 2) on the SPECTER2 vectors themselves, so the split does not depend on any drawing;
    # citations within and across the two groups against what group sizes alone would give; works at the boundary (the
    # smallest margin between the two centroids) and the works most cited across; the shape of the 3-D sky
    from scipy.cluster.vq import kmeans2
    X = U.emb / np.linalg.norm(U.emb, axis=1, keepdims=True)
    cent, lab = kmeans2(X.astype(np.float64), 2, minit="++", seed=SEED)
    phys = [sum(1 for i in range(U.n) if lab[i] == g and (U.tidx.get("Embodied and physical-world safety") in U.ptopics[i] or U.tidx.get("Safe reinforcement learning") in U.ptopics[i])) / max(1, int(np.sum(lab == g))) for g in (0, 1)]
    ctrl = int(np.argmax(phys))  # the group of control, robotics and safe RL; the other is the LLM-agent group
    grp = np.where(lab == ctrl, 1, 0)  # 0 = LLM agents, 1 = control and robotics
    cn = cent / np.linalg.norm(cent, axis=1, keepdims=True)
    sim = X @ cn.T
    margin = np.abs(sim[:, 0] - sim[:, 1])
    edge = set(np.argsort(margin)[:max(1, int(round(U.n * 0.015)))].tolist())
    fl = Counter((int(grp[i]), int(grp[j])) for i, j in U.links)
    tot = sum(fl.values()) or 1
    share = [float(np.mean(grp == g)) for g in (0, 1)]
    cross = [(i, j) for i, j in U.links if grp[i] != grp[j]]
    anc = Counter(j for i, j in cross)
    def side(g):
        ws = [i for i in range(U.n) if grp[i] == g]
        tc = Counter(t for i in ws for t in U.ptopics[i])
        yrs = [U.year[i] for i in ws if U.year[i]]
        st = Counter(x for i in ws if facets.get(i) for x in facets[i].get("settings") or []) if facets else Counter()
        lab_n = sum(1 for i in ws if facets.get(i)) if facets else 0
        return {"works": len(ws), "share": pct(len(ws), U.n), "since2025": pct(sum(1 for y in yrs if y >= 2025), len(yrs)), "medianYear": median(yrs),
                "topics": [[k, pct(v, len(ws))] for k, v in tc.most_common(6)], "settings": [[k, pct(v, lab_n)] for k, v in st.most_common(5)],
                "top": [U.item(i) for i in sorted(ws, key=lambda i: -(U.cites[i] or 0))[:5]]}
    sky3 = os.path.join(DATA, "starmap-3d.json")
    shape = None
    if os.path.exists(sky3):
        sm_ids = json.load(open(os.path.join(DATA, "starmap.json"), encoding="utf-8"))["ids"]
        xyz = np.array([v if v else [0, 0, 0] for v in json.load(open(sky3))["xyz"]], dtype=float)
        c = xyz - xyz.mean(0)
        sv = np.linalg.svd(c, compute_uv=False) ** 2
        r = np.linalg.norm(c, axis=1)
        from scipy.spatial import cKDTree
        dd, _ = cKDTree(xyz).query(xyz, k=11)
        lone = dd[:, 1:].mean(1)
        shape = {"variance": [round(float(v), 3) for v in sv / sv.sum()], "farthest": [sm_ids[i] for i in np.argsort(-r)[:10]],
                 "loneliest": [sm_ids[i] for i in np.argsort(-lone)[:10]]}
    out["traditions"] = {
        "groups": [side(0), side(1)],
        "citations": {"within": [pct(fl[(0, 0)], tot), pct(fl[(1, 1)], tot)], "llmCitesControl": pct(fl[(0, 1)], tot), "controlCitesLlm": pct(fl[(1, 0)], tot),
                      "cross": pct(len(cross), tot), "expectedCross": round(200 * share[0] * share[1], 1), "links": tot},
        "boundary": {"works": len(edge), "share": pct(len(edge), U.n), "crossTouching": pct(sum(1 for i, j in cross if i in edge or j in edge), len(cross)),
                     "topics": [[k, pct(v, len(edge))] for k, v in Counter(t for i in edge for t in U.ptopics[i]).most_common(6)],
                     "ids": [U.item(i) for i in sorted(edge, key=lambda i: -(U.cites[i] or 0))]},
        "ancestors": [[U.item(j), n, int(grp[j])] for j, n in anc.most_common(8)],
        "shape": shape}

    # ---- new ideas in titles: two-word terms and acronyms first seen (third title) since 2023; months from then until
    # they are used (two titles or more) in 3, 5 and 10 clusters
    vocab = {t.lower() for i in dated for t in TERM.findall(U.title[i].replace("-", " "))}
    singular = {w: w[:-1] for w in vocab if w.endswith("s") and not w.endswith("ss") and w[:-1] in vocab}
    tset, case = {}, defaultdict(Counter)
    for i in dated:
        tset[i], cs = title_terms(U.title[i], singular)
        for low, t in cs.items():
            case[low][t] += 1
    acronym = lambda t: len(t) >= 2 and case[t].most_common(1)[0][0].isupper()  # noqa: E731
    by_term = defaultdict(list)
    for i in sorted(dated, key=lambda i: U.date[i]):
        for t in tset[i]:
            if " " in t or acronym(t):
                by_term[t].append(i)
    # an acronym and its spelled-out form are one idea
    for alias, main in TERM_ALIASES.items():
        if alias in by_term and main in by_term:
            by_term[main] = sorted(set(by_term[main]) | set(by_term.pop(alias)), key=lambda i: U.date[i])
    # not new: three or more titles before 2023, counting works dated only by year
    old = Counter(t for i in range(U.n) if U.year[i] and U.year[i] < 2023 for t in title_terms(U.title[i], singular)[0])
    diff = []
    for t, ids in by_term.items():
        if len(ids) < 25 or U.date[ids[2]] < dt.date(2023, 1, 1) or old[t] >= 3:
            continue
        start, seen, reach = U.date[ids[2]], Counter(), {}
        for i in ids:
            for k in U.ptopics[i]:
                seen[k] += 1
                if seen[k] == 2:
                    n = sum(1 for v in seen.values() if v >= 2)
                    for m in (3, 5, 10):
                        if n >= m and m not in reach:
                            reach[m] = round(max(0, months(U.date[i], start)), 1)
        # the label as titles write it: the two words with up to two left-out words between them ("Chain-of-Thought")
        words = t.split()
        pat = re.compile(r"\b" + r"\w*\W+(?:\w{1,12}\W+){0,2}?".join(re.escape(w) for w in words) + r"\w*", re.I)
        forms = Counter(m.group(0) for i in ids[:60] for m in [pat.search(U.title[i])] if m)
        label = forms.most_common(1)[0][0] if forms else " ".join(case[w].most_common(1)[0][0] if case[w] else w for w in words)
        diff.append({"term": t, "label": label, "works": len(ids), "start": start.isoformat()[:7], "clusters": sum(1 for v in seen.values() if v >= 2),
                     "to3": reach.get(3), "to5": reach.get(5), "to10": reach.get(10), "ids": [U.item(i) for i in ids]})
    # one entry per idea: drop a term sharing a word with a listed term that has more works, or whose titles are mostly
    # already counted under one (MCP and "Model Context Protocol")
    diff.sort(key=lambda d: -d["works"])
    kept = []
    for d in diff:
        if any(set(d["term"].split()) & set(k["term"].split()) or len(set(d["ids"]) & set(k["ids"])) >= len(d["ids"]) / 2 for k in kept):
            continue
        kept.append(d)
    for d in kept:
        d["ids"] = d["ids"][:200]
    early = [d["to10"] for d in kept if d["start"] < "2025" and d["to10"] is not None]
    late = [d["to10"] for d in kept if d["start"] >= "2025" and d["to10"] is not None]
    out["diffusion"] = {"terms": kept[:14], "considered": len(kept), "medianTo5": median([d["to5"] for d in kept if d["to5"] is not None]),
                        "to10Before2025": [median(early), len(early), sum(1 for d in kept if d["start"] < "2025")],
                        "to10Since2025": [median(late), len(late), sum(1 for d in kept if d["start"] >= "2025")]}
    return out


_MODULES = {}


def local_module(name):
    """A module next to this file (the platform folder is off sys.path here, see the top of the file). Loaded once, so a
    module's cache (models_analysis.CACHE, read by the evidence board) is the one its own section filled."""
    if name not in _MODULES:
        import importlib.util
        spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + ".py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _MODULES[name] = mod
    return _MODULES[name]


def write_benchmark_routes(U, routes):
    # benchmark routes with their evidence, for the snapshot package and later audits (local; quotes stay short)
    os.makedirs(os.path.join(HERE, "research-paths", "findings"), exist_ok=True)
    with open(os.path.join(HERE, "research-paths", "findings", "benchmark-routes.jsonl"), "w", encoding="utf-8") as f:
        for (i, j), r in sorted(routes.items()):
            f.write(json.dumps({"user": U.item(i), "benchmark": U.item(j), "name": r["name"], "kind": r["kind"], "evidence": r["evidence"]},
                               ensure_ascii=False) + "\n")


def module_records(U, out):
    """item-level records kept by the tail and trajectory sections (F8, F11) and the facet labels behind F5; removed from the report"""
    ev = local_module("evidence_analysis")
    day = lambda i: U.date[i].isoformat() if i is not None and U.date[i] else None
    recs = {}
    facets = load_facets(U)
    recs["F5"] = ev._records(["work", "工作"], ["Facet labels: DeepSeek reads each title and abstract (rules v2); attack entry points are read for attack papers.", "分面标签：DeepSeek 按规则读每篇标题与摘要（规则 v2）；攻击入口只对攻击论文读取。"],
                             [["role", "Contribution", "贡献类型", "text"], ["settings", "Agent settings", "智能体场景", "list"], ["surfaces", "Attack entry points", "攻击入口", "list"]],
                             [[U.ids[i], day(i), [f.get("role_primary") or "", ", ".join(f.get("settings") or []), ", ".join(f.get("surfaces") or []) if f.get("role_primary") == "attack" else ""], None, []]
                              for i, f in sorted(facets.items()) if f])
    op = (out.get("tail") or {}).get("open") or {}
    rows8 = (op.get("stats") or {}).pop("_records", None)
    if rows8:
        recs["F8"] = ev._records(["later work that follows up a recurring open problem", "跟进反复提出的开放问题的后来工作"],
                                 ["Open problems read from the limitation and future-work passages (DeepSeek, verbatim) and grouped at SPECTER2 cosine 0.80; a follow-up cites a raising paper and is close in content; Claude Opus 5.5 reads its title and abstract for what it does with the problem.",
                                  "开放问题读自“局限 / 未来工作”段落（DeepSeek，逐字引用），按 SPECTER2 相似度 0.80 归组；后续工作引用了提出论文且内容接近；Claude Opus 5.5 读它的标题与摘要，判断它对问题做了什么。"],
                                 [["problem", "Open problem", "开放问题", "text"], ["raisedBy", "Raised by (papers)", "提出论文数", "num"], ["takesUp", "Takes it up", "是否接手", "text"], ["form", "Form of the answer", "回应形式", "text"]],
                                 [[r["follow"], day(U.pos.get(r["follow"])), [r["problem"], r["papers"], r["takes_up"], r["form"]], r.get("evidence"), []] for r in rows8])
    tr = out.get("trajectory") or {}
    rows11 = (tr.get("cold") or {}).pop("_records", None)
    if rows11:
        lines = tr.get("lines") or []
        lab = lambda k: (lines[k].get("label") if k < len(lines) and isinstance(lines[k], dict) else None) or f"line {k}"
        recs["F11"] = ev._records(["research line (candidate cluster)", "研究线（候选星团）"],
                                  ["Research lines found from paper content; cold = the smaller half of the tail at a quarter; the head = the largest lines holding half of all works.", "研究线根据论文内容自动发现；冷门 = 某季度长尾里较小的一半；头部 = 合计占一半工作的那些最大的研究线。"],
                                  [["line", "Research line", "研究线", "text"], ["firstSeen", "First seen in the tail", "首次出现在长尾", "text"], ["firstGroup", "Then", "当时", "text"],
                                   ["enteredHead", "Entered the head", "进入头部", "text"], ["enteredFrom", "Entered from", "进入时来自", "text"]],
                                  [[f"L{r['line']}", None, [lab(r["line"]), r["firstSeen"], r["firstGroup"], r.get("enteredHead") or "", r.get("enteredFrom") or ""], None, []] for r in rows11])
    rows12 = (tr.get("cold") or {}).pop("_records12", None)
    if rows12:
        lines = tr.get("lines") or []
        lab = lambda k: (lines[k].get("label") if k < len(lines) and isinstance(lines[k], dict) else None) or f"line {k}"
        feats = [f for f in rows12[0] if f not in ("line", "origin", "up")]
        recs["F12"] = ev._records(["cold research line at a quarter", "某季度的冷门研究线"],
                                  ["Signals measured on each cold line at each quarter from 2024-01, using only citations made by then; outcome = in the head 12 months later.", "从 2024-01 起每个季度，对每条冷门研究线测量信号（只用当时已有的引用）；结果 = 12 个月后是否在头部。"],
                                  [["line", "Research line", "研究线", "text"], ["quarter", "Quarter", "季度", "text"], ["up", "In the head a year later", "一年后进入头部", "text"]] + [[f, *FEATURE_NAMES.get(f, (f, f)), "num"] for f in feats],
                                  [[f"L{r['line']}@{r['origin']}", r["origin"] + "-01", [lab(r["line"]), r["origin"], "yes" if r["up"] else "no", *[r[f] for f in feats]], None, []] for r in rows12])
    return recs


FEATURE_NAMES = {"headCites": ("Cited by head lines", "已被头部研究线引用"), "inCites": ("Cited by other lines, per work", "被其他研究线引用（每篇）"),
                 "institutions": ("Institutions per work", "每篇的机构数"), "clusters": ("Clusters reached", "横跨的星团数"), "code": ("Works with code", "有代码的比例"),
                 "momentum": ("Last six months on the six before", "近 6 个月对前 6 个月"), "growth": ("Growth on the year before", "比前一年的增长"), "youth": ("Months since first work (negative)", "出现至今的月数（取负）"),
                 "works": ("Works in the last 12 months", "近 12 个月工作数")}


def write_records(records, folder, meta):
    """data/records/<F>.json, one file per question, loaded only when a reader opens a card's record"""
    if os.path.isdir(folder):
        shutil.rmtree(folder)
    os.makedirs(folder)
    index = {}
    for f, r in sorted(records.items()):
        r = {**r, "question": f, "analysisVersion": meta.get("analysisVersion"), "release": meta.get("release")}
        with open(os.path.join(folder, f"{f}.json"), "w", encoding="utf-8") as fh:
            json.dump(r, fh, ensure_ascii=False, separators=(",", ":"))
        index[f] = {"rows": len(r["rows"]), "unit": r["unit"]}
    with open(os.path.join(folder, "index.json"), "w", encoding="utf-8") as fh:
        json.dump({"analysisVersion": meta.get("analysisVersion"), "release": meta.get("release"), "questions": index}, fh, ensure_ascii=False, indent=1)
    print("records", len(records), "questions,", sum(v["rows"] for v in index.values()), "rows ->", folder, flush=True)


def paper_part(U, routes, out):
    pr, ci, pa = local_module("protocol_analysis"), local_module("cites_analysis"), local_module("position_analysis")
    both = {**pr._load(PROTOCOL_LABELS), **pr._load(PROTOCOL_OLDER)}  # 2026 cards and the 2020-2025 defences, same rules
    prot = pr._filled(pr._judgecheck(pr._adaptive(both, PROTOCOL_LABELS), PROTOCOL_LABELS), os.path.join(os.path.dirname(PROTOCOL_LABELS), "fill_v1.jsonl"))
    chains = pr._load(os.path.join(os.path.dirname(PROTOCOL_LABELS), "chains_v2.jsonl"))
    items = {json.loads(l)["id"]: json.loads(l) for l in open(CITES_CORPUS, encoding="utf-8")}
    labels = {**ci._load(CITES_LABELS), **ci._load(CITES_VERIFY), **ci._load(CITES_VERIFY_BG)}
    works = {}
    for line in open(os.path.join(CG, "works.jsonl"), encoding="utf-8"):
        r = json.loads(line)
        works[r["id"]] = r
    axes = {U.pos[k]: v for k, v in pa.load_axes(AXES).items() if k in U.pos}
    read = lambda p: {k: v for k, v in pr._load(p).items()} if os.path.exists(p) else None
    inherit = None
    if os.path.exists(INHERIT):
        inherit = {}
        for l in open(INHERIT, encoding="utf-8"):
            r = json.loads(l)
            if r.get("labels"):
                inherit[r["id"]] = {**r["labels"], "family": r.get("family")}
    return local_module("paper_analysis").paper_section(U, routes, benchmark_names(U), load_facets(U), axes, prot, chains, items, labels, works,
                                                        load_json("oss.json"), os.path.join(OSS_DIR, "meta.jsonl"), out, novelty=read(NOVELTY),
                                                        bounds=read(BOUNDARY), inherit=inherit, upkeep=os.path.join(OSS_DIR, "upkeep_v1.jsonl"))


def main():
    import argparse
    ap = argparse.ArgumentParser(description="per-work navigation data (--data-only) or the observation report as an analysis version")
    ap.add_argument("--data-only", action="store_true", help="bands, facet labels and citing-sentence shards only; findings.json untouched")
    ap.add_argument("--analysis-version", help="label of the observation report, e.g. A2 (required unless --data-only)")
    ap.add_argument("--out", help="write the report here instead of dist/data/findings.json; per-work data files are then left untouched")
    a = ap.parse_args()
    if not a.data_only and not a.analysis_version:
        ap.error("the observation report is an analysis version: pass --analysis-version (release_analysis.py does), or --data-only")
    random.seed(SEED)
    U = Universe()
    print(f"works {U.n}, citation routes {len(U.links)}, as of {U.asof}", flush=True)
    names, routes, texts = benchmark_routes(U)
    print(f"benchmark names {len(names)}, routes {len(routes)} from {texts} full texts", flush=True)
    data_files = not a.out
    if a.data_only:
        star_bands(U, routes)
        write_facets(U)
        c = citation_contexts(U)
        write_benchmark_routes(U, routes)
        print("per-work data written (bands, facets, citing-sentence shards):", c and c["withSentence"], "routes with a sentence", flush=True)
        return
    rq1 = rq1_section(U, routes)
    print("rq1 done", json.dumps(rq1["pilot"]["table"]), flush=True)
    rq2 = rq2_section(U, routes)
    print("rq2 done", rq2["correlation"], flush=True)
    rq3 = rq3_section(U, routes)
    print("rq3 done", rq3["correlation"], flush=True)
    rq4 = rq4_section(U, routes)
    print("rq4 done", rq4["growth"]["doublingMonths"], flush=True)
    meta = U.atlas["meta"]
    rel = load_json("updates.json")["releases"][0]["release"]
    used_ids = set()
    out = {
        "meta": {"version": "findings-v1", "analysisVersion": a.analysis_version, "release": rel, "cutoff": meta.get("cutoff"), "asOf": U.asof.isoformat(),
                 "computedOn": dt.date.today().isoformat(), "novaMonths": NOVA_MONTHS, "minGroup": MIN_GROUP, "seed": SEED,
                 "clusters": U.topics, "galaxies": [{"id": t["id"], "en": t["en"], "color": t["color"]} for t in U.themes],
                 "clusterGalaxy": U.theme_of_topic},
        "universe": universe_section(U, names, routes, texts),
        "fractures": None, "rq1": rq1, "rq2": rq2, "rq3": rq3, "rq4": rq4,
        "web": web_section(U, routes), "fragmentation": fragmentation(U, routes, load_facets(U)), "benchmarks": benchmark_table(U, routes),
        "audit": audit_summary(U, routes),
        "hypotheses": hypotheses(rq1, rq2, rq3, rq4),
        "trends": trends_section(U, routes),
        "lenses": lens_section(U, routes),
        "deeper": deeper_section(U, routes),
    }
    out["fractures"] = fractures(U, routes, rq1, rq4)
    # RQ5: the tail and the gaps (tail_analysis.py), next to the head that the Leadership lens analyses
    tx = {pid: (title, body) for pid, title, body, _ in local_module("embed_specter2").texts()}
    out["tail"] = local_module("tail_analysis").tail_section(U, routes, load_facets(U), tx, json.load(open(os.path.join(DATA, "facets.json"), encoding="utf-8"))["fields"],
                                                         stop=STOP, aliases=TERM_ALIASES)
    print("tail done", json.dumps({k: out["tail"]["backtest"][0][k] for k in ("rose", "roseFromTailOrAbsent", "tailTerms", "tailRose", "baseRate")}), flush=True)
    # what the collection studies, on an agent axis and a safety axis (scope_analysis.py; first question of the Structure lens)
    out["scope"] = local_module("scope_analysis").scope_section(U, load_facets(U), tx, SEED)
    print("scope done", json.dumps({r["key"]: r["n"] for r in out["scope"]["agent"]}), flush=True)
    # the Connection lens' global view: galaxies and clusters x four layers x years (connect_analysis.py)
    cx = local_module("connect_analysis")
    out["connect"] = cx.connect_section(U, routes)
    out["connect"]["collab"] = cx.collab_finding(rq2)
    print("connect done", len(out["connect"]["years"]), "years", flush=True)
    # the Positioning chapter: Opus labels on the two axes and their filters, DeepSeek as a second reader (position_analysis.py)
    pa = local_module("position_analysis")
    if os.path.exists(AXES):
        out["position"] = pa.position_section(U, pa.load_axes(AXES), load_facets(U), pa.load_axes(AXES2) if os.path.exists(AXES2) else None,
                                              fulltext=(fulltext_path, REFS_HEAD))
        print("position done", out["position"]["labelled"], "labelled", flush=True)
    # the Players part's global view: countries on a map, institutions on output x influence (players_analysis.py)
    out["players"] = local_module("players_analysis").players_section(U, routes, ROR_CACHE)
    print("players done", len(out["players"]["countries"]), "countries", len(out["players"]["institutions"]), "institutions", flush=True)
    # the Trajectory part's global view: candidate clusters month by month, head and tail (trajectory_analysis.py)
    out["trajectory"] = local_module("trajectory_analysis").trajectory_section(U)
    print("trajectory done", len(out["trajectory"]["lines"]), "lines", flush=True)
    # topic board: which models the year's papers work with (models_analysis.py)
    out["models2026"] = local_module("models_analysis").models_section(U, fulltext_path, REFS_HEAD, local_module("scope_analysis").agent_of, load_facets(U),
                                                                       roles_path=ROLES_LABELS, roles_second=ROLES_LABELS2)
    print("models done", out["models2026"]["papers"], "full texts", flush=True)
    # the evidence board: what conclusions rest on (evidence_analysis.py; protocol extraction adds more when it is in)
    ma = local_module("models_analysis")
    out["evidence"] = local_module("evidence_analysis").evidence_section(U, routes, load_facets(U), ma.CACHE["meta"], ma.CACHE["tables"], ma.CACHE["lags"], ma.CACHE["quotes"], ma.CACHE["counts"], ma.CACHE["scan"],
                                                                         {i for i in range(U.n) if fulltext_path(U, i)}, ma.CACHE["judgeAny"], ma.CACHE["judgeUnmatched"])
    # protocol cards (judging level 2, F16, F19-F22) and citation intents (F18 contexts, F23, F24), when their full runs are in
    pr = local_module("protocol_analysis").protocol_section(U, load_facets(U), PROTOCOL_LABELS, PROTOCOL_SECOND, ma.G, ma.norm, ma.CACHE["tables"], ma.CACHE["meta"], PROTOCOL_CANON, CLAIMS_LABELS, CLAIMS_SECOND)
    ci = local_module("cites_analysis").cites_section(U, CITES_CORPUS, CITES_LABELS, CITES_SECOND, routes, CITES_VERIFY, CITES_VERIFY_BG)
    out["evidence"]["cards"].update(pr.get("cards", {}))
    out["evidence"]["cards"].update(ci.get("cards", {}))
    qa = local_module("questions_analysis").questions_section(U, routes, load_facets(U), ma.CACHE["meta"], ma.CACHE["tables"], ma.CACHE["quotes"], ma.CACHE["counts"],
                                                               out.get("position"), local_module("scope_analysis").agent_of, set(benchmark_names(U).values()))
    out["evidence"]["cards"].update(qa.get("cards", {}))
    records = {**out["evidence"].pop("records", {}), **pr.get("records", {}), **ci.get("records", {}), **qa.get("records", {})}
    # joint analyses on the same records (joint_analysis.py)
    def refs_text(i):  # the reference section of a work's full text ("" when there is none)
        path = fulltext_path(U, i)
        if not path:
            return ""
        t = gzip.open(path, "rt", encoding="utf-8", errors="ignore").read()
        m = REFS_HEAD.search(t, len(t) // 3)
        return t[m.start():] if m else t[-len(t) // 3:]
    ja = local_module("joint_analysis").joint_section(U, routes, load_facets(U), ma.CACHE["tables"], ma.CACHE["meta"], records, benchmark_names(U), refs_text, lambda i: bool(fulltext_path(U, i)),
                                                      PROTOCOL_LABELS, CLAIMS_LABELS, CITES_CORPUS, CITES_LABELS, CITES_VERIFY, CITES_VERIFY_BG)
    out["evidence"]["cards"].update(ja["cards"])
    records.update(ja["records"])
    # the paper's question structure: growth -> accumulation, RQ1-RQ4 (paper_analysis.py)
    out["paper"] = paper_part(U, routes, out)
    records.update(out["paper"].pop("_records", {}))
    print("paper done", ", ".join(f"{k}: {len(v)}" for k, v in out["paper"].items() if k.startswith("rq")), flush=True)
    # the item-level records go to data/records/ (write_records), not a second time into the report
    out["evidence"]["sources"] = {"protocol": {k: v for k, v in pr.items() if k not in ("cards", "records")} or None, "cites": {k: v for k, v in ci.items() if k not in ("cards", "records")} or None}
    print("evidence done", out["evidence"]["independence"]["benchmarks"], "benchmarks with 3+ uses;", len(out["evidence"]["cards"]), "cards", flush=True)
    # topic board: the open-source side against the papers (oss_analysis.py)
    oss_path = os.path.join(DATA, "oss.json")
    if os.path.exists(oss_path):
        out["oss"] = local_module("oss_analysis").oss_section(U, json.load(open(oss_path, encoding="utf-8")), load_facets(U))
        print("oss done", out["oss"]["repos"], "repositories", flush=True)
    out["threads"] = {t["id"]: {"label": t.get("label"), "topic": U.tidx.get(t["topic"])} for t in U.threads}
    if data_files:
        star_bands(U, routes)
        write_facets(U)
    out["contexts"] = citation_contexts(U, write=data_files)
    if out["contexts"]:
        c = out["contexts"]
        b = out["fractures"]["basis"]
        b["citationSentence"] = c["withSentence"]
        b["sentenceLevel"] = b["benchmarkUseRoutes"] + c["withSentence"]
        b["sentenceLevelPct"] = pct(b["sentenceLevel"], b["citationRoutes"] + b["benchmarkUseRoutes"])
        b["contextCoverage"] = [c["citingFetched"], c["citingTotal"]]
    write_benchmark_routes(U, routes)
    target = a.out or os.path.join(DATA, "findings.json")
    os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
    records.update(module_records(U, out))
    with open(target, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
    print(target, os.path.getsize(target) // 1024, "KB", flush=True)
    write_records(records, os.path.join(os.path.dirname(os.path.abspath(target)), "records"), out["meta"])


if __name__ == "__main__":
    main()
