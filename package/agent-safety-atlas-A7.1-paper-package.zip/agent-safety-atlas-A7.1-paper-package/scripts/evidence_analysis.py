#!/usr/bin/env python3
"""The evidence board: what agent-safety conclusions rest on (owner's questions Q1, Q2, F15-F24, 2026-10-19).

Every item is a card in one shape (owner rule 2026-10-19): the denominator and the missing rate, the main statistics,
traceable evidence (a paper and a sentence copied from it), supporting and counter cases, the results under other
definitions, and whether there is a difference at all; analyses that find none are kept and say so.

  fresh       Q1: do papers on newer models study newly emerged agent settings, and newer benchmarks? (2026 papers)
  judges      Q2, level 1 (observation): judge and studied model from the same family, against chance
  bench       F15: concentration of shared benchmarks, reach, and the papers that rest on one benchmark
  modeldep    F15: concentration of studied models and judges (2026 model roles)
  independence F17: spread of a benchmark beyond its authors and their institutions
  citeuse     F18: benchmarks cited against benchmarks used, within year and cluster
The protocol cards (Q2 level 2, F16, F19-F22) come from intake/screening/label_protocol.py (protocol_analysis.py).
Benchmark uses are the Atlas's benchmark-use routes (a work names an Atlas benchmark in its experiments, with the sentence);
benchmarks outside the Atlas are not seen, which is counted as missing where it matters.
"""
import math
import re
import unicodedata
from collections import Counter, defaultdict


def _norm_name(a):
    t = unicodedata.normalize("NFKD", a or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z]+", " ", t).strip()


def _hhi(counts):
    tot = sum(counts) or 1
    return round(sum((c / tot) ** 2 for c in counts), 4)


def _pct(k, n, d=1):
    return round(100 * k / n, d) if n else None


def _ztest(k1, n1, k2, n2):
    """two-sided p of a difference of two proportions (normal approximation)"""
    if not n1 or not n2:
        return None
    p = (k1 + k2) / (n1 + n2)
    se = math.sqrt(p * (1 - p) * (1 / n1 + 1 / n2))
    if se == 0:
        return 1.0
    z = abs(k1 / n1 - k2 / n2) / se
    return round(math.erfc(z / math.sqrt(2)), 4)


def _spearman(a, b):
    n = len(a)
    if n < 3:
        return None
    def ranks(v):
        o = sorted(range(n), key=lambda i: v[i])
        r = [0.0] * n
        i = 0
        while i < n:
            j = i
            while j + 1 < n and v[o[j + 1]] == v[o[i]]:
                j += 1
            for k in range(i, j + 1):
                r[o[k]] = (i + j) / 2
            i = j + 1
        return r
    ra, rb = ranks(a), ranks(b)
    ma, mb = sum(ra) / n, sum(rb) / n
    num = sum((x - ma) * (y - mb) for x, y in zip(ra, rb))
    den = math.sqrt(sum((x - ma) ** 2 for x in ra) * sum((y - mb) ** 2 for y in rb))
    return round(num / den, 3) if den else None


def _records(unit, basis, cols, rows):
    """the item-level record behind a question (data/records/<F>.json, shown on demand under its card): one row per paper,
    benchmark use, citation, repository or institution, keyed by Atlas ids so records of different questions can be joined.
    cols: [key, en, zh, kind] (kind: text, paper, list, num); rows: [id, date, [values in column order], evidence, [unknown keys]];
    evidence is one verbatim phrase, or [[field key, phrase], …] when different fields rest on different phrases"""
    return {"unit": unit, "basis": basis, "cols": cols, "rows": rows}


def _card(base, base_label, missing, missing_of, missing_why, stats, evidence=(), support=(), counter=(), alt=(), null=False, null_note=None):
    return {"base": base, "baseLabel": base_label, "missing": missing, "missingOf": missing_of, "missingRate": _pct(missing, missing_of),
            "missingWhy": missing_why, "stats": stats, "evidence": list(evidence), "support": list(support), "counter": list(counter),
            "alt": list(alt), "null": null, "nullNote": null_note}


def evidence_section(U, routes, facets, models_meta=None, roles=None, model_papers=None, quotes=None, counts=None, scan=None, has_text=None, judge_any=None, judge_unmatched=None, first_year=2022):
    years = list(range(first_year, U.asof.year + 1))
    uses = [(i, j) for (i, j), r in routes.items() if r["kind"] == "use"]
    authors = [{_norm_name(a) for a in (U.byid[pid].get("authors") or []) if isinstance(a, str) and a.strip()} for pid in U.ids]
    pid = lambda i: U.ids[i]
    ref = lambda i, quote=None, **kw: {"id": U.ids[i], "title": U.title[i], "year": U.year[i], "quote": quote, **kw}
    use_q = lambda i, j: routes[(i, j)]["evidence"]
    quotes, counts, scan = quotes or {}, counts or {}, scan or {}
    experimental = lambda i: (facets.get(i) or {}).get("evaluation") not in (None, "no_experiment")
    cards = {}

    # ------------------------------------------------------------------ F15: shared benchmarks
    dep = []
    for y in years:
        us = [(i, j) for i, j in uses if U.year[i] == y]
        c = Counter(j for _, j in us)
        users = {i for i, _ in us}
        top = [j for j, _ in c.most_common(5)]
        exp_works = sum(1 for i in range(U.n) if U.year[i] == y and experimental(i))
        dep.append({"year": y, "uses": len(us), "papers": len(users), "experimentalWorks": exp_works, "benchmarks": len(c),
                    "top1": _pct(c.most_common(1)[0][1], len(us)) if c else None, "top5": _pct(sum(c[j] for j in top), len(us)), "hhi": _hhi(list(c.values())),
                    "papersTop5": _pct(sum(1 for i in users if any((i, j) in routes for j in top)), len(users)),
                    "papersTop1": _pct(sum(1 for i in users if top and (i, top[0]) in routes), len(users))})
    c_all = Counter(j for _, j in uses)
    reach = []
    for j, n in c_all.most_common(25):
        us = [i for i, jj in uses if jj == j]
        reach.append({"id": U.ids[j], "title": U.title[j], "uses": n, "clusters": len({k for i in us for k in U.ptopics[i]}), "year": U.year[j]})
    recent = [y for y in years if y >= U.asof.year - 1]
    us_r = [(i, j) for i, j in uses if U.year[i] in recent]
    per_paper = defaultdict(set)
    for i, j in us_r:
        per_paper[i].add(j)
    removal = []
    for j, n in Counter(j for _, j in us_r).most_common(5):
        users = [i for i, bs in per_paper.items() if j in bs]
        removal.append({"id": U.ids[j], "title": U.title[j], "papers": len(users), "share": _pct(len(users), len(per_paper)),
                        "only": sum(1 for i in users if len(per_paper[i]) == 1), "onlyShare": _pct(sum(1 for i in users if len(per_paper[i]) == 1), len(per_paper))})
    exp_recent = [i for i in range(U.n) if U.year[i] in recent and experimental(i)]
    has_text = has_text if has_text is not None else set(range(U.n))
    exp_text = [i for i in exp_recent if i in has_text]
    top_j = U.pos[removal[0]["id"]] if removal else None
    if top_j is not None:
        only = sorted([i for i, bs in per_paper.items() if bs == {top_j}], key=lambda i: U.date[i] or U.asof, reverse=True)
        many = sorted([i for i, bs in per_paper.items() if top_j in bs and len(bs) >= 3], key=lambda i: -len(per_paper[i]))
        # other definitions: by papers rather than uses; without the benchmark authors' own uses; the last year alone
        def top_share(pairs):
            c = Counter(j for _, j in pairs)
            return (_pct(c.most_common(1)[0][1], len(pairs)), U.title[c.most_common(1)[0][0]].split(":")[0][:40]) if c else (None, None)
        own = lambda i, j: bool(authors[i] & authors[j])
        last = [p for p in us_r if U.year[p[0]] == U.asof.year]
        alt = [{"key": "byUses", "value": top_share(us_r)[0], "label": top_share(us_r)[1], "base": len(us_r)},
               {"key": "byPapers", "value": removal[0]["share"], "label": U.title[top_j].split(":")[0][:40], "base": len(per_paper)},
               {"key": "noOwnUses", "value": top_share([p for p in us_r if not own(*p)])[0], "label": top_share([p for p in us_r if not own(*p)])[1], "base": sum(1 for p in us_r if not own(*p))},
               {"key": "lastYear", "value": top_share(last)[0], "label": top_share(last)[1], "base": len(last)}]
        cards["bench"] = _card(len(per_paper), "works in the last two years that use at least one Atlas benchmark", len(exp_recent) - len(exp_text),
                               len(exp_recent), "works with experiments whose full text is not available, so benchmark use cannot be read",
                               {"top": removal[0], "removal": removal, "byYear": dep, "experimental": len(exp_recent), "withText": len(exp_text),
                                "withTextNoAtlas": sum(1 for i in exp_text if i not in per_paper), "withTextNoAtlasShare": _pct(sum(1 for i in exp_text if i not in per_paper), len(exp_text))},
                               evidence=[ref(i, use_q(i, top_j)) for i in only[:3]],
                               support=[ref(i, use_q(i, top_j), benchmarks=1) for i in only[3:9]],
                               counter=[ref(i, use_q(i, top_j), benchmarks=len(per_paper[i])) for i in many[:6]],
                               alt=alt)
    # ------------------------------------------------------------------ F15: studied models and judges (2026 roles)
    models = None
    fam = (lambda g: models_meta[g]["family"]) if models_meta else None
    if roles and models_meta:
        subj, judge = {}, {}
        for p, t in roles.items():
            s = {fam(g) for g, rs in t.items() if "subject" in rs}
            jd = {fam(g) for g, rs in t.items() if "judge" in rs}
            if s:
                subj[p] = s
            if jd:
                judge[p] = jd
        sc, jc = Counter(f for s in subj.values() for f in s), Counter(f for s in judge.values() for f in s)
        bench_of = defaultdict(set)
        for i, j in uses:
            if U.year[i] == 2026:
                bench_of[U.ids[i]].add(U.title[j].split(":")[0][:40])
        combos = Counter()
        for p in set(subj) & set(judge):
            for b in bench_of.get(p) or {"(no Atlas benchmark)"}:
                for s in subj[p]:
                    for jd in judge[p]:
                        combos[(b, s, jd)] += 1
        models = {"papersWithSubject": len(subj), "papersWithJudge": len(judge),
                  "subjects": [{"family": f, "papers": n, "share": _pct(n, len(subj))} for f, n in sc.most_common(8)],
                  "judges": [{"family": f, "papers": n, "share": _pct(n, len(judge))} for f, n in jc.most_common(8)],
                  "judgeOnly": {f: _pct(sum(1 for s in judge.values() if s == {f}), len(judge)) for f, _ in jc.most_common(3)},
                  "subjectOnly": {f: _pct(sum(1 for s in subj.values() if s == {f}), len(subj)) for f, _ in sc.most_common(3)},
                  "combos": [{"benchmark": b, "subject": s, "judge": jd, "papers": n} for (b, s, jd), n in combos.most_common(12)]}
        topj = jc.most_common(1)[0][0] if jc else None
        only_j = [p for p, s in judge.items() if s == {topj}]
        other_j = [p for p, s in judge.items() if topj not in s]
        jq = lambda p, f: next((quotes.get(p, {}).get(g) for g, rs in roles[p].items() if "judge" in rs and fam(g) == f and quotes.get(p, {}).get(g)), None)
        # other definitions: twice-named judges only (the page's count rule); judges in the last six months
        twice = {p: {fam(g) for g, rs in roles[p].items() if "judge" in rs and counts.get(U.pos[p], {}).get(g, 0) >= 2} for p in judge if p in U.pos}
        twice = {p: s for p, s in twice.items() if s}
        late = {p: s for p, s in judge.items() if p in U.pos and U.date[U.pos[p]] and U.date[U.pos[p]].strftime("%Y-%m") >= f"{U.asof.year}-{max(1, U.asof.month - 5):02d}"}
        tw = Counter(f for s in twice.values() for f in s)
        lt = Counter(f for s in late.values() for f in s)
        j_any = set(judge_any or judge)
        unknown = [p for p in j_any if p not in judge]
        cards["modeldep"] = _card(len(judge), "2026 papers whose model roles name at least one judge model of a known family", len(unknown), len(j_any),
                                  "papers whose judge models are all outside the model registry (family unknown)",
                                  {**models, "papersLabelled": len(roles), "judgeAny": len(j_any), "judgeSomeUnknown": len(set(judge_unmatched or ()) & j_any)},
                                  evidence=[ref(U.pos[p], jq(p, topj), family=topj) for p in only_j[:3] if p in U.pos],
                                  support=[ref(U.pos[p], jq(p, topj), family=topj) for p in only_j[3:9] if p in U.pos],
                                  counter=[ref(U.pos[p], next(iter(quotes.get(p, {}).values()), None), families=sorted(judge[p])) for p in other_j[:6] if p in U.pos],
                                  alt=[{"key": "judgeShare", "value": _pct(jc[topj], len(judge)), "label": topj, "base": len(judge)},
                                       {"key": "twiceNamed", "value": _pct(tw[topj], len(twice)), "label": topj, "base": len(twice)},
                                       {"key": "lastSixMonths", "value": _pct(lt[topj], len(late)), "label": topj, "base": len(late)},
                                       {"key": "onlyThisFamily", "value": _pct(len(only_j), len(judge)), "label": topj, "base": len(judge)}])
    # ------------------------------------------------------------------ Q2 level 1: judge and studied model of one family
    if roles and models_meta:
        both = [p for p in roles if subj.get(p) and judge.get(p)]
        same = [p for p in both if subj[p] & judge[p]]
        gens = lambda p, r: {g for g, rs in roles[p].items() if r in rs}
        same_gen = [p for p in both if gens(p, "subject") & gens(p, "judge")]
        # chance: a paper's judge family drawn from the marginal judge-family distribution, independent of its subjects
        jm = Counter(f for p in both for f in judge[p])
        tot = sum(jm.values())
        expected = sum(sum(jm[f] for f in subj[p]) / tot for p in both) / max(1, len(both)) if tot else None
        one_subj = [p for p in both if len(subj[p]) == 1]
        no_gpt = [p for p in both if "GPT" not in judge[p]]
        alt = [{"key": "sameGeneration", "value": _pct(len(same_gen), len(both)), "base": len(both)},
               {"key": "chance", "value": round(100 * expected, 1) if expected is not None else None, "base": len(both)},
               {"key": "oneSubjectFamily", "value": _pct(sum(1 for p in one_subj if subj[p] & judge[p]), len(one_subj)), "base": len(one_subj)},
               {"key": "nonOpenAIJudges", "value": _pct(sum(1 for p in no_gpt if subj[p] & judge[p]), len(no_gpt)), "base": len(no_gpt)}]
        sq = lambda p: next((quotes.get(p, {}).get(g) for g in gens(p, "judge") if quotes.get(p, {}).get(g)), None)
        pairs = Counter((f, f) for p in same for f in subj[p] & judge[p])
        judge_no_subject = [p for p in judge if not subj.get(p)]
        cards["judges"] = _card(len(both), "2026 papers whose model roles name both a judge model and a studied model", len(judge_no_subject), len(judge),
                                "papers that name a judge model but no studied model of a known family (the judge's object cannot be read from the roles)",
                                {"sameFamily": _pct(len(same), len(both)), "sameGeneration": _pct(len(same_gen), len(both)), "chance": alt[1]["value"],
                                 "pairs": [{"family": f, "papers": n} for (f, _), n in pairs.most_common(6)], "papers": len(both)},
                                evidence=[ref(U.pos[p], sq(p), judge=sorted(judge[p]), subject=sorted(subj[p])) for p in same[:3] if p in U.pos],
                                support=[ref(U.pos[p], sq(p), judge=sorted(judge[p]), subject=sorted(subj[p])) for p in same[3:9] if p in U.pos],
                                counter=[ref(U.pos[p], sq(p), judge=sorted(judge[p]), subject=sorted(subj[p])) for p in both if not (subj[p] & judge[p]) and p in U.pos][:6],
                                alt=alt, null=False,
                                null_note="Level 1 is an observation of co-occurrence. Whether the judge actually grades that model is checked in level 2 (protocol card); whether conclusions move with the judge was the re-judging experiment, paused by the owner on 2026-10-19.")
    # ------------------------------------------------------------------ F17: spread beyond the authors
    indep = []
    by_bench = defaultdict(list)
    for i, j in uses:
        by_bench[j].append(i)
    undated = 0
    for j, us in by_bench.items():
        if len(us) < 3:
            continue
        if not U.date[j]:
            undated += 1
            continue
        us = sorted(us, key=lambda i: U.date[i] or U.asof)
        no_auth = [i for i in us if authors[j] and not (authors[i] & authors[j])]
        no_inst = [i for i in us if U.pinst[j] and U.pinst[i] and not (U.pinst[i] & U.pinst[j])]
        lag = lambda xs: max(0, (U.date[xs[0]] - U.date[j]).days // 30) if xs and U.date[xs[0]] else None
        teams = {frozenset(authors[i]) for i in no_auth}
        indep.append({"id": U.ids[j], "title": U.title[j], "year": U.year[j], "uses": len(us), "noSharedAuthor": len(no_auth), "noSharedInstitution": len(no_inst) if U.pinst[j] else None,
                      "independentTeams": len(teams), "firstUseMonths": lag(us), "firstNoAuthorMonths": lag(no_auth), "firstNoInstitutionMonths": lag(no_inst) if U.pinst[j] else None,
                      "citations": U.cites[j], "clusters": len({k for i in us for k in U.ptopics[i]}), "_j": j, "_first": no_auth[0] if no_auth else None})
    by_uses = sorted(indep, key=lambda r: -r["uses"])
    by_indep = sorted(indep, key=lambda r: (-r["independentTeams"], -(r["noSharedInstitution"] or 0)))
    rank_u = {r["id"]: k + 1 for k, r in enumerate(by_uses)}
    for k, r in enumerate(by_indep):
        r["rankIndependent"], r["rankUses"] = k + 1, rank_u[r["id"]]
    cite_rank = {r["id"]: k + 1 for k, r in enumerate(sorted(indep, key=lambda r: -(r["citations"] or 0)))}
    for r in indep:
        r["rankCitations"] = cite_rank[r["id"]]
    self_share = _pct(sum(r["uses"] - r["noSharedAuthor"] for r in indep), sum(r["uses"] for r in indep))
    risers = sorted([r for r in indep if r["rankIndependent"] + 5 <= r["rankUses"] or (r["rankCitations"] - r["rankIndependent"] >= 10)], key=lambda r: r["rankIndependent"])[:10]
    selfish = sorted([r for r in indep if r["uses"] >= 5 and r["noSharedAuthor"] / r["uses"] < 0.5], key=lambda r: -r["uses"])[:6]
    no_inst_known = [r for r in indep if r["noSharedInstitution"] is not None]
    five = [r for r in indep if r["uses"] >= 5]
    top10 = lambda key: {r["id"] for r in sorted(indep, key=key)[:10]}
    ev_first = lambda r: ref(r["_first"], use_q(r["_first"], r["_j"]), benchmark=r["title"].split(":")[0][:50], months=r["firstNoAuthorMonths"]) if r["_first"] is not None else None
    cards["independence"] = _card(len(indep), "Atlas benchmarks used by at least three works", undated + sum(1 for r in indep if r["noSharedInstitution"] is None), len(indep) + undated,
                                  "benchmarks without a date (left out) or without a known institution (no institution-based count)",
                                  {"selfUseShare": self_share, "spearmanUsesTeams": _spearman([r["uses"] for r in indep], [r["independentTeams"] for r in indep]),
                                   "spearmanUsesCitations": _spearman([r["uses"] for r in indep], [r["citations"] or 0 for r in indep])},
                                  evidence=[x for x in (ev_first(r) for r in by_indep[:3]) if x],
                                  support=[{"id": r["id"], "title": r["title"], "rankUses": r["rankUses"], "rankIndependent": r["rankIndependent"], "rankCitations": r["rankCitations"]} for r in risers[:6]],
                                  counter=[{"id": r["id"], "title": r["title"], "uses": r["uses"], "noSharedAuthor": r["noSharedAuthor"]} for r in selfish],
                                  alt=[{"key": "fiveUses", "value": _pct(sum(r["uses"] - r["noSharedAuthor"] for r in five), sum(r["uses"] for r in five)), "base": len(five)},
                                       {"key": "byInstitution", "value": _pct(sum(r["uses"] - r["noSharedInstitution"] for r in no_inst_known), sum(r["uses"] for r in no_inst_known)), "base": len(no_inst_known)},
                                       {"key": "top10Overlap", "value": len(top10(lambda r: -r["uses"]) & top10(lambda r: (-r["independentTeams"], -(r["noSharedInstitution"] or 0)))), "base": 10},
                                       {"key": "top10OverlapInst", "value": len(top10(lambda r: -r["uses"]) & top10(lambda r: -(r["noSharedInstitution"] or 0))), "base": 10}])
    for r in indep:
        r.pop("_j"), r.pop("_first")
    # ------------------------------------------------------------------ F18: cited against used
    bench_all = [j for j in range(U.n) if U.form[j] == "benchmark" and U.year[j] and U.year[j] <= U.asof.year - 1]
    bench = [j for j in bench_all if U.cites[j] is not None]

    def quadrants(js_all, group_key, hi=0.75, min_uses=2, min_group=8):
        groups = defaultdict(list)
        for j in js_all:
            groups[group_key(j)].append(j)
        quad, ex, seen = Counter(), defaultdict(list), 0
        for key, js in groups.items():
            if len(js) < min_group:
                continue
            seen += len(js)
            cr = {j: sum(1 for x in js if (U.cites[x] or 0) < (U.cites[j] or 0)) / (len(js) - 1) for j in js}
            ur = {j: sum(1 for x in js if c_all[x] < c_all[j]) / (len(js) - 1) for j in js}
            for j in js:
                hc, hu = cr[j] >= hi, c_all[j] >= min_uses and ur[j] >= hi
                q = "both" if hc and hu else "citedNotUsed" if hc else "usedNotCited" if hu else "neither"
                quad[q] += 1
                ex[q].append(j)
        return quad, ex, seen
    yc = lambda j: (U.year[j], U.ptopics[j][0] if U.ptopics[j] else -1)
    quad, ex, seen = quadrants(bench, yc)
    exs = {q: [{"id": U.ids[j], "title": U.title[j], "year": U.year[j], "citations": U.cites[j], "uses": c_all[j]} for j in
               sorted(js, key=lambda j: -(c_all[j] if q != "citedNotUsed" else U.cites[j] or 0))[:12]] for q, js in ex.items() if q != "neither"}
    first_use = {}
    for i, j in sorted(uses, key=lambda p: U.date[p[0]] or U.asof):
        first_use.setdefault(j, i)
    alt = []
    for key, kw in (("topThird", {"hi": 2 / 3}), ("yearOnly", {"group_key": lambda j: U.year[j]}), ("oneUse", {"min_uses": 1})):
        q2, _, s2 = quadrants(bench, **({"group_key": yc} | kw))
        alt.append({"key": key, "value": _pct(q2["citedNotUsed"], q2["citedNotUsed"] + q2["both"]), "base": s2, "citedNotUsed": q2["citedNotUsed"], "both": q2["both"]})
    cited_hi = quad["citedNotUsed"] + quad["both"]
    cards["citeuse"] = _card(seen, "Atlas benchmarks published up to last year, in year x cluster groups of at least eight", len(bench_all) - seen, len(bench_all),
                             "benchmarks without a citation count or in groups too small to rank within",
                             {"quadrants": dict(quad), "citedNotUsedShare": _pct(quad["citedNotUsed"], cited_hi)},
                             evidence=[ref(U.pos[r["id"]], use_q(first_use[U.pos[r["id"]]], U.pos[r["id"]]) if U.pos[r["id"]] in first_use else None, citations=r["citations"], uses=r["uses"], user=U.ids[first_use[U.pos[r["id"]]]] if U.pos[r["id"]] in first_use else None) for r in exs.get("usedNotCited", [])[:3]],
                             support=exs.get("citedNotUsed", [])[:6], counter=exs.get("both", [])[:6], alt=alt)
    # ------------------------------------------------------------------ Q1: newer models and new agent settings
    fresh = None
    if model_papers:
        settings = ["web_browser", "computer_gui_mobile", "coding", "general_tool_assistant", "mcp_skills_ecosystem", "rag_memory_assistant",
                    "multi_agent", "embodied_robot", "driving_drone", "rl_simulator", "enterprise_workflow", "science_research"]
        dated = {st: sorted(U.date[i].strftime("%Y-%m") for i in range(U.n) if U.date[i] and st in ((facets.get(i) or {}).get("settings") or [])) for st in settings}
        def new_settings(nth, since="2025-01"):
            return sorted(s for s, ds in dated.items() if len(ds) >= nth and ds[nth - 1] >= since)
        bench_age = defaultdict(list)
        for i, j in uses:
            if U.date[i] and U.date[j]:
                bench_age[i].append((U.date[i].year - U.date[j].year) * 12 + U.date[i].month - U.date[j].month)
        st_of = lambda i: set((facets.get(i) or {}).get("settings") or [])

        def compare(lags, fresh_max=6, stale_min=12, new_st=None):
            new_st = set(new_st if new_st is not None else new_settings(20))
            rows = defaultdict(lambda: {"fresh": [0, 0], "stale": [0, 0]})
            for i, lag in lags.items():
                g = "fresh" if lag <= fresh_max else "stale" if lag >= stale_min else None
                if not g:
                    continue
                on = bool(st_of(i) & new_st)
                rows[U.date[i].strftime("%Y-%m")][g][0] += 1
                rows[U.date[i].strftime("%Y-%m")][g][1] += on
            num = den = 0
            for r in rows.values():
                if r["fresh"][0] >= 10 and r["stale"][0] >= 10:
                    w = min(r["fresh"][0], r["stale"][0])
                    num += w * (r["fresh"][1] / r["fresh"][0] - r["stale"][1] / r["stale"][0])
                    den += w
            f = [sum(r["fresh"][k] for r in rows.values()) for k in (0, 1)]
            s = [sum(r["stale"][k] for r in rows.values()) for k in (0, 1)]
            return {"fresh": f, "stale": s, "freshShare": _pct(f[1], f[0]), "staleShare": _pct(s[1], s[0]), "withinMonth": round(100 * num / den, 1) if den else None,
                    "p": _ztest(f[1], f[0], s[1], s[0])}
        main = compare(model_papers)
        new_st = new_settings(20)
        ages = {"fresh": [], "stale": []}
        for i, lag in model_papers.items():
            g = "fresh" if lag <= 6 else "stale" if lag >= 12 else None
            if g and bench_age.get(i):
                ages[g].append(min(bench_age[i]))
        med = lambda v: sorted(v)[len(v) // 2] if v else None
        on_new = [i for i in model_papers if st_of(i) & set(new_st) and (model_papers[i] <= 6 or model_papers[i] >= 12)]
        # any-mention newest model, as another definition of "uses a newer model"
        lm = {k for k, m in (models_meta or {}).items() if m["kind"] in ("llm", "vlm")}
        def lag_any(i):
            rel = [models_meta[k]["release"] for k in (counts.get(i) or {}) if k in lm and models_meta[k]["release"]]
            if not rel:
                return None
            r, m = max(rel), U.date[i].strftime("%Y-%m")
            return max(0, (int(m[:4]) - int(r[:4])) * 12 + int(m[5:7]) - int(r[5:7]))
        any_lags = {i: d for i in counts for d in [lag_any(i)] if d is not None}
        newest = lambda i: max(((models_meta[k]["release"], k) for k in (counts.get(i) or {}) if k in lm and models_meta[k]["release"] and counts[i][k] >= 2), default=(None, None))[1]
        mq = lambda i: quotes.get(U.ids[i], {}).get(newest(i)) if newest(i) else None
        mk = lambda i: models_meta[newest(i)]["label"] if newest(i) else None
        sup = sorted([i for i in on_new if model_papers[i] <= 6], key=lambda i: U.date[i], reverse=True)
        cou = sorted([i for i in on_new if model_papers[i] >= 12], key=lambda i: U.date[i], reverse=True)
        middle = sum(1 for d in model_papers.values() if 6 < d < 12)
        works = scan.get("worksInYear") or 0
        fresh = {"newSettings": new_st, "emergence": {s: (ds[19] if len(ds) >= 20 else None) for s, ds in dated.items()}, **main,
                 "benchAgeFresh": [len(ages["fresh"]), med(ages["fresh"])], "benchAgeStale": [len(ages["stale"]), med(ages["stale"])],
                 "newSettingStale": _pct(sum(1 for i in on_new if model_papers[i] >= 12), len(on_new)), "middle": middle}
        null = main["p"] is None or main["p"] >= 0.05
        cards["fresh"] = _card(main["fresh"][0] + main["stale"][0], "2026 papers whose newest twice-named language or vision-language model is at most 6 months old (fresh) or at least 12 (stale) at publication",
                               works - (main["fresh"][0] + main["stale"][0]), works,
                               f"2026 works without a full text, without a model named twice or with an unknown release month, and {middle} in the 7-11 month band left between the groups",
                               fresh,
                               evidence=[ref(i, mq(i), model=mk(i), months=model_papers[i], settings=sorted(st_of(i) & set(new_st))) for i in sup[:3]],
                               support=[ref(i, mq(i), model=mk(i), months=model_papers[i], settings=sorted(st_of(i) & set(new_st))) for i in sup[3:9]],
                               counter=[ref(i, mq(i), model=mk(i), months=model_papers[i], settings=sorted(st_of(i) & set(new_st))) for i in cou[:6]],
                               alt=[{"key": k, **{x: v for x, v in r.items() if x in ("freshShare", "staleShare", "withinMonth", "p")}, "base": r["fresh"][0] + r["stale"][0]} for k, r in (
                                   ("fresh3", compare(model_papers, 3, 12)), ("noGap", compare(model_papers, 6, 7)), ("emerge10", compare(model_papers, new_st=new_settings(10))),
                                   ("emerge40", compare(model_papers, new_st=new_settings(40))), ("anyMention", compare(any_lags)))],
                               null=null)
    # ------------------------------------------------------------------ item-level records behind F15 and F17
    day = lambda i: U.date[i].isoformat() if i is not None and U.date[i] else None
    recs = {}
    if roles and models_meta:
        ids15 = sorted({U.ids[i] for i in per_paper} | set(subj) | set(judge), key=lambda p: U.pos.get(p, 0))
        bn = lambda p: ", ".join(sorted(U.title[j].split(":")[0][:40] for j in per_paper.get(U.pos.get(p), ())))
        recs["F15"] = _records(["work using an Atlas benchmark (last two years) or 2026 paper with model roles", "使用 Atlas 基准的工作（近两年）或有模型角色的 2026 年论文"],
                               ["Benchmark uses from the full texts; model roles of 2026 papers matched to the model registry by family.", "基准使用来自全文；2026 年论文的模型角色按家族与模型登记表匹配。"],
                               [["benchmarks", "Atlas benchmarks used", "用到的 Atlas 基准", "list"], ["judges", "Judge families", "裁判家族", "list"], ["studied", "Studied families", "被测模型家族", "list"]],
                               [[p, day(U.pos.get(p)), [bn(p), ", ".join(sorted(judge.get(p, ()))), ", ".join(sorted(subj.get(p, ())))], None, []] for p in ids15 if p in U.pos])
    recs["F17"] = _records(["Atlas benchmark used by three works or more", "至少被 3 项工作使用的 Atlas 基准"],
                           ["Uses from the benchmark-use detection in full texts; outside = no shared author, or no shared institution.", "使用关系来自全文中的基准使用检测；外部 = 无共同作者，或无共同机构。"],
                           [["uses", "Uses", "使用", "num"], ["noSharedAuthor", "By teams sharing no author", "不共享作者", "num"], ["noSharedInstitution", "By other institutions", "不共享机构", "num"],
                            ["independentTeams", "Independent teams", "独立团队", "num"], ["firstNoAuthorMonths", "Months to first outside use", "首次外部使用（月）", "num"]],
                           [[r["id"], day(U.pos.get(r["id"])), [r["uses"], r["noSharedAuthor"], r["noSharedInstitution"], r["independentTeams"], r["firstNoAuthorMonths"]], None,
                             ["noSharedInstitution"] if r["noSharedInstitution"] is None else []] for r in by_uses])
    return {"years": years, "dependence": dep, "reach": reach, "removal": removal, "removalYears": recent, "models": models, "records": recs,
            "independence": {"benchmarks": len(indep), "selfUseShare": self_share, "byUses": by_uses[:15], "byIndependent": by_indep[:15], "risers": risers},
            "citeUse": {"benchmarks": len(bench), "quadrants": dict(quad), "examples": exs}, "freshness": fresh, "cards": cards}
