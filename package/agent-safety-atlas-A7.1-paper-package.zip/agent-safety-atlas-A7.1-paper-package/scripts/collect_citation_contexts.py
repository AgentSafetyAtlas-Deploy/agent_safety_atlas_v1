#!/usr/bin/env python3
"""
Citation contexts for the citation routes inside the Atlas (sentence-level provenance, "trace downward").

For every Atlas work with a Semantic Scholar reference list, this asks /paper/{id}/references for the citing sentences
(contexts), Semantic Scholar's citation intents (background / methodology / result) and its "influential citation"
flag. Only paper identifiers are sent. Raw answers are cached per citing work (research-paths/citation-graph/raw/
ctx_<paperId>.json.gz), so a rerun only asks for works not cached yet.

Coverage is Semantic Scholar's: contexts exist only where it parsed the citing paper's text; a route without a context is
"record-level" (the reference list), not "unsupported". Intents are Semantic Scholar's classifier output, not ours.

Output: research-paths/citation-graph/contexts.jsonl, one line per citing Atlas work:
  {"id": <Atlas id>, "refs": [{"paperId", "contexts" (up to 3, trimmed), "intents", "influential"}]} for references that
  are themselves Atlas works.
Data source attribution: Semantic Scholar Academic Graph (https://www.semanticscholar.org/product/api).
  python collect_citation_contexts.py [--order forward|reverse] [--fetch-only] [--limit N]
"""
import argparse
import gzip
import json
import os
import time

import requests

HERE = os.path.dirname(os.path.abspath(__file__))
CG = os.path.join(HERE, "research-paths", "citation-graph")
RAW = os.path.join(CG, "raw")
API = "https://api.semanticscholar.org/graph/v1"
UA = {"User-Agent": "agent-safety-atlas-research/1.0"}
MAX_CTX, MAX_CHARS = 3, 360


def cached(pid):
    """The cached answer, or None when it is missing or unreadable (a partly written file is fetched again)."""
    path = os.path.join(RAW, f"ctx_{pid}.json.gz")
    try:
        return json.load(gzip.open(path, "rt", encoding="utf-8")) if os.path.exists(path) else None
    except (OSError, EOFError, ValueError):
        return None


def fetch(session, pid):
    path = os.path.join(RAW, f"ctx_{pid}.json.gz")
    hit = cached(pid)
    if hit is not None:
        return hit
    out, offset = [], 0
    while offset is not None:
        for attempt in range(8):
            try:
                r = session.get(f"{API}/paper/{pid}/references", params={"fields": "contexts,intents,isInfluential,paperId",
                                "limit": 1000, "offset": offset}, headers=UA, timeout=120)
            except requests.RequestException:
                time.sleep(10 * (attempt + 1))
                continue
            if r.status_code == 429 or r.status_code >= 500:
                time.sleep(10 * (attempt + 1))
                continue
            break
        else:
            return None
        if r.status_code != 200:
            return None
        d = r.json()
        for x in d.get("data") or []:
            cp = (x.get("citedPaper") or {}).get("paperId")
            if cp:
                out.append({"paperId": cp, "contexts": x.get("contexts") or [], "intents": x.get("intents") or [],
                            "influential": bool(x.get("isInfluential"))})
        offset = d.get("next")
        time.sleep(1.0)
    tmp = f"{path}.{os.getpid()}.tmp"  # written whole, then moved: parallel collectors never see half a file
    with gzip.open(tmp, "wt", encoding="utf-8") as f:
        json.dump(out, f)
    os.replace(tmp, path)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--order", choices=["forward", "reverse"], default="forward")
    ap.add_argument("--fetch-only", action="store_true", help="fill the cache; do not write contexts.jsonl")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--max-fetch", type=int, help="ask for at most this many works not cached yet (scheduled updates)")
    a = ap.parse_args()
    os.makedirs(RAW, exist_ok=True)
    rows = [json.loads(l) for l in open(os.path.join(CG, "works.jsonl"), encoding="utf-8")]
    atlas_pids = {r["s2"]["paperId"] for r in rows if r["status"] == "found" and r["s2"].get("paperId")}
    todo = [r for r in rows if r["status"] == "found" and r.get("references")]
    if a.order == "reverse":
        todo = todo[::-1]
    if a.limit:
        todo = todo[:a.limit]
    s = requests.Session()
    asked = got = 0
    for n, r in enumerate(todo, 1):
        pid = r["s2"]["paperId"]
        if cached(pid) is None and (a.max_fetch is None or asked < a.max_fetch):
            asked += 1
            if fetch(s, pid) is not None:
                got += 1
        if n % 200 == 0:
            print(f"  {a.order} {n}/{len(todo)}: asked {asked}, fetched {got}", flush=True)
    print(f"fetch done: asked {asked}, fetched {got}", flush=True)
    if a.fetch_only:
        return
    n_works = n_routes = n_ctx = 0
    with open(os.path.join(CG, "contexts.jsonl"), "w", encoding="utf-8") as f:
        for r in todo if not a.limit else [x for x in rows if x["status"] == "found" and x.get("references")]:
            data = cached(r["s2"]["paperId"])
            if data is None:
                continue
            refs = []
            for x in data:
                if x["paperId"] not in atlas_pids or x["paperId"] == r["s2"]["paperId"]:
                    continue
                ctx = [" ".join(c.split())[:MAX_CHARS] for c in x["contexts"][:MAX_CTX]]
                refs.append({"paperId": x["paperId"], "contexts": ctx, "intents": x["intents"], "influential": x["influential"]})
                n_routes += 1
                n_ctx += bool(ctx)
            n_works += 1
            f.write(json.dumps({"id": r["id"], "refs": refs}, ensure_ascii=False) + "\n")
    with open(os.path.join(CG, "contexts-meta.json"), "w", encoding="utf-8") as f:
        json.dump({"citingWorksFetched": n_works, "citingWorksWithReferences": len(todo), "atlasRoutes": n_routes, "withSentence": n_ctx,
                   "observedOn": time.strftime("%Y-%m-%d")}, f)
    print(f"contexts.jsonl: {n_works} of {len(todo)} citing works, {n_routes} Atlas routes, {n_ctx} with a citing sentence", flush=True)


if __name__ == "__main__":
    main()
