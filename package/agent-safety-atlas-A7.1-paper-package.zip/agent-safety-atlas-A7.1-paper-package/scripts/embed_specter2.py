#!/usr/bin/env python3
"""
SPECTER2 document embeddings for the Research paths star map (title + [SEP] + abstract, proximity adapter, CLS vector),
the model setup published by AllenAI for paper similarity (https://huggingface.co/allenai/specter2).

Text per active Atlas work, in order of preference (recorded per work in text-sources.json):
  1. the original abstract kept with the screening input (candidate id, or arxiv:<id>)
  2. the abstract quoted from the source version in the Atlas record
  3. the Semantic Scholar abstract (research-paths/citation-graph/works.jsonl)
  4. the Atlas editorial summary (marked as such; used only when no abstract is available)

Runs in its own environment because SPECTER2 needs the `adapters` library:
  ../../.venv-specter2/bin/python embed_specter2.py
Output: research-paths/starmap/embeddings.npy (float32, L2-normalised), embedding-ids.json, text-sources.json, texts.jsonl, model.json
"""
import glob
import json
import os

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening"))
OUT = os.path.join(HERE, "research-paths", "starmap")


def texts():
    atlas = json.load(open(os.path.join(HERE, "dist/data/atlas.json"), encoding="utf-8"))
    works = [p for p in atlas["papers"] if p["status"] == "included" and not p["attributes"].get("withdrawal")]
    ab = {}
    files = [os.path.join(SCR, "firstpass_input.jsonl"), os.path.join(SCR, "review_input.jsonl")] + \
        sorted(glob.glob(os.path.join(SCR, "batches", "*", "input.jsonl"))) + sorted(glob.glob(os.path.join(SCR, "candidates_*.jsonl")))
    for f in files:
        if not os.path.exists(f):
            continue
        for line in open(f, encoding="utf-8"):
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if r.get("candidate_id") and r.get("abstract") and len(r["abstract"]) > 80:
                ab.setdefault(r["candidate_id"], r["abstract"])
    s2 = {}
    wpath = os.path.join(HERE, "research-paths", "citation-graph", "works.jsonl")
    if os.path.exists(wpath):
        for line in open(wpath, encoding="utf-8"):
            r = json.loads(line)
            if (r.get("s2") or {}).get("abstract"):
                s2[r["id"]] = r["s2"]["abstract"]
    out = []
    for p in works:
        a = p["attributes"]
        keys = [a.get("source_candidate_id")] + (["arxiv:" + a["arxiv_id"]] if a.get("arxiv_id") else [])
        hit = next((k for k in keys if k and k in ab), None)
        sva = a.get("source_version_abstract") or {}
        if hit:
            body, src = ab[hit], "screening_input_abstract"
        elif sva.get("text") or sva.get("excerpt"):
            body, src = sva.get("text") or sva.get("excerpt"), "source_version_abstract"
        elif p["id"] in s2:
            body, src = s2[p["id"]], "semantic_scholar_abstract"
        else:
            body, src = p.get("summary") or "", "atlas_editorial_summary"
        out.append((p["id"], p.get("originalTitle") or p["title"], " ".join(body.split()), src))
    return out


def main():
    from adapters import AutoAdapterModel
    from transformers import AutoTokenizer
    os.makedirs(OUT, exist_ok=True)
    rows = texts()
    tok = AutoTokenizer.from_pretrained("allenai/specter2_base")
    model = AutoAdapterModel.from_pretrained("allenai/specter2_base")
    model.load_adapter("allenai/specter2", source="hf", load_as="specter2", set_active=True)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(dev).eval()
    vecs = []
    with torch.no_grad():
        for i in range(0, len(rows), 64):
            batch = [t + tok.sep_token + b for _, t, b, _ in rows[i:i + 64]]
            enc = tok(batch, padding=True, truncation=True, return_tensors="pt", return_token_type_ids=False, max_length=512).to(dev)
            vecs.append(model(**enc).last_hidden_state[:, 0, :].float().cpu().numpy())
    emb = np.concatenate(vecs)
    emb /= np.linalg.norm(emb, axis=1, keepdims=True)
    np.save(os.path.join(OUT, "embeddings.npy"), emb.astype(np.float32))
    json.dump([r[0] for r in rows], open(os.path.join(OUT, "embedding-ids.json"), "w"))
    json.dump({r[0]: r[3] for r in rows}, open(os.path.join(OUT, "text-sources.json"), "w"))
    with open(os.path.join(OUT, "texts.jsonl"), "w", encoding="utf-8") as f:
        for pid, title, body, src in rows:
            f.write(json.dumps({"id": pid, "title": title, "text": body, "source": src}, ensure_ascii=False) + "\n")
    from collections import Counter
    json.dump({"base": "allenai/specter2_base", "adapter": "allenai/specter2 (proximity)",
               "baseRevision": getattr(model.config, "_commit_hash", None), "input": "title [SEP] abstract, max 512 tokens, CLS",
               "normalised": "L2", "works": len(rows), "textSources": Counter(r[3] for r in rows), "device": dev},
              open(os.path.join(OUT, "model.json"), "w"), indent=1)
    print(f"embedded {len(rows)} works on {dev}: {dict(Counter(r[3] for r in rows))}")


if __name__ == "__main__":
    main()
