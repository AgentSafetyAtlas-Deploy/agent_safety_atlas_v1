#!/usr/bin/env python3
"""The paper's question structure (owner, 2026-10-21): does the fast growth of agent-safety research accumulate knowledge?

Accumulation is read as four conditions, one per research question:
  RQ1 扩展  new safety problems are recognised (growth opens new problems rather than only densifying known ones)
  RQ2 回应  risks meet defences, and the defences carry evidence (the evidence ladder replaces a "solve rate")
  RQ3 流动  knowledge moves between directions (inheritance from older traditions, routes and their order)
  RQ4 沉淀  contributions stay in use after attention moves on, and claims are revised when challenged
Every sub-question is one card in the shape of evidence_analysis._card: denominator and missing, statistics, verbatim
evidence, support and counter cases, results under other definitions; null results are kept.

Units
  safety problem   safety requirement (axes label safety_primary, owner's scheme 8) x risk mechanism x scenario
                   fine: requirement x entry surface (facet "surfaces"; the risk origin when no entry applies) x setting
                   coarse: requirement x risk origin (axes) x agent kind (axes)
  risk             adversarial threats and failures without an attacker; RQ2 covers both (51% of defence cards have no
                   adversary)
  response         a defence aimed at the same risk; no citation between them is required; "responds to a work" is said
                   only where the defence cites it
Evidence rule for the whole paper: order in time and asymmetric citation are clues only; "caused" or "responded to a work"
needs a citation, an adoption record or a case.
Periods are calendar years (879 works carry only a year); the last year is partial (cut-off in meta) and is shown but left
out of trend tests.
"""
import datetime as dt
import json
import math
import os
import random
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from evidence_analysis import _card, _norm_name, _pct, _records  # noqa: E402

SEED = 20261021
FIRST_YEAR = 2019
SAFETY = ["goal_intent_alignment", "information_state_integrity", "authorization_information_boundary", "action_consequence_safety",
          "oversight_correctability", "collaboration_composition", "safety_under_update", "comprehensive"]
ORIGIN = ["human_adversarial", "human_non_adversarial", "agent_internal", "human_agent_interaction", "multi_agent_emergent"]
COMPONENTS = ["model", "retrieval", "memory", "tools_interfaces", "execution_environment", "communication_interface"]
STAGES = ["prevention", "runtime_detection", "formal_guarantee", "after_the_fact"]
THREAT_ROLES = ("attack", "measurement", "benchmark")
WEB_BROWSER = re.compile(r"\b(web|browser|browsing) agents?\b|computer[- ]use|\bGUI agents?\b|web navigation|agentic browser", re.I)
WEB_OBJECTS = ["browser", "tools", "webContent", "memory"]


def _r(x, d=3):
    return None if x is None else round(x, d)


class Ctx:
    """per-work labels gathered once: years, roles, the two axes, facets, authors"""

    def __init__(self, U, facets, axes):
        self.U, self.F, self.X = U, facets, axes
        self.n = U.n
        self.asof = U.asof
        self.last = U.asof.year                      # partial year
        self.years = list(range(FIRST_YEAR, self.last + 1))
        self.authors = [{_norm_name(a) for a in (U.byid[pid].get("authors") or []) if isinstance(a, str) and a.strip()} for pid in U.ids]
        self.text = [((U.title[i] or "") + " . " + ((U.s2[i] or {}).get("abstract") or "")) for i in range(U.n)]

    def role(self, i):
        return (self.F.get(i) or {}).get("role_primary")

    def roles(self, i):
        f = self.F.get(i) or {}
        return {f.get("role_primary")} | set(f.get("role_secondary") or [])

    def safety(self, i):
        return (self.X.get(i) or {}).get("safety_primary")

    def origin(self, i):
        return (self.X.get(i) or {}).get("risk_origin_primary")

    def agent(self, i):
        return (self.X.get(i) or {}).get("agent_kind")

    def adversarial(self, i):
        x = self.X.get(i) or {}
        return "human_adversarial" in [x.get("risk_origin_primary")] + list(x.get("risk_origin_secondary") or [])

    def mechs(self, i):
        """the risk mechanism: the entry surfaces where the facet labels name one, otherwise the risk origin"""
        s = list((self.F.get(i) or {}).get("surfaces") or [])
        return s or (["origin:" + self.origin(i)] if self.origin(i) else [])

    def scenes(self, i):
        s = list((self.F.get(i) or {}).get("settings") or [])
        return s or (["agent:" + self.agent(i)] if self.agent(i) else [])

    def cells(self, i, fine=True):
        g = self.safety(i)
        if not g or g == "comprehensive":  # broad surveys and frameworks span every requirement
            return set()
        if fine:
            return {(g, m, s) for m in self.mechs(i) for s in self.scenes(i)}
        return {(g, self.origin(i), self.agent(i))} if self.origin(i) and self.agent(i) else set()

    def web_objects(self, i):
        """the Web objects a work on a digital agent studies (owner, 2026-10-21: answer the Web community with concrete
        objects): browsers and computer use, tools and APIs (MCP and skills included), external web content, memory and
        retrieval; empty for works outside the Web subset"""
        if self.agent(i) != "digital_agent":
            return set()
        f = self.F.get(i) or {}
        st, sf = set(f.get("settings") or []), set(f.get("surfaces") or [])
        out = set()
        if st & {"web_browser", "computer_gui_mobile"} or WEB_BROWSER.search(self.text[i]):
            out.add("browser")
        if st & {"general_tool_assistant", "mcp_skills_ecosystem"} or sf & {"tool_output", "tool_description_mcp_skills"}:
            out.add("tools")
        if "web_external_content" in sf:
            out.add("webContent")
        if "rag_memory_assistant" in st or "memory_retrieval" in sf:
            out.add("memory")
        return out

    def web(self, i):
        return bool(self.web_objects(i))

    def ref(self, i, quote=None, **kw):
        U = self.U
        return {"id": U.ids[i], "title": U.title[i], "year": U.year[i], "quote": quote, **kw}


def _d(U, i):
    return U.date[i].isoformat() if U.date[i] else None


def _rec(unit, basis, cols, rows):
    """item-level record (data/records/<key>.json) in the shape of evidence_analysis._records; cols [key, en, zh, kind]"""
    return _records(unit, basis, cols, rows)


# ======================================================================================================== RQ1 扩展
def growth_decomposition(C, fine=True, k=1, first_only=False):
    """for each year, the works in combinations that existed before the year (densifying), in a known requirement x mechanism
    pair placed in a scenario where it had not been seen (old mechanism, new scenario), or in a requirement x mechanism pair
    seen nowhere before (new at the taxonomy level). A combination exists once k works sit in it; with first_only, only the
    first work of a new combination counts as opening it (the others of the same year count as densifying)."""
    U = C.U
    order = sorted((i for i in range(C.n) if U.year[i] and C.cells(i, fine)), key=lambda i: (U.date[i], U.ids[i]))
    cell_n, pair_n = Counter(), Counter()
    rows, examples = [], defaultdict(list)
    by_year = defaultdict(list)
    for i in order:
        by_year[U.year[i]].append(i)
    before = [i for i in order if U.year[i] < FIRST_YEAR]
    for i in before:
        for c in C.cells(i, fine):
            cell_n[c] += 1
            pair_n[c[:2]] += 1
    for y in C.years:
        ws = by_year.get(y, [])
        cls = Counter()
        opened = set()
        for i in ws:
            cs = C.cells(i, fine)
            new_cells = {c for c in cs if cell_n[c] < k and (not first_only or c not in opened)}
            if not new_cells:
                cls["dense"] += 1
                continue
            new_pairs = {c[:2] for c in new_cells if pair_n[c[:2]] < k}
            kind = "newMechanism" if new_pairs else "newScene"
            cls[kind] += 1
            opened |= new_cells
            if len(examples[(y, kind)]) < 6:
                examples[(y, kind)].append((i, sorted(new_cells)[0]))
        for i in ws:  # the year's works are added after the year is classified: a combination opened this year is new all year
            for c in C.cells(i, fine):
                cell_n[c] += 1
                pair_n[c[:2]] += 1
        occupied = sum(1 for c in cell_n if cell_n[c] >= 1)
        rows.append({"year": y, "works": len(ws), "dense": cls["dense"], "newScene": cls["newScene"], "newMechanism": cls["newMechanism"],
                     "denseShare": _pct(cls["dense"], len(ws)), "newSceneShare": _pct(cls["newScene"], len(ws)), "newMechanismShare": _pct(cls["newMechanism"], len(ws)),
                     "cellsOccupied": occupied, "partial": y == C.last})
    return rows, examples


def rarefied_cells(C, fine=True, size=150, reps=200, seed=SEED):
    """distinct combinations among `size` works drawn from each year (diversity at equal volume) and the concentration of the
    year's works over combinations (HHI over cell memberships)"""
    rnd = random.Random(seed)
    out = []
    for y in C.years:
        ws = [i for i in range(C.n) if C.U.year[i] == y and C.cells(i, fine)]
        if len(ws) < size:
            out.append({"year": y, "works": len(ws), "cells": None})
            continue
        vals = []
        cl = {i: sorted(C.cells(i, fine)) for i in ws}
        for _ in range(reps):  # one combination drawn per work, so that works with more labels do not add more combinations
            s = rnd.sample(ws, size)
            vals.append(len({rnd.choice(cl[i]) for i in s}))
        vals.sort()
        cnt = Counter(c for i in ws for c in C.cells(i, fine))
        tot = sum(cnt.values())
        top10 = sum(v for _, v in cnt.most_common(10)) / tot
        out.append({"year": y, "works": len(ws), "cells": round(sum(vals) / reps, 1), "lo": vals[int(0.025 * reps)], "hi": vals[int(0.975 * reps) - 1],
                    "hhi": round(sum((v / tot) ** 2 for v in cnt.values()), 4), "top10Share": round(100 * top10, 1), "partial": y == C.last})
    return out


CELL_ZH = {}


def cell_label(c):
    return " × ".join(str(x).replace("origin:", "").replace("agent:", "") for x in c)


def rq1_growth(C):
    U = C.U
    rows, ex = growth_decomposition(C)
    full = [r for r in rows if not r["partial"] and r["year"] >= 2021]
    base = sum(r["works"] for r in rows)
    lab = sum(1 for i in range(C.n) if U.year[i] and U.year[i] >= FIRST_YEAR)
    missing = lab - base
    rare = rarefied_cells(C)
    # added works between 2023 and the last full year: where the growth went
    y0, y1 = 2023, C.last - 1
    r0 = next(r for r in rows if r["year"] == y0)
    r1 = next(r for r in rows if r["year"] == y1)
    alts = []
    for key, kw in (("coarse", {"fine": False}), ("threeWorks", {"k": 3}), ("firstOnly", {"first_only": True})):
        rr, _ = growth_decomposition(C, **kw)
        alts.append({"key": key, "rows": [{k2: r[k2] for k2 in ("year", "works", "denseShare", "newSceneShare", "newMechanismShare")} for r in rr if r["year"] >= 2021]})
    alts.append({"key": "coarseRarefied", "rows": rarefied_cells(C, fine=False)})
    ref = lambda i, c, kind: C.ref(i, (C.X.get(i) or {}).get("evidence", {}).get("safety_primary"), cell=cell_label(c), kind=kind)
    last_full = C.last - 1
    evidence = [ref(i, c, "newMechanism") for i, c in ex[(last_full, "newMechanism")][:3]]
    support = [ref(i, c, "newScene") for i, c in ex[(last_full, "newScene")][:3]] + [ref(i, c, "newMechanism") for i, c in ex[(C.last, "newMechanism")][:3]]
    dense_ex = [i for i in range(C.n) if U.year[i] == last_full and C.cells(i)][:0]
    stats = {"rows": rows, "rarefied": rare, "grew": {"from": y0, "to": y1, "works": [r0["works"], r1["works"]],
                                                      "denseShare": [r0["denseShare"], r1["denseShare"]],
                                                      "newShare": [_r(100 - (r0["denseShare"] or 0), 1), _r(100 - (r1["denseShare"] or 0), 1)]},
             "cellsPossible": len(SAFETY) * 12 * 13}
    return _card(base, "works with a year and labels on both axes (since %d)" % FIRST_YEAR, missing, lab, "works without a safety requirement or a mechanism label",
                 stats, evidence=evidence, support=support, counter=[], alt=alts)


NEW_NAMES = {
    "mcp": (r"\bMCP\b|Model Context Protocol", 0),
    "skills": (r"\bagent skills?\b|\bSKILL\.md\b|\bskills? (ecosystem|marketplace|supply|hub|store)|Claude Skills|\bskill (poisoning|injection|registr|file)|malicious skills?|third-party skills?", re.I),
    "a2a": (r"\bA2A\b|Agent2Agent|agent-to-agent protocol", 0),
    "openclaw": (r"OpenClaw|Clawdbot|Moltbot|Moltbook", re.I),
    "computerUse": (r"computer[- ]use|\bCUAs?\b|computer-using agent", re.I),
}
NAME_LAUNCH = {"computerUse": "2024-10-22", "mcp": "2024-11-25", "a2a": "2025-04-09", "skills": "2025-10-16", "openclaw": None}


def floor_of(k):
    """works and repositories count for a name from three months before its launch (earlier hits are other uses of the word)"""
    d = NAME_LAUNCH.get(k)
    if not d:
        return None
    d = dt.date.fromisoformat(d)
    return dt.date(d.year - (1 if d.month <= 3 else 0), (d.month - 4) % 12 + 1, 1)


def new_name_works(C):
    out = defaultdict(set)
    for i in range(C.n):
        for k, (p, fl) in NEW_NAMES.items():
            f = floor_of(k)
            if re.search(p, C.text[i], fl) and not (f and C.U.date[i] and C.U.date[i] < f):
                out[k].add(i)
    return out


def rq1_novel_names(C, readings=None, rec=None):
    """1b: works under the new system names (MCP, skills, A2A, OpenClaw, computer use): which known mechanism they study,
    and how many argue for a failure that only the new system makes possible (novelty_readings.py on title and abstract;
    without the readings, only the taxonomy view: the requirement x mechanism pairs these works sit in, and whether each pair
    existed before the name's first work)"""
    U = C.U
    sets = new_name_works(C)
    allw = sorted(set().union(*sets.values()))
    per = {}
    for k, ws in sets.items():
        ws = sorted(ws, key=lambda i: U.date[i] or dt.date.max)
        if not ws:
            continue
        first = U.date[ws[0]]
        pairs = Counter(c[:2] for i in ws for c in C.cells(i))
        before = {c[:2] for i in range(C.n) if U.date[i] and U.date[i] < first for c in C.cells(i)}
        old = sum(v for p, v in pairs.items() if p in before)
        per[k] = {"works": len(ws), "first": first.isoformat(), "launch": NAME_LAUNCH.get(k),
                  "pairMemberships": sum(pairs.values()), "inOldPairs": _pct(old, sum(pairs.values())),
                  "topPairs": [[cell_label(p), v] for p, v in pairs.most_common(5)],
                  "roles": Counter(C.role(i) for i in ws).most_common()}
    stats = {"names": per, "works": len(allw)}
    R = readings or {}
    read = [i for i in allw if U.ids[i] in R]
    if read:
        cls = Counter(R[U.ids[i]].get("novelty") for i in read)
        mech = Counter(R[U.ids[i]].get("known_mechanism") for i in read)
        stats["readings"] = {"read": len(read), "novelty": dict(cls), "share": {k: _pct(v, len(read)) for k, v in cls.items()},
                             "mechanisms": mech.most_common(), "relates": _pct(sum(1 for i in read if R[U.ids[i]].get("relates_to_known") == "yes"), len(read)),
                             "byName": {k: dict(Counter(R[U.ids[i]].get("novelty") for i in sets[k] if U.ids[i] in R)) for k in sets}}
    rd = lambda i: R.get(U.ids[i]) or {}
    if rec is not None:
        rec["P1b"] = _rec(["work naming a new component", "提到新组件的工作"], ["Title and abstract read by Claude Opus 5.5 (novelty-v1)", "Claude Opus 5.5 读标题与摘要（novelty-v1）"],
                          [["names", "Component named", "提到的组件", "text"], ["novelty", "Kind of failure", "失效类别", "text"], ["mechanism", "Closest known mechanism", "最接近的已知机制", "text"],
                           ["relates", "Abstract relates to earlier problems", "摘要联系已有问题", "text"], ["aspect", "What is new", "新在哪里", "text"]],
                          [[U.ids[i], _d(U, i), [", ".join(k for k, v in sets.items() if i in v), rd(i).get("novelty"), rd(i).get("known_mechanism"), rd(i).get("relates_to_known"), rd(i).get("novel_aspect")],
                            rd(i).get("evidence"), [] if U.ids[i] in R else ["novelty"]] for i in allw])
    ev = [C.ref(i, rd(i).get("evidence"), novelty=rd(i).get("novelty"), mechanism=rd(i).get("known_mechanism"), note=rd(i).get("novel_aspect")) for i in read if rd(i).get("novelty") == "new_mechanism"][:6]
    sup = [C.ref(i, rd(i).get("evidence"), novelty=rd(i).get("novelty"), mechanism=rd(i).get("known_mechanism")) for i in read if rd(i).get("novelty") == "known_same_form"][:6]
    ctr = [C.ref(i, rd(i).get("evidence"), novelty=rd(i).get("novelty"), mechanism=rd(i).get("known_mechanism"), note=rd(i).get("novel_aspect")) for i in read if rd(i).get("novelty") == "known_new_form"][:6]
    return _card(len(read) if read else len(allw), "works naming MCP, agent skills, A2A, OpenClaw or computer use in title or abstract",
                 len(allw) - len(read), len(allw), "works not read yet" if read else "readings pending",
                 stats, evidence=ev, support=sup, counter=ctr)


def first_author_dates(C):
    """for each author, the date of their first Atlas work"""
    first = {}
    for i in range(C.n):
        d = C.U.date[i]
        if not d:
            continue
        for a in C.authors[i]:
            if a not in first or d < first[a]:
                first[a] = d
    return first


def rq1_pioneers(C, oss=None, rec=None):
    """1c: do teams new to the Atlas open new combinations more often than incumbent teams? A work is by newcomers when
    none of its authors has an earlier Atlas work. Open-source side: for each new system name, the first repositories of the
    ecosystem (new functions) and of agent security (attack surfaces and defences) against the first papers."""
    U = C.U
    first = first_author_dates(C)
    rows_y, ex = growth_decomposition(C)
    # classify each work as in growth_decomposition, keeping the per-work class
    order = sorted((i for i in range(C.n) if U.year[i] and C.cells(i)), key=lambda i: (U.date[i], U.ids[i]))
    cell_n, pair_n = Counter(), Counter()
    kind = {}
    by_year = defaultdict(list)
    for i in order:
        by_year[U.year[i]].append(i)
    for y in sorted(by_year):
        for i in by_year[y]:
            if y >= FIRST_YEAR:
                nc = {c for c in C.cells(i) if cell_n[c] < 1}
                kind[i] = "dense" if not nc else ("newMechanism" if any(pair_n[c[:2]] < 1 for c in nc) else "newScene")
        for i in by_year[y]:
            for c in C.cells(i):
                cell_n[c] += 1
                pair_n[c[:2]] += 1
    newcomer = {i: bool(C.authors[i]) and all(first.get(a) == U.date[i] for a in C.authors[i]) for i in kind}
    if rec is not None:
        name = {"dense": "existing", "newScene": "known pair, new scenario", "newMechanism": "new pair"}
        rec["P1a"] = _rec(["work since %d with labels on both axes" % FIRST_YEAR, "%d 年以来两类标签齐全的工作" % FIRST_YEAR],
                          ["Combinations of requirement x mechanism x scenario from the axis and facet labels; class against all earlier works", "按轴标签与分面标签得到的目标 × 机制 × 场景组合；与之前所有工作比较得出类别"],
                          [["year", "Year", "年份", "num"], ["class", "Class", "类别", "text"], ["newcomer", "Newcomer team", "新进入团队", "text"],
                           ["combos", "Combinations", "组合", "text"]],
                          [[U.ids[i], _d(U, i), [U.year[i], name[kind[i]], "yes" if newcomer[i] else "no", "; ".join(cell_label(c) for c in sorted(C.cells(i))[:4])], None, []]
                           for i in sorted(kind, key=lambda i: (U.date[i], U.ids[i]))])
    rows = []
    mh_num = mh_den = 0.0
    for y in C.years:
        ws = [i for i in kind if U.year[i] == y and C.authors[i]]
        a = [i for i in ws if newcomer[i]]
        b = [i for i in ws if not newcomer[i]]
        na, nb = sum(kind[i] != "dense" for i in a), sum(kind[i] != "dense" for i in b)
        rows.append({"year": y, "newcomerWorks": len(a), "incumbentWorks": len(b), "newcomerOpens": _pct(na, len(a)), "incumbentOpens": _pct(nb, len(b)),
                     "newcomerShare": _pct(len(a), len(ws)), "partial": y == C.last})
        if a and b and y != C.last:
            n = len(a) + len(b)  # Mantel-Haenszel risk difference across years
            w = len(a) * len(b) / n
            mh_num += w * (na / len(a) - nb / len(b))
            mh_den += w
    opened = [i for i in kind if kind[i] != "dense" and U.year[i] and U.year[i] < C.last]
    by_new = [i for i in opened if newcomer.get(i)]
    stats = {"rows": rows, "mhDifference": _r(100 * mh_num / mh_den, 1) if mh_den else None,
             "openedByNewcomers": _pct(len(by_new), len(opened)), "opened": len(opened),
             "newcomerWorksShare": _pct(sum(1 for i in kind if newcomer[i] and U.year[i] < C.last), sum(1 for i in kind if U.year[i] < C.last))}
    if oss:
        stats["oss"] = oss_timing(C, oss)
    ev = [C.ref(i, None, kind=kind[i]) for i in sorted(by_new, key=lambda i: U.date[i], reverse=True)[:4]]
    base = sum(1 for i in kind if C.authors[i])
    return _card(base, "works with authors and labels on both axes (since %d)" % FIRST_YEAR, len(kind) - base, len(kind), "works without an author list",
                 stats, evidence=ev, alt=[{"key": "institutionNewcomers", "value": None}])


def oss_timing(C, oss):
    """first and median creation months of ecosystem and agent-security repositories naming each new system, against papers"""
    U = C.U
    sets = new_name_works(C)
    out = {}
    for k, (p, fl) in NEW_NAMES.items():
        rx = re.compile(p, fl)
        f = floor_of(k)
        rs = [r for r in oss["repos"] if r.get("createdAt") and rx.search((r.get("description") or "") + " " + " ".join(r.get("topics") or []) + " " + (r.get("repo") or ""))
              and not (f and r["createdAt"][:10] < f.isoformat())]
        eco = sorted(r["createdAt"][:10] for r in rs if r.get("group") == "ecosystem")
        sec = sorted(r["createdAt"][:10] for r in rs if r.get("group") == "agent_security")
        pap = sorted(U.date[i].isoformat() for i in sets.get(k, ()) if U.date[i] and U.prec[i] == "day")
        q = lambda xs, f: xs[min(len(xs) - 1, int(f * len(xs)))] if xs else None
        out[k] = {"launch": NAME_LAUNCH.get(k), "ecosystem": [len(eco), q(eco, 0), q(eco, 0.1), q(eco, 0.5)],
                  "security": [len(sec), q(sec, 0), q(sec, 0.1), q(sec, 0.5)], "papers": [len(pap), q(pap, 0), q(pap, 0.1), q(pap, 0.5)]}
    return out


def rq1_early(prev):
    """1d: whether early signals pick the problems that grow; taken from the observation report of the same analysis
    (tail backtest and the salience test) rather than recomputed"""
    tail = (prev or {}).get("tail") or {}
    bt = (tail.get("backtest") or [{}])[0]
    rq1 = (prev or {}).get("rq1") or {}
    table = ((rq1.get("pilot") or {}).get("table")) or []
    return _card(bt.get("tailTerms"), "tail terms a year before the backtest point", None, None, None,
                 {"backtest": {k: bt.get(k) for k in ("rose", "roseFromTailOrAbsent", "tailTerms", "tailRose", "baseRate")}, "rankers": table,
                  "signals": bt.get("signals"), "t0": bt.get("t0"), "examples": (bt.get("examples") or [])[:6]})


# ======================================================================================================== RQ2 回应
def kaplan_meier(times):
    """times: [(months, observed)]; returns [(t, S(t))] and the median (None when S never reaches 0.5)"""
    ts = sorted(times)
    n = len(ts)
    s, curve, med = 1.0, [(0, 1.0)], None
    k = 0
    while k < n:
        t = ts[k][0]
        d = sum(1 for x in ts[k:] if x[0] == t and x[1])
        m = sum(1 for x in ts[k:] if x[0] == t)
        if d:
            s *= 1 - d / (n - k)
            curve.append((t, round(s, 4)))
            if med is None and s <= 0.5:
                med = t
        k += m
    return curve, med


def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month) + (b.day - a.day) / 30.0


def rq2_sources(C, protocol=None, chains=None, rec=None):
    """2a: where the risks come from, on the threat side (attack, measurement and benchmark works): origin, entry surface
    (adversarial works), the components harmed and the harm domains, by year; and the entry -> effect chains the protocol
    cards record (passages of full texts)"""
    U = C.U
    T = [i for i in range(C.n) if C.role(i) in THREAT_ROLES and C.X.get(i) and U.year[i] and U.year[i] >= 2021]
    rows = []
    for y in range(2021, C.last + 1):
        ws = [i for i in T if U.year[i] == y]
        adv = [i for i in ws if C.adversarial(i)]
        rows.append({"year": y, "works": len(ws), "partial": y == C.last,
                     "origin": {o: _pct(sum(1 for i in ws if C.origin(i) == o), len(ws)) for o in ORIGIN},
                     "entry": {s: _pct(sum(1 for i in adv if s in ((C.F.get(i) or {}).get("surfaces") or [])), len(adv)) for s in C_SURFACES},
                     "components": {c: _pct(sum(1 for i in ws if c in ((C.X.get(i) or {}).get("components") or [])), len(ws)) for c in COMPONENTS},
                     "adversarial": _pct(len(adv), len(ws))})
    if rec is not None:
        rec["P2a"] = _rec(["attack, measurement or benchmark work (2021 on)", "攻击、测量或基准工作（2021 年起）"], ["Axis labels (origin, components, harm domains) and facet labels (entry points)", "轴标签（风险来源、受影响组件、伤害领域）与分面标签（入口）"],
                          [["role", "Role", "角色", "text"], ["origin", "Risk origin", "风险来源", "text"], ["entries", "Entry points", "入口", "text"],
                           ["components", "Components harmed", "受影响组件", "text"], ["harm", "Harm domains", "伤害领域", "text"]],
                          [[U.ids[i], _d(U, i), [C.role(i), C.origin(i), ", ".join((C.F.get(i) or {}).get("surfaces") or []), ", ".join((C.X.get(i) or {}).get("components") or []),
                                                 ", ".join((C.X.get(i) or {}).get("harm_domains") or [])], ((C.X.get(i) or {}).get("evidence") or {}).get("safety_primary"), []] for i in T])
    chain = Counter()
    if protocol:
        for pid, d in protocol.items():
            for t in ((chains or {}).get(pid) or d).get("cross_component_tests") or []:
                chain[(t.get("entry"), t.get("effect"))] += 1
    ev = []
    for pid, d in list((chains or {}).items())[:3]:
        i = U.pos.get(pid)
        t = (d.get("cross_component_tests") or [{}])[0]
        if i is not None:
            ev.append(C.ref(i, t.get("evidence"), chain="%s → %s" % (t.get("entry"), t.get("effect"))))
    return _card(len(T), "attack, measurement and benchmark works with axis labels (2021 on)", None, None, None,
                 {"rows": rows, "chains": [[a, b, v] for (a, b), v in chain.most_common(25)]}, evidence=ev)


C_SURFACES = ["direct_instruction", "web_external_content", "tool_output", "tool_description_mcp_skills", "memory_retrieval", "multi_agent_communication",
              "code_system_execution", "permissions_credentials", "training_data_weights", "physical_sensing_environment", "human_interface_oversight"]
MECHS = ["detection_filtering", "prompt_architecture_design", "training_alignment", "isolation_least_privilege", "information_flow_formal", "runtime_monitoring", "human_approval"]


def shift_share(C, ws_a, ws_b, strata, outcome):
    """change in the share of an outcome between two sets of works, split into a between-strata part (the mix of strata
    moved) and a within-strata part (the outcome changed inside strata); strata(i) is a list (fractional membership)"""
    def tab(ws):
        w, p = Counter(), Counter()
        for i in ws:
            st = strata(i) or ["none"]
            for s in st:
                w[s] += 1 / len(st)
                p[s] += outcome(i) / len(st)
        tot = sum(w.values()) or 1
        return {s: w[s] / tot for s in w}, {s: (p[s] / w[s] if w[s] else 0) for s in w}
    wa, pa = tab(ws_a)
    wb, pb = tab(ws_b)
    S = set(wa) | set(wb)
    sa = sum(wa.get(s, 0) * pa.get(s, 0) for s in S)
    sb = sum(wb.get(s, 0) * pb.get(s, 0) for s in S)
    between = sum((wb.get(s, 0) - wa.get(s, 0)) * pa.get(s, pb.get(s, 0)) for s in S)
    within = sum(wa.get(s, 0) * (pb.get(s, 0) - pa.get(s, 0)) for s in S if s in pa and s in pb)
    return {"from": round(100 * sa, 1), "to": round(100 * sb, 1), "change": round(100 * (sb - sa), 1),
            "between": round(100 * between, 1), "within": round(100 * within, 1), "rest": round(100 * (sb - sa - between - within), 1)}


def rq2_defence(C, rec=None):
    """2b: how defences respond: the stage they act at, whether the components they guard match those the threats harm,
    whether the change in defence strategy comes from new scenarios or from changes inside a scenario, and the response
    lag from the first threat work in a combination to its first defence and first benchmark"""
    U = C.U
    D = [i for i in range(C.n) if C.role(i) == "defense" and C.X.get(i) and U.year[i]]
    T = [i for i in range(C.n) if C.role(i) in THREAT_ROLES and C.X.get(i) and U.year[i]]
    stage = lambda i: (C.X.get(i) or {}).get("defense_stage") or []
    by_year = []
    for y in range(2021, C.last + 1):
        ws = [i for i in D if U.year[i] == y]
        by_year.append({"year": y, "defences": len(ws), "partial": y == C.last, **{s: _pct(sum(1 for i in ws if s in stage(i)), len(ws)) for s in STAGES}})
    req = []
    for g in SAFETY[:-1]:
        t = [i for i in T if C.safety(i) == g]
        d = [i for i in D if C.safety(i) == g]
        comp = {c: [_pct(sum(1 for i in t if c in (C.X[i].get("components") or [])), len(t)), _pct(sum(1 for i in d if c in (C.X[i].get("components") or [])), len(d))] for c in COMPONENTS}
        req.append({"requirement": g, "threat": len(t), "defence": len(d), "ratio": _r(len(d) / len(t), 2) if t else None,
                    "stages": {s: _pct(sum(1 for i in d if s in stage(i)), len(d)) for s in STAGES}, "components": comp,
                    "gap": max(((c, v[0] - v[1]) for c, v in comp.items() if v[0] is not None and v[1] is not None), key=lambda x: x[1], default=(None, None))})
    # entry surfaces: threats against defences that name the same entry
    ent = []
    for s in C_SURFACES:
        t = sum(1 for i in T if s in ((C.F.get(i) or {}).get("surfaces") or []))
        d = sum(1 for i in D if s in ((C.F.get(i) or {}).get("surfaces") or []))
        ent.append({"entry": s, "threat": t, "defence": d, "ratio": _r(d / t, 2) if t else None})
    # composition: defence mechanisms 2023-24 against 2025-26, strata = settings
    early = [i for i in D if U.year[i] in (2023, 2024)]
    late = [i for i in D if U.year[i] in (2025, 2026)]
    sets = lambda i: (C.F.get(i) or {}).get("settings") or []
    mech = lambda m: (lambda i: 1.0 if m in ((C.F.get(i) or {}).get("mechanisms") or []) else 0.0)
    comp_mech = {m: shift_share(C, early, late, sets, mech(m)) for m in MECHS}
    comp_stage = {s: shift_share(C, early, late, sets, (lambda i, s=s: 1.0 if s in stage(i) else 0.0)) for s in STAGES}
    comp_mech_req = {m: shift_share(C, early, late, lambda i: [C.safety(i)], mech(m)) for m in MECHS}
    # response lag over requirement x mechanism pairs
    lag = response_lag(C, T, D, rec=rec)
    stats = {"byYear": by_year, "requirements": req, "entries": ent, "composition": {"mechanismBySetting": comp_mech, "stageBySetting": comp_stage,
             "mechanismByRequirement": comp_mech_req, "early": len(early), "late": len(late)}, "lag": lag,
             "afterTheFact": _pct(sum(1 for i in D if "after_the_fact" in stage(i)), len(D))}
    aft = [i for i in D if "after_the_fact" in stage(i)]
    ev = [C.ref(i, None, stage="after_the_fact") for i in sorted(aft, key=lambda i: -(C.U.cites[i] or 0))[:4]]
    return _card(len(D), "defence works with axis labels", None, None, None, stats, evidence=ev)


def response_lag(C, T, D, fine=False, rec=None):
    U = C.U
    B = [i for i in range(C.n) if C.role(i) == "benchmark" and C.X.get(i) and U.date[i]]
    key = (lambda i: {c for c in C.cells(i)}) if fine else (lambda i: {c[:2] for c in C.cells(i)})
    first = {"threat": {}, "defence": {}, "benchmark": {}}
    who = {"threat": {}, "defence": {}, "benchmark": {}}
    for name, ws in (("threat", T), ("defence", D), ("benchmark", B)):
        for i in ws:
            d = U.date[i]
            if not d:
                continue
            for k in key(i):
                if k not in first[name] or d < first[name][k]:
                    first[name][k] = d
                    who[name][k] = i
    if rec is not None:
        rows = []
        for k, t0 in sorted(first["threat"].items(), key=lambda x: x[1]):
            t1 = first["defence"].get(k)
            state = "defence first" if t1 is not None and t1 <= t0 else ("observed" if t1 is not None else "censored")
            m = months_between(t0, t1 if t1 is not None else C.asof)
            rows.append([cell_label(k), t0.isoformat(), [U.ids[who["threat"][k]], U.ids[who["defence"][k]] if k in who["defence"] else None, t1.isoformat() if t1 else None,
                                                         first["benchmark"][k].isoformat() if k in first["benchmark"] else None, round(m, 1), state], None, []])
        rec["P2b"] = _rec(["requirement x mechanism pair with threat work", "有威胁工作的目标 × 机制组合"], ["First dated threat-side work, defence and benchmark in each pair", "每个组合中最早的威胁侧工作、防御与基准"],
                          [["threatWork", "First threat work", "首个威胁工作", "paper"], ["defenceWork", "First defence", "首个防御", "paper"], ["defenceDate", "Defence date", "防御日期", "text"],
                           ["benchmarkDate", "First benchmark", "首个基准日期", "text"], ["months", "Months to defence (or to cut-off)", "到防御（或截止日）的月数", "num"], ["state", "State", "状态", "text"]], rows)
    out = {}
    for tgt in ("defence", "benchmark"):
        rows = []
        cohorts = defaultdict(list)
        before = 0
        for k, t0 in first["threat"].items():
            t1 = first[tgt].get(k)
            if t1 is not None and t1 <= t0:
                before += 1
                continue
            obs = t1 is not None
            m = months_between(t0, t1 if obs else C.asof)
            rows.append((round(m, 1), obs))
            cohorts[min(max(t0.year, 2022), C.last)].append((round(m, 1), obs))
        curve, med = kaplan_meier(rows)
        out[tgt] = {"combos": len(first["threat"]), "firstBefore": before, "after": len(rows), "observed": sum(1 for r in rows if r[1]), "median": med,
                    "at12": next((s for t, s in reversed(curve) if t <= 12), 1.0), "at24": next((s for t, s in reversed(curve) if t <= 24), 1.0),
                    "cohorts": {str(y): {"n": len(v), "events": sum(1 for x in v if x[1]), "median": kaplan_meier(v)[1], "medianCI": median_interval(v),
                                         "at12": next((s for t, s in reversed(kaplan_meier(v)[0]) if t <= 12), 1.0)} for y, v in sorted(cohorts.items())}}
        out[tgt]["sameDay"] = sum(1 for k, t0 in first["threat"].items() if first[tgt].get(k) == t0)
    return out


def median_interval(times, reps=2000, seed=SEED):
    """95% percentile bootstrap interval of the Kaplan-Meier median (resampling pairs); a draw whose curve never reaches 0.5
    counts as above every observed value, so an upper bound that is not reached is returned as None"""
    rnd = random.Random(seed)
    times = sorted(times)  # the draws must not depend on the order the pairs were met in (set order varies between runs)
    vals = []
    for _ in range(reps):
        m = kaplan_meier([rnd.choice(times) for _ in times])[1]
        vals.append(float("inf") if m is None else m)
    vals.sort()
    lo, hi = vals[int(0.025 * reps)], vals[int(0.975 * reps) - 1]
    return [None if lo == float("inf") else lo, None if hi == float("inf") else hi]


LAYER_RANK = {"output_text": 0, "tool_call": 1, "environment_state": 2, "consequence": 3}
OUTSIDE_CHECK = ("compares", "uses_artifact", "adopts_method")
BOUNDARY = ("counterevidence", "critique")


def ladder_levels(C, protocol, cites_items, cites_labels, self_bounds=None, mature_months=12):
    """2c: the evidence ladder for each defence with a protocol card.
      L1 a defence exists;
      L2 threat match: tested against an adaptive attacker (adversarial setting) / in an interactive environment, simulated
         or real (no adversary: the failure conditions have to arise);
      L3 effect and cost: the safety result is measured at the action layer or beyond (tool call, environment state,
         consequence) and utility is reported; cost (an overhead measure) is recorded alongside;
      L4 outside check: a work by none of its authors compares against it, reuses it or adopts its method;
      L5 boundary known: a failure condition is reported: outside counter-evidence or critique, or the paper's own
         statement of where it fails (boundary_readings.py, when present)
    L4 and L5 need time: they are read on defences at least `mature_months` old."""
    U = C.U
    out = {}
    engaged = defaultdict(set)
    bounded = defaultdict(list)
    for cid, it in cites_items.items():
        lab = cites_labels.get(cid)
        if not lab:
            continue
        a, b = U.pos.get(it["citing"]), U.pos.get(it["cited"])
        if a is None or b is None or (C.authors[a] & C.authors[b]):
            continue
        intents = {lab.get("intent")} | set(lab.get("also") or [])
        if intents & set(OUTSIDE_CHECK):
            engaged[b].add(a)
        if intents & set(BOUNDARY):
            bounded[b].append((a, lab.get("evidence")))
    over = re.compile(r"latenc|overhead|token|cost|compute|runtime|run time|throughput|memory|time per|seconds|\bms\b|gpu|flops|price|dollar|\$", re.I)
    for pid, d in protocol.items():
        i = U.pos.get(pid)
        if i is None or C.role(i) != "defense":
            continue
        adv = d.get("attacker_access") != "not_applicable"
        ev = (C.F.get(i) or {}).get("evaluation")
        l2 = (d.get("adaptive_attack") == "yes") if adv else (ev in ("simulated_environment", "real_system"))
        l3 = LAYER_RANK.get(d.get("primary_layer"), -1) >= 1 and d.get("utility_reported") == "yes"
        cost = any(over.search(m or "") for m in d.get("utility_metrics") or [])
        sb = (self_bounds or {}).get(pid) or {}
        age = months_between(U.date[i], C.asof) if U.date[i] else None
        out[i] = {"adv": adv, "L2": l2, "L3": l3, "cost": cost, "L4": bool(engaged.get(i)), "L5out": bool(bounded.get(i)),
                  "L5self": sb.get("states_failure") == "yes", "mature": age is not None and age >= mature_months, "age": age,
                  "L2unknown": adv and d.get("adaptive_attack") not in ("yes", "no"), "layer": d.get("primary_layer"),
                  "adaptiveEvidence": d.get("adaptive_evidence") or d.get("threat_evidence"), "boundEvidence": (bounded.get(i) or [(None, None)])[0], "selfEvidence": sb.get("evidence")}
        out[i]["L5"] = out[i]["L5out"] or out[i]["L5self"]
    return out


def rq2_outside(C, cites_items, cites_labels):
    """the two upper rungs on every defence work (not only those with a protocol card), by publication year: an outside work
    compares against it, reuses it or adopts its method (L4), or reports counter-evidence or criticism (L5, outside half),
    within 12 and 24 months and by the cut-off. Citations are read where the citing sentence was available."""
    U = C.U
    D = [i for i in range(C.n) if C.role(i) == "defense" and U.date[i] and U.prec[i] != "year"]
    first_chk, first_bd = {}, {}
    labelled_to = Counter()
    for cid, it in cites_items.items():
        lab = cites_labels.get(cid)
        a, b = U.pos.get(it["citing"]), U.pos.get(it["cited"])
        if not lab or a is None or b is None or not U.date[a]:
            continue
        labelled_to[b] += 1
        if C.authors[a] & C.authors[b]:
            continue
        intents = {lab.get("intent")} | set(lab.get("also") or [])
        if intents & set(OUTSIDE_CHECK) and (b not in first_chk or U.date[a] < first_chk[b]):
            first_chk[b] = U.date[a]
        if intents & set(BOUNDARY) and (b not in first_bd or U.date[a] < first_bd[b]):
            first_bd[b] = U.date[a]
    rows = []
    for y in range(2020, C.last + 1):
        ws = [i for i in D if U.year[i] == y]
        row = {"year": y, "defences": len(ws), "partial": y == C.last}
        for name, f in (("check", first_chk), ("boundary", first_bd)):
            for m in (12, 24):
                el = [i for i in ws if months_between(U.date[i], C.asof) >= m]
                row["%s%d" % (name, m)] = _pct(sum(1 for i in el if i in f and months_between(U.date[i], f[i]) <= m), len(el)) if len(el) >= 20 else None
            row[name + "Ever"] = _pct(sum(1 for i in ws if i in f), len(ws))
        rows.append(row)
    cited = sum(1 for i in D if U.cited_by[i])
    lab = sum(1 for i in D if labelled_to[i])
    return _card(len(D), "defence works with a day-precise date", cited - lab, cited, "cited defences none of whose citing sentences could be read",
                 {"rows": rows, "checked": _pct(sum(1 for i in D if i in first_chk), len(D)), "bounded": _pct(sum(1 for i in D if i in first_bd), len(D))})


def rq2_ladder(C, protocol, cites_items, cites_labels, self_bounds=None, rec=None):
    L = ladder_levels(C, protocol, cites_items, cites_labels, self_bounds)
    U = C.U
    if rec is not None:
        yn = lambda v: "yes" if v else "no"
        rec["P2c"] = _rec(["defence with a protocol card", "有实验方案卡的防御"], ["Protocol card (experiment passages), citation intents of outside works, boundary reading", "实验方案卡（实验段落）、外部工作的引用用途、失效边界阅读"],
                          [["adv", "Faces an attacker", "面对攻击者", "text"], ["L2", "Tested under matching conditions", "威胁匹配", "text"], ["L3", "Effect at tool call or deeper, with utility", "效果与代价", "text"],
                           ["cost", "Overhead reported", "报告开销", "text"], ["L4", "Outside check", "外部检验", "text"], ["L5out", "Outside counter-evidence or critique", "外部反例或批评", "text"],
                           ["L5self", "States a failure condition", "写明失效条件", "text"], ["mature", "A year old or more", "满一年", "text"], ["layer", "Measured layer", "测量层次", "text"]],
                          [[U.ids[i], _d(U, i), [yn(x["adv"]), yn(x["L2"]), yn(x["L3"]), yn(x["cost"]), yn(x["L4"]), yn(x["L5out"]), yn(x["L5self"]), yn(x["mature"]), x["layer"]],
                            [["adaptive", x["adaptiveEvidence"]], ["failure", x["selfEvidence"]]] , []] for i, x in sorted(L.items(), key=lambda kv: U.ids[kv[0]])])
    keys = ["L2", "L3", "L4", "L5"]

    def summary(ws):
        n = len(ws)
        mat = [i for i in ws if L[i]["mature"]]
        prof = {k: _pct(sum(1 for i in (mat if k in ("L4", "L5") else ws) if L[i][k]), len(mat) if k in ("L4", "L5") else n) for k in keys}
        cum, alive = [], list(mat)
        cum.append(_pct(len(alive), len(mat)))
        for k in keys:
            alive = [i for i in alive if L[i][k]]
            cum.append(_pct(len(alive), len(mat)))
        return {"n": n, "mature": len(mat), "profile": prof, "ladder": cum, "ladderN": len(alive), "cost": _pct(sum(1 for i in ws if L[i]["cost"]), n)}
    ws = sorted(L)
    groups = {"all": summary(ws), "adversarial": summary([i for i in ws if L[i]["adv"]]), "noAdversary": summary([i for i in ws if not L[i]["adv"]])}
    by_req = {g: summary([i for i in ws if C.safety(i) == g]) for g in SAFETY[:-1] if sum(1 for i in ws if C.safety(i) == g) >= 15}
    by_year = {str(y): summary([i for i in ws if U.year[i] == y]) for y in range(2022, C.last + 1)}
    adv_year = {}
    for y in range(2021, C.last + 1):
        a = [i for i in ws if U.year[i] == y and L[i]["adv"]]
        adv_year[str(y)] = {"n": len(a), "adaptive": _pct(sum(1 for i in a if L[i]["L2"]), len(a)), "adaptiveUnknown": sum(1 for i in a if L[i]["L2unknown"]),
                            "utility": _pct(sum(1 for i in a if protocol[U.ids[i]].get("utility_reported") == "yes"), len(a)), "overhead": _pct(sum(1 for i in a if L[i]["cost"]), len(a)),
                            "toolLayer": _pct(sum(1 for i in a if LAYER_RANK.get(L[i]["layer"], -1) >= 1), len(a)),
                            "realSystem": _pct(sum(1 for i in a if (C.F.get(i) or {}).get("evaluation") == "real_system"), len(a)), "partial": y == C.last}
    alt = [{"key": "l2AdaptiveOrBudget", "value": _pct(sum(1 for i in ws if L[i]["adv"] and (L[i]["L2"] or (protocol[U.ids[i]].get("attacker_budget")))), sum(1 for i in ws if L[i]["adv"]))},
           {"key": "l3LayerOnly", "value": _pct(sum(1 for i in ws if LAYER_RANK.get(L[i]["layer"], -1) >= 1), len(ws))},
           {"key": "l4AllAges", "value": _pct(sum(1 for i in ws if L[i]["L4"]), len(ws))},
           {"key": "l5OutsideOnly", "value": _pct(sum(1 for i in ws if L[i]["mature"] and L[i]["L5out"]), sum(1 for i in ws if L[i]["mature"]))},
           {"key": "l2NonAdvRealOnly", "value": _pct(sum(1 for i in ws if not L[i]["adv"] and (C.F.get(i) or {}).get("evaluation") == "real_system"), sum(1 for i in ws if not L[i]["adv"]))}]
    top = [i for i in ws if L[i]["mature"] and all(L[i][k] for k in keys)]
    ev = [C.ref(i, L[i]["adaptiveEvidence"], level="L5") for i in top[:6]]
    ctr = [C.ref(i, L[i]["boundEvidence"][1], level="boundary") for i in ws if L[i]["L5out"]][:6]
    return _card(len(ws), "defences with a protocol card (full-text passages)", None, None, None,
                 {"groups": groups, "byRequirement": by_req, "byYear": by_year, "adversarialByYear": adv_year, "selfBoundsRead": sum(1 for i in ws if U.ids[i] in (self_bounds or {}))},
                 evidence=ev, counter=ctr, alt=alt), L


INJ = re.compile(r"prompt injection|injected (instruction|prompt|content)|injection attack|indirect injection", re.I)
MEM, POI = re.compile(r"memor", re.I), re.compile(r"poison|backdoor|inject|corrupt|manipulat|tamper", re.I)
CASES = {
    "injection": {"harm": 1, "label": "tool-using agents, indirect prompt injection",
                  "member": lambda C, i: C.agent(i) == "digital_agent" and bool(INJ.search(C.text[i]))},
    "memory": {"harm": 1, "label": "agent memory poisoning",
               "member": lambda C, i: C.agent(i) == "digital_agent" and bool(MEM.search(C.text[i]) and POI.search(C.text[i]))
               and ("memory_retrieval" in ((C.F.get(i) or {}).get("surfaces") or []) or "memory" in ((C.X.get(i) or {}).get("components") or []))},
    "embodied": {"harm": 2, "label": "embodied agents with a foundation model, unsafe actions",
                 "member": lambda C, i: C.agent(i) == "physical_agent" and "embodied_robot" in ((C.F.get(i) or {}).get("settings") or [])
                 and (C.X.get(i) or {}).get("decision_maker") == "foundation_model"},
}
POSITION = [("upstream", lambda m, s: bool({"isolation_least_privilege", "information_flow_formal", "prompt_architecture_design"} & m)),
            ("entry", lambda m, s: "detection_filtering" in m),
            ("model", lambda m, s: "training_alignment" in m),
            ("action", lambda m, s: bool({"runtime_monitoring", "human_approval"} & m) or "formal_guarantee" in s),
            ("after", lambda m, s: "after_the_fact" in s)]


def rq2_cases(C, protocol, ladder, routes, names, rec=None):
    """2d: three risk paths followed link by link: trigger conditions (entry surfaces, attacker access, origin) -> failure
    process (entry -> effect chains in the protocol cards, components) -> where defences intervene (upstream by design, at the
    entry, in the model, at the action, after the fact) -> how they are tested (ladder levels; measured at the layer where the
    case's harm happens: tool call for the two digital cases, environment state for embodied action)"""
    U = C.U
    bname = {j: n for n, j in names.items()} if names else {}
    out = {}
    for key, spec in CASES.items():
        ws = [i for i in range(C.n) if spec["member"](C, i)]
        thr = [i for i in ws if C.role(i) in THREAT_ROLES]
        dfs = [i for i in ws if C.role(i) == "defense"]
        bms = [i for i in ws if C.role(i) == "benchmark"]
        first = lambda xs: min((U.date[i] for i in xs if U.date[i]), default=None)
        acc = Counter(protocol[U.ids[i]].get("attacker_access") for i in ws if U.ids[i] in protocol and C.role(i) in ("attack", "defense"))
        chain = Counter()
        for i in ws:
            d = protocol.get(U.ids[i]) or {}
            for t in d.get("cross_component_tests") or []:
                chain[(t.get("entry"), t.get("effect"))] += 1
        pos = Counter()
        for i in dfs:
            m = set((C.F.get(i) or {}).get("mechanisms") or [])
            s = set((C.X.get(i) or {}).get("defense_stage") or [])
            hit = [p for p, f in POSITION if f(m, s)]
            for p in hit or ["unplaced"]:
                pos[p] += 1
        lad = [i for i in dfs if i in ladder]
        mat = [i for i in lad if ladder[i]["mature"]]
        at_harm = [i for i in lad if LAYER_RANK.get(ladder[i]["layer"], -1) >= spec["harm"]]
        bench_used = Counter(bname.get(j) or U.title[j][:40] for (i, j), r in routes.items() if r["kind"] == "use" and i in set(dfs))
        years = []
        for y in range(2023, C.last + 1):
            years.append({"year": y, "threat": sum(1 for i in thr if U.year[i] == y), "defence": sum(1 for i in dfs if U.year[i] == y),
                          "benchmark": sum(1 for i in bms if U.year[i] == y), "partial": y == C.last})
        adv = [i for i in ws if C.adversarial(i)]
        f_thr, f_def, f_bm = first(thr), first(dfs), first(bms)
        out[key] = {"label": spec["label"], "works": len(ws), "threat": len(thr), "defence": len(dfs), "benchmark": len(bms),
                    "first": {"threat": f_thr and f_thr.isoformat(), "defence": f_def and f_def.isoformat(), "benchmark": f_bm and f_bm.isoformat()},
                    "lagMonths": _r(months_between(f_thr, f_def), 1) if f_thr and f_def else None,
                    "adversarial": _pct(len(adv), len(ws)), "origin": Counter(C.origin(i) for i in ws).most_common(),
                    "entries": Counter(s for i in ws for s in ((C.F.get(i) or {}).get("surfaces") or [])).most_common(6),
                    "access": acc.most_common(), "chains": [[a, b, v] for (a, b), v in chain.most_common(8)],
                    "positions": {p: _pct(pos[p], len(dfs)) for p in [x for x, _ in POSITION] + ["unplaced"]},
                    "ladderCards": len(lad), "ladder": {k: _pct(sum(1 for i in (mat if k in ("L4", "L5") else lad) if ladder[i][k]), len(mat) if k in ("L4", "L5") else len(lad)) for k in ("L2", "L3", "L4", "L5")},
                    "adaptive": [len([i for i in lad if ladder[i]["adv"]]), _pct(sum(1 for i in lad if ladder[i]["adv"] and ladder[i]["L2"]), sum(1 for i in lad if ladder[i]["adv"]))],
                    "interactive": [len([i for i in lad if not ladder[i]["adv"]]), _pct(sum(1 for i in lad if not ladder[i]["adv"] and ladder[i]["L2"]), sum(1 for i in lad if not ladder[i]["adv"]))],
                    "atHarmLayer": _pct(len(at_harm), len(lad)), "layers": Counter(ladder[i]["layer"] for i in lad).most_common(),
                    "realSystem": _pct(sum(1 for i in dfs if (C.F.get(i) or {}).get("evaluation") == "real_system"), len(dfs)),
                    "benchmarks": bench_used.most_common(6), "years": years,
                    "examples": [C.ref(i, ladder[i]["adaptiveEvidence"] if i in ladder else None, role=C.role(i)) for i in sorted(dfs, key=lambda i: -(U.cites[i] or 0))[:4]]}
        if key == "embodied":
            nonadv = [i for i in ws if not C.adversarial(i)]
            out[key]["paths"] = {"adversarial": len(adv), "noAdversary": len(nonadv),
                                 "safety": Counter(C.safety(i) for i in ws).most_common(5)}
    if rec is not None:
        rows = []
        for key, spec in CASES.items():
            for i in range(C.n):
                if not spec["member"](C, i):
                    continue
                m = set((C.F.get(i) or {}).get("mechanisms") or [])
                st = set((C.X.get(i) or {}).get("defense_stage") or [])
                pos = [p for p, f in POSITION if f(m, st)] if C.role(i) == "defense" else []
                lv = ladder.get(i) or {}
                rows.append([U.ids[i], _d(U, i), [key, C.role(i), "yes" if C.adversarial(i) else "no", ", ".join(pos), lv.get("layer"),
                                                  ("yes" if lv.get("L2") else "no") if lv else None, (C.F.get(i) or {}).get("evaluation")], None, []])
        rec["P2d"] = _rec(["work in a risk-path case", "风险路径案例中的工作"], ["Case membership from labels and title or abstract; where defences act from mechanism and stage labels", "案例归属由标签与标题/摘要界定；介入位置由机制与阶段标签读出"],
                          [["case", "Case", "案例", "text"], ["role", "Role", "角色", "text"], ["adv", "Attacker present", "有攻击者", "text"], ["acts", "Where the defence acts", "介入位置", "text"],
                           ["layer", "Measured layer", "测量层次", "text"], ["L2", "Matching conditions", "威胁匹配", "text"], ["evaluation", "Evaluation setting", "评测环境", "text"]], rows)
    tot = sum(v["works"] for v in out.values())
    return _card(tot, "works in the three case definitions (title and abstract plus labels)", None, None, None, {"cases": out})


# ======================================================================================================== RQ3 流动
# The checklist of established safety and security mechanisms (fixed before looking at the results): how an agent defence
# is recognised as one of them, and how a reference is recognised as a classic source of it (title pattern, published up to
# CLASSIC_YEAR, before agents built on language models)
CLASSIC_YEAR = 2018
FAMILIES = [
    ("least_privilege", "least privilege and access control", {"isolation_least_privilege"}, None,
     r"least[- ]privilege|access control|permission (system|model|control|polic)|capabilit(y|ies)[- ]based|privilege separation",
     r"access control|least privilege|protection of information|capabilit(y|ies)|role-based|authori[sz]ation|discretionary|mandatory access|privilege"),
    ("sandbox", "sandboxing and isolation", set(), None, r"sandbox|isolat(ed|ion) (execution|environment|runtime)|container",
     r"sandbox|isolation|virtual machine|confinement|jail|software fault isolation"),
    ("ifc", "information-flow control and taint tracking", set(), None, r"information[- ]flow|\btaint|non-?interference|data[- ]flow (control|tracking|integrity)",
     r"information flow|\btaint|non-?interference|lattice model|secure flow|declassif"),
    ("monitor", "reference monitors and runtime verification", set(), None, r"reference monitor|runtime (verification|enforcement)|security automat|policy enforcement|enforce\w* (policies|policy)",
     r"reference monitor|security automat|runtime (verification|monitoring|enforcement)|inline reference|edit automata|execution monitor|enforceable security"),
    ("audit", "audit, logging and provenance", set(), None, r"\baudit|provenance|forensic|tamper-evident log",
     r"audit|provenance|forensic|secure log|accountab"),
    ("recovery", "rollback, recovery and fault tolerance", set(), None, r"rollback|roll back|\bundo\b|recover(y|ing) from|checkpoint|transaction|revers(ible|ibility)",
     r"rollback|recovery|checkpoint|transaction|fault[- ]toleran|undo|reversib"),
    ("formal", "formal verification", set(), "formal_guarantee", r"formal verification|model checking|temporal logic|theorem prov|formally verif",
     r"model checking|temporal logic|formal verification|theorem prov|abstract interpretation|hoare|verified|satisfiability modulo"),
    ("safe_rl", "safe reinforcement learning and shielding", set(), None, r"constrained (mdp|markov|reinforcement|policy optimi)|safe (reinforcement|exploration|rl\b)|shield(ing)?\b",
     r"constrained markov|safe (reinforcement|exploration)|shield|risk-sensitive|cmdp|constrained policy|safe policy"),
    ("barrier", "control barrier functions and reachability", set(), None, r"barrier function|reachab|hamilton[- ]jacobi|safety filter|invariant set|control barrier",
     r"barrier function|reachab|hamilton|invariant set|viability|safety filter"),
    ("human_loop", "human approval and supervisory control", {"human_approval"}, None, r"human[- ]in[- ]the[- ]loop|human approval|user confirmation|human oversight",
     r"human[- ]in[- ]the[- ]loop|mixed[- ]initiative|supervisory control|automation (bias|surprise)|levels of automation|human[- ]automation|trust in automation"),
    ("anomaly", "anomaly and intrusion detection", set(), None, r"anomal|intrusion detection|out[- ]of[- ]distribution detection",
     r"anomaly detection|intrusion detection|novelty detection|outlier detection|misuse detection"),
    ("sanitize", "input sanitisation from injection defences", set(), None, r"sanitiz|sanitis|delimit|spotlight|escap(e|ing) (input|untrusted)",
     r"sql injection|cross-site|\bxss\b|sanitiz|code injection|injection attack|input validation"),
]


def classic_refs(works_refs, rx):
    return [r for r in works_refs if (r.get("year") or 9999) <= CLASSIC_YEAR and rx.search(r.get("title") or "")]


def rq3_inherit(C, works, readings=None, rec=None):
    """3a: which established mechanisms agent defences take up, and whether they connect to the classic sources: directly (a
    classic source in their reference list), indirectly (they cite an Atlas work that cites one), or with no visible link;
    readings (inheritance_readings.py) split a sample of the last group into same mechanism with a new adaptation, surface
    similarity, and correspondence without a link"""
    U = C.U
    refs = [((works.get(pid) or {}).get("references") or []) for pid in U.ids]
    D = [i for i in range(C.n) if C.role(i) == "defense" and U.year[i]]
    fams = []
    member = {}
    for key, label, mech, stage, agent_rx, classic_rx in FAMILIES:
        arx, crx = re.compile(agent_rx, re.I), re.compile(classic_rx, re.I)
        ms = [i for i in D if (mech & set((C.F.get(i) or {}).get("mechanisms") or [])) or (stage and stage in ((C.X.get(i) or {}).get("defense_stage") or [])) or arx.search(C.text[i])]
        if mech or stage:  # the label alone over-reaches for broad mechanism classes: keep works whose text also names it
            ms = [i for i in ms if arx.search(C.text[i]) or not mech]
        direct = {i for i in range(C.n) if refs[i] and classic_refs(refs[i], crx)}
        has_refs = [i for i in ms if refs[i]]
        d = [i for i in has_refs if i in direct]
        ind = [i for i in has_refs if i not in direct and any(j in direct for j in U.refs[i])]
        none = [i for i in has_refs if i not in direct and i not in ind]
        member[key] = {"direct": d, "indirect": ind, "none": none}
        split = lambda xs, ak: [x for x in xs if C.agent(x) == ak]
        top = Counter((r.get("title") or "")[:90] for i in d for r in classic_refs(refs[i], crx)).most_common(3)
        fams.append({"key": key, "label": label, "defences": len(ms), "withRefs": len(has_refs), "direct": _pct(len(d), len(has_refs)),
                     "indirect": _pct(len(ind), len(has_refs)), "none": _pct(len(none), len(has_refs)),
                     "digital": [len(split(has_refs, "digital_agent")), _pct(len(split(d, "digital_agent")), len(split(has_refs, "digital_agent")))],
                     "physical": [len(split(has_refs, "physical_agent")), _pct(len(split(d, "physical_agent")), len(split(has_refs, "physical_agent")))],
                     "share": _pct(len(ms), len(D)), "classicTop": top})
    # reference age, all works: share of references published up to CLASSIC_YEAR, by year and agent kind
    age = []
    for y in range(2021, C.last + 1):
        row = {"year": y, "partial": y == C.last}
        for ak in ("digital_agent", "physical_agent", "rl_agent", "no_concrete_agent"):
            rs = [r for i in range(C.n) if U.year[i] == y and C.agent(i) == ak for r in refs[i] if r.get("year")]
            row[ak] = _pct(sum(1 for r in rs if r["year"] <= CLASSIC_YEAR), len(rs))
        age.append(row)
    R = {k: v for k, v in (readings or {}).items() if k in U.pos}  # a work removed from the corpus after it was read does not count
    stats = {"families": fams, "referenceAge": age, "defences": len(D)}
    if R:
        cls = Counter(r.get("link_class") for r in R.values())
        # the sample is stratified (the same number per mechanism); the weighted share counts each mechanism by the size of
        # its "no visible link" group, so it estimates the share among all such defences
        byfam = defaultdict(Counter)
        for r in R.values():
            byfam[r.get("family")][r.get("link_class")] += 1
        size = {f["key"]: f["withRefs"] * (f["none"] or 0) / 100 for f in fams}
        tot = sum(size.get(k, 0) for k in byfam) or 1
        weighted = {c: _r(100 * sum(size.get(k, 0) * byfam[k][c] / sum(byfam[k].values()) for k in byfam) / tot, 1) for c in cls}
        stats["readings"] = {"read": len(R), "classes": dict(cls), "share": {k: _pct(v, len(R)) for k, v in cls.items()}, "weighted": weighted,
                             "noLinkDefences": round(tot), "byFamily": {k: {**dict(v), "n": sum(v.values())} for k, v in byfam.items()}}
    ev = []
    for key in ("ifc", "least_privilege", "barrier"):
        for i in member[key]["direct"][:1]:
            ev.append(C.ref(i, None, family=key, link="direct"))
    ctr = [C.ref(U.pos[pid], r.get("evidence"), link=r.get("link_class"), family=r.get("family")) for pid, r in R.items() if r.get("link_class") == "correspondence_without_link" and pid in U.pos][:6]
    if rec is not None:
        rows = []
        crxs = {key: re.compile(classic_rx, re.I) for key, label, mech, stage, agent_rx, classic_rx in FAMILIES}
        for key, grp in member.items():
            for link, ws in grp.items():
                for i in ws:
                    rd = R.get(U.ids[i]) or {}
                    src = [r.get("title") for r in classic_refs(refs[i], crxs[key])][:2] if link == "direct" else []
                    rows.append([U.ids[i], _d(U, i), [key, link, C.agent(i), " | ".join(t or "" for t in src), rd.get("link_class") if rd.get("family") == key else None],
                                 rd.get("evidence") if rd.get("family") == key else None, []])
        rec["P3a"] = _rec(["defence corresponding to an established mechanism", "对应既有安全机制的防御"],
                          ["Fixed checklist of twelve mechanisms; classic sources by title pattern up to %d; readings on a sample of the no-link group" % CLASSIC_YEAR,
                           "事先固定的 12 类机制清单；经典来源按标题模式认定（%d 年及以前）；对“看不到联系”一组抽样细读" % CLASSIC_YEAR],
                          [["mechanism", "Mechanism", "机制", "text"], ["link", "Citation link", "引用联系", "text"], ["agent", "Agent kind", "agent 类型", "text"],
                           ["classic", "Classic sources cited", "引用的经典来源", "text"], ["reading", "Reading of the link", "细读结论", "text"]], rows)
    return _card(len(D), "defence works", None, None, None, stats, evidence=ev, counter=ctr), member


def rq3_routes(C, routes, cites_items, cites_labels, groups=None, unit="editorial clusters", rec=None, key=None):
    """3b: how knowledge reaches one direction (editorial cluster) from another: a term first used in A appears in B; a
    requirement x mechanism pair first studied in A is studied in B; B adopts a method of A; B uses a resource of A
    (benchmark use, or a citation that uses an artifact); an author of A publishes in B. For each ordered pair of clusters,
    the first date of each route; then how common each route is, which combinations occur, and which comes first."""
    U = C.U
    tops = groups or [set(t) for t in U.ptopics]
    K = len({g for t in tops for g in t})
    first = defaultdict(dict)  # (a, b) -> route -> date

    def note(a, b, route, d):
        if a == b or d is None:
            return
        cur = first[(a, b)].get(route)
        if cur is None or d < cur:
            first[(a, b)][route] = d
    # citations with an intent (engaged reading where it exists)
    vol = Counter()
    for cid, it in cites_items.items():
        lab = cites_labels.get(cid)
        i, j = U.pos.get(it["citing"]), U.pos.get(it["cited"])
        if lab is None or i is None or j is None or not U.date[i]:
            continue
        intents = {lab.get("intent")} | set(lab.get("also") or [])
        kind = "method" if "adopts_method" in intents else "resource" if "uses_artifact" in intents else "comparison" if "compares" in intents else "background"
        for a in tops[j] - tops[i]:
            for b in tops[i] - tops[j]:
                note(a, b, kind, U.date[i])
                vol[kind] += 1
    for (i, j), r in routes.items():
        if r["kind"] != "use" or not U.date[i]:
            continue
        for a in tops[j] - tops[i]:
            for b in tops[i] - tops[j]:
                note(a, b, "resource", U.date[i])
                vol["resourceUse"] += 1
    # people: an author whose earlier work sits in A publishes in B
    seen = defaultdict(list)  # author -> [(date, topics)]
    for i in sorted((i for i in range(C.n) if U.date[i]), key=lambda i: U.date[i]):
        for au in C.authors[i]:
            for d0, t0 in seen[au]:
                if d0 < U.date[i]:
                    for a in t0 - tops[i]:
                        for b in tops[i] - t0:
                            note(a, b, "people", U.date[i])
            seen[au].append((U.date[i], tops[i]))
    # problems: a requirement x mechanism pair first studied in A
    pfirst = {}
    for i in sorted((i for i in range(C.n) if U.date[i]), key=lambda i: U.date[i]):
        for p in {c[:2] for c in C.cells(i)}:
            if p not in pfirst:
                pfirst[p] = (U.date[i], tops[i])
            else:
                d0, t0 = pfirst[p]
                if U.date[i] > d0:
                    for a in t0 - tops[i]:
                        for b in tops[i] - t0:
                            note(a, b, "problem", U.date[i])
    # terms: a title term first used in A (and used in at least 8 titles overall)
    tfirst, tcount = {}, Counter()
    for i in sorted((i for i in range(C.n) if U.date[i]), key=lambda i: U.date[i]):
        for t in title_terms_of(U.title[i]):
            tcount[t] += 1
            if t not in tfirst:
                tfirst[t] = (U.date[i], tops[i])
    for i in sorted((i for i in range(C.n) if U.date[i]), key=lambda i: U.date[i]):
        for t in title_terms_of(U.title[i]):
            if tcount[t] < 8:
                continue
            d0, t0 = tfirst[t]
            if U.date[i] > d0:
                for a in t0 - tops[i]:
                    for b in tops[i] - t0:
                        note(a, b, "term", U.date[i])
    R = ["term", "problem", "people", "background", "method", "resource", "comparison"]
    pairs = [p for p in first if first[p]]
    if rec is not None and key:
        order = ["term", "problem", "people", "background", "method", "resource", "comparison"]
        rec[key] = _rec(["ordered pair of %s joined by a route" % unit, "有途径相连的有序方向对"], ["First date of each route from one direction to the other", "从一个方向到另一个方向，每种途径最早出现的日期"],
                        [[r, r, {"term": "术语", "problem": "问题", "people": "人员", "background": "背景引用", "method": "方法采用", "resource": "资源使用", "comparison": "对照比较"}[r], "text"] for r in order]
                        + [["first", "First route", "最先出现的途径", "text"]],
                        [[f"{a}>{b}", min(first[(a, b)].values()).isoformat(), [first[(a, b)][r].isoformat() if r in first[(a, b)] else None for r in order]
                          + [min(first[(a, b)], key=lambda r: first[(a, b)][r])], None, []] for (a, b) in sorted(pairs, key=lambda x: str(x))])
    prev = {r: _pct(sum(1 for p in pairs if r in first[p]), len(pairs)) for r in R}
    combos = Counter(tuple(r for r in R if r in first[p]) for p in pairs).most_common(8)
    prec = {}
    for x in R:
        for y in R:
            if x >= y:
                continue
            both = [p for p in pairs if x in first[p] and y in first[p]]
            if len(both) >= 20:
                xf = sum(1 for p in both if first[p][x] < first[p][y])
                yf = sum(1 for p in both if first[p][y] < first[p][x])
                prec[x + ">" + y] = {"pairs": len(both), "xFirst": _pct(xf, len(both)), "yFirst": _pct(yf, len(both))}
    order = Counter()
    for p in pairs:
        if first[p]:
            order[min(first[p], key=lambda r: first[p][r])] += 1
    eng = {k: vol[k] for k in ("method", "resource", "comparison", "background", "resourceUse")}
    return _card(len(pairs), "ordered pairs of the %d %s joined by at least one route" % (K, unit), K * (K - 1) - len(pairs), K * (K - 1), "pairs with no route",
                 {"prevalence": prev, "combos": [[list(c), v] for c, v in combos], "precedence": prec, "firstRoute": {r: _pct(order[r], len(pairs)) for r in R},
                  "volumes": eng, "engagedShare": {k: _pct(eng[k], eng["method"] + eng["resource"] + eng["comparison"]) for k in ("method", "resource", "comparison")}})


def title_terms_of(title):
    words = [w for w in re.findall(r"[a-z][a-z0-9\-]+", (title or "").lower()) if w not in TERM_STOP and len(w) > 2]
    return {words[k] + " " + words[k + 1] for k in range(len(words) - 1)}


TERM_STOP = set("""a an the and or of for in on to with via by from as at into under over towards toward through against beyond
using use based towards large language model models llm llms agent agents agentic ai learning safe safety secure security
evaluating evaluation benchmark benchmarking framework approach study analysis new novel can are is be its their our we
your you how what when why do does not more less than toward multi""".split())


def thread_groups(C):
    g = [set() for _ in range(C.n)]
    for th in C.U.threads:
        for m in th["members"]:
            i = C.U.sm_map[m]
            if i is not None:
                g[i].add(th["id"])
    return g


def rq3_new_directions(C, routes, cites_items, cites_labels, min_size=25, start="2024-07-01", rec=None):
    """3b (second part): when a candidate cluster forms (its fifth work on or after `start`, at least `min_size` works), what its
    first 12 months draw on: benchmarks released outside it before it began, methods adopted from works outside it, and
    authors with earlier Atlas works outside it"""
    U = C.U
    t0 = dt.date.fromisoformat(start)
    rows = []
    for th in U.threads:
        mem = [U.sm_map[m] for m in th["members"] if U.sm_map[m] is not None]
        mem = [i for i in mem if U.date[i]]
        if len(mem) < min_size:
            continue
        begin = sorted(U.date[i] for i in mem)[4]  # formed when its fifth work appeared (a first stray work is not the start)
        if begin < t0:
            continue
        S = set(mem)
        early = [i for i in mem if months_between(begin, U.date[i]) <= 12]
        uses = [(i, j) for (i, j), r in routes.items() if r["kind"] == "use" and i in early]
        out_old = [1 for i, j in uses if j not in S and U.date[j] and U.date[j] < begin]
        meth = []
        for cid, it in cites_items.items():
            lab = cites_labels.get(cid)
            i, j = U.pos.get(it["citing"]), U.pos.get(it["cited"])
            if lab and i in early and j is not None and "adopts_method" in ({lab.get("intent")} | set(lab.get("also") or [])):
                meth.append(j not in S)
        prev_auth = set()
        for k in range(C.n):
            if U.date[k] and U.date[k] < begin and k not in S:
                prev_auth |= C.authors[k]
        with_prior = sum(1 for i in early if C.authors[i] & prev_auth)
        rows.append({"id": th["id"], "label": th.get("label"), "topic": th.get("topic"), "begin": begin.isoformat(), "works": len(mem), "early": len(early),
                     "uses": len(uses), "usesOldOutside": _pct(len(out_old), len(uses)), "methods": len(meth), "methodsOutside": _pct(sum(meth), len(meth)),
                     "priorAuthors": _pct(with_prior, len(early))})
    rows.sort(key=lambda r: r["begin"])
    if rec is not None:
        rec["P3bNew"] = _rec(["algorithmic cluster formed since %s" % start, "%s 以后成形的算法簇" % start], ["First twelve months after the fifth work", "第五篇工作出现后的 12 个月"],
                             [["label", "Keywords", "关键词", "text"], ["line", "Curated line", "研究线", "text"], ["works", "Works", "工作数", "num"], ["uses", "Benchmark uses", "基准使用", "num"],
                              ["usesOld", "Uses of older outside benchmarks (%)", "使用外部更早基准（%）", "num"], ["methods", "Method adoptions", "方法采用", "num"],
                              ["methodsOut", "From outside (%)", "来自外部（%）", "num"], ["prior", "Works with an author from elsewhere (%)", "作者来自其他方向（%）", "num"]],
                             [[r["id"], r["begin"], [", ".join(r.get("label") or []), r.get("topic"), r["works"], r["uses"], r["usesOldOutside"], r["methods"], r["methodsOutside"], r["priorAuthors"]], None, []] for r in rows])
    pool = lambda k, n: _pct(sum((r[k] or 0) * r[n] / 100 for r in rows if r[n]), sum(r[n] for r in rows))
    return _card(len(rows), "candidate clusters that began on or after %s with %d or more works" % (start, min_size), None, None, None,
                 {"rows": rows, "pooled": {"usesOldOutside": pool("usesOldOutside", "uses"), "methodsOutside": pool("methodsOutside", "methods"), "priorAuthors": pool("priorAuthors", "early")}})


def rq3_digital_physical(C, cites_items, cites_labels, rec=None):
    """3c: one field or two? Citations between digital and physical agent works against what group sizes predict, the
    intents of the citations that cross, shared authors, and the overlap of the problems studied"""
    U = C.U
    G = {"digital_agent": "D", "physical_agent": "P"}
    g = [G.get(C.agent(i)) for i in range(C.n)]
    cnt = Counter()
    by_year = defaultdict(Counter)
    for i, j in U.links:
        if g[i] and g[j]:
            cnt[g[i] + g[j]] += 1
            if U.year[i]:
                by_year[U.year[i]][g[i] + g[j]] += 1
    out_d, out_p = cnt["DD"] + cnt["DP"], cnt["PD"] + cnt["PP"]
    in_d, in_p = cnt["DD"] + cnt["PD"], cnt["DP"] + cnt["PP"]
    tot = out_d + out_p
    exp = {"DP": out_d * in_p / tot, "PD": out_p * in_d / tot}
    cross_int = Counter()
    for cid, it in cites_items.items():
        lab = cites_labels.get(cid)
        i, j = U.pos.get(it["citing"]), U.pos.get(it["cited"])
        if lab and i is not None and j is not None and g[i] and g[j] and g[i] != g[j]:
            cross_int[(g[i] + g[j], lab.get("intent"))] += 1
    if rec is not None:
        rows = []
        for i, j in U.links:
            if g[i] and g[j] and g[i] != g[j]:
                cid = f"{U.ids[i]}>{U.ids[j]}"
                lab, it = cites_labels.get(cid) or {}, cites_items.get(cid) or {}
                rows.append([U.ids[i], _d(U, i), [U.ids[j], "digital > physical" if g[i] == "D" else "physical > digital", lab.get("intent")],
                             (lab.get("evidence") or ((it.get("contexts") or [None])[0])), []])
        rec["P3c"] = _rec(["citation between digital- and physical-agent works", "数字与物理 agent 工作之间的一次引用"], ["Semantic Scholar reference lists; intent where a citing sentence was read", "Semantic Scholar 参考文献；读到引用句时附用途"],
                          [["cited", "Cited work", "被引工作", "paper"], ["direction", "Direction", "方向", "text"], ["intent", "Intent", "用途", "text"]], rows)
    auth = defaultdict(set)
    for i in range(C.n):
        if g[i]:
            for a in C.authors[i]:
                auth[a].add(g[i])
    both = {a for a, s in auth.items() if len(s) == 2}
    wd = [i for i in range(C.n) if g[i] == "D"]
    wp = [i for i in range(C.n) if g[i] == "P"]
    sd = Counter(C.safety(i) for i in wd)
    sp = Counter(C.safety(i) for i in wp)
    js = jensen_shannon([sd[k] for k in SAFETY], [sp[k] for k in SAFETY])
    pairs_d = {c[:2] for i in wd for c in C.cells(i)}
    pairs_p = {c[:2] for i in wp for c in C.cells(i)}
    years = [{"year": y, "DP": _pct(c["DP"], c["DD"] + c["DP"]), "PD": _pct(c["PD"], c["PD"] + c["PP"]), "n": sum(c.values()), "partial": y == C.last} for y, c in sorted(by_year.items()) if y >= 2021]
    return _card(sum(cnt.values()), "citations between works on digital or physical agents", None, None, None,
                 {"counts": dict(cnt), "observedOverExpected": {k: _r(cnt[k] / exp[k], 3) for k in exp}, "expected": {k: round(v) for k, v in exp.items()},
                  "crossIntents": [[k[0], k[1], v] for k, v in cross_int.most_common()], "bridgingAuthors": len(both),
                  "authors": {"D": sum(1 for s in auth.values() if "D" in s), "P": sum(1 for s in auth.values() if "P" in s)},
                  "worksByBridging": {"D": _pct(sum(1 for i in wd if C.authors[i] & both), len(wd)), "P": _pct(sum(1 for i in wp if C.authors[i] & both), len(wp))},
                  "safetyJS": _r(js, 3), "safety": {"D": {k: _pct(sd[k], len(wd)) for k in SAFETY}, "P": {k: _pct(sp[k], len(wp)) for k in SAFETY}},
                  "pairs": {"D": len(pairs_d), "P": len(pairs_p), "both": len(pairs_d & pairs_p)}, "years": years})


def jensen_shannon(a, b):
    sa, sb = sum(a) or 1, sum(b) or 1
    p = [x / sa for x in a]
    q = [x / sb for x in b]
    m = [(x + y) / 2 for x, y in zip(p, q)]
    kl = lambda u, v: sum(x * math.log2(x / y) for x, y in zip(u, v) if x > 0 and y > 0)
    return (kl(p, m) + kl(q, m)) / 2


# ======================================================================================================== RQ4 沉淀
def half_index(d):
    return d.year * 2 + (0 if d.month <= 6 else 1)


def rq4_durable(C, routes, cites_items, cites_labels, min_size=40, rec=None):
    """4a: after attention moves on, what stays in use. A candidate cluster's attention has moved on when its share of the
    half-year's works fell to at most 60% of its peak share and the peak was two or more complete half-years before the last
    complete one. Its works up to the peak are the contributions; after the peak each is read for use of four kinds:
    problem (cited as background), method (adopted), resource (benchmark use or artifact use), any citation; and whether the
    later use comes from other clusters. Baseline: works of the same half-year from clusters whose share did not fall."""
    U = C.U
    last_full = half_index(C.asof) - 1  # the running half-year is left out
    tot = Counter(half_index(U.date[i]) for i in range(C.n) if U.date[i] and U.prec[i] != "year")
    member_of = defaultdict(set)
    info = []
    for th in U.threads:
        mem = [U.sm_map[m] for m in th["members"] if U.sm_map[m] is not None]
        mem = [i for i in mem if U.date[i] and U.prec[i] != "year"]
        if len(mem) < min_size:
            continue
        h = Counter(half_index(U.date[i]) for i in mem)
        shares = {k: h[k] / tot[k] for k in h if k <= last_full and tot[k] >= 50}
        if not shares:
            continue
        peak = max(shares, key=lambda k: shares[k])
        now = shares.get(last_full, 0)
        declined = peak <= last_full - 2 and now <= 0.6 * shares[peak]
        info.append({"id": th["id"], "label": th.get("label"), "works": len(mem), "peak": "%dH%d" % (peak // 2, peak % 2 + 1), "peakShare": _r(100 * shares[peak], 2),
                     "nowShare": _r(100 * now, 2), "declined": declined, "_peak": peak, "_mem": mem})
        for i in mem:
            member_of[i].add(th["id"])
    use = defaultdict(lambda: defaultdict(list))  # cited work -> kind -> [(date, citing)]
    for cid, it in cites_items.items():
        lab = cites_labels.get(cid)
        i, j = U.pos.get(it["citing"]), U.pos.get(it["cited"])
        if lab is None or i is None or j is None or not U.date[i]:
            continue
        intents = {lab.get("intent")} | set(lab.get("also") or [])
        if "adopts_method" in intents:
            use[j]["method"].append((U.date[i], i))
        if "uses_artifact" in intents:
            use[j]["resource"].append((U.date[i], i))
        if "background" in intents:
            use[j]["problem"].append((U.date[i], i))
    for (i, j), r in routes.items():
        if r["kind"] == "use" and U.date[i]:
            use[j]["resource"].append((U.date[i], i))
    for j in range(C.n):
        for i in U.cited_by[j]:
            if U.date[i]:
                use[j]["cited"].append((U.date[i], i))

    def after(j, kind, since, other=None):
        xs = [(d, i) for d, i in use[j][kind] if half_index(d) > since and not (C.authors[i] & C.authors[j])]
        if other is not None:
            xs = [(d, i) for d, i in xs if not (member_of.get(i, set()) & other)]
        return xs
    kinds = ["cited", "problem", "method", "resource"]
    dec = [t for t in info if t["declined"]]
    rest = [t for t in info if not t["declined"]]
    ws = [(i, t["_peak"], {t["id"]}) for t in dec for i in t["_mem"] if half_index(U.date[i]) <= t["_peak"]]
    if rec is not None:
        yn = lambda v: "yes" if v else "no"
        rec["P4a"] = _rec(["work of an algorithmic cluster whose share fell, up to its peak", "份额下降的算法簇在高峰前的工作"], ["Uses after the peak by teams sharing no author", "高峰之后、没有共同作者的团队的使用"],
                          [["cluster", "Cluster", "簇", "text"], ["peak", "Peak half-year", "高峰半年", "text"], ["cited", "Cited", "被引用", "text"], ["problem", "Cited as background", "作为背景被引", "text"],
                           ["method", "Method adopted", "方法被采用", "text"], ["resource", "Resource used", "资源被使用", "text"], ["outside", "Cited from other clusters", "被其他簇引用", "text"]],
                          [[U.ids[i], _d(U, i), [next(iter(own)), "%dH%d" % (pk // 2, pk % 2 + 1), yn(after(i, "cited", pk)), yn(after(i, "problem", pk)), yn(after(i, "method", pk)),
                                                 yn(after(i, "resource", pk)), yn(after(i, "cited", pk, own))], None, []] for i, pk, own in ws])
    res = {"declined": {"works": len(ws), **{k: _pct(sum(1 for i, pk, own in ws if after(i, k, pk)), len(ws)) for k in kinds},
                        **{k + "Outside": _pct(sum(1 for i, pk, own in ws if after(i, k, pk, own)), len(ws)) for k in kinds}}}
    # baseline matched on age: for each declined cluster, as many works of the same half-years from clusters that did not
    # decline, read after the same point
    mws = []
    for t in dec:
        hs = Counter(half_index(U.date[i]) for i in t["_mem"] if half_index(U.date[i]) <= t["_peak"])
        pool = [i for r in rest for i in r["_mem"] if half_index(U.date[i]) in hs]
        rnd = random.Random(SEED + len(mws))
        mws += [(i, t["_peak"]) for i in rnd.sample(pool, min(len(pool), sum(hs.values())))]
    matched = {"works": len(mws), **{k: _pct(sum(1 for i, pk in mws if after(i, k, pk)), len(mws)) for k in kinds}}
    res["matched"] = matched
    for t in info:
        t.pop("_mem"); t.pop("_peak")
    return _card(len(info), "candidate clusters with %d or more dated works" % min_size, None, None, None,
                 {"clusters": sorted(info, key=lambda t: (not t["declined"], -t["works"]))[:60], "declined": len(dec), "groups": res})


def rq4_benchmarks(C, routes, names, cites_items, cites_labels, rec=None):
    """4b: the life of an evaluation resource. Four levels per named benchmark: released, cited (citation graph), mentioned
    in a full text (name present, no use sentence), used in experiments (use sentence). Time to first outside use (no shared
    author) by release cohort; use in fixed windows after release (0-6, 6-12, 12-18 months) for benchmarks released 18 or
    more months before the cut-off; who uses it (own team or outside); and the paths: never used (no outside use by the cut-off),
    short (outside use in the first year, none in months 12-18; later uses are not read), sustained (outside use in months 12-18
    and in the first year), late (outside use only after the first year)"""
    U = C.U
    bench = sorted(set(names.values()))
    uses = defaultdict(list)
    ments = defaultdict(list)
    for (i, j), r in routes.items():
        if U.date[i]:
            (uses if r["kind"] == "use" else ments)[j].append(i)
    rows = []
    km = defaultdict(list)
    for j in bench:
        if not U.date[j] or U.prec[j] == "year":
            continue
        d0 = U.date[j]
        age = months_between(d0, C.asof)
        own = [i for i in uses[j] if C.authors[i] & C.authors[j]]
        out = [i for i in uses[j] if not (C.authors[i] & C.authors[j])]
        cites = len(U.cited_by[j])
        t_out = min((months_between(d0, U.date[i]) for i in out), default=None)
        km[min(max(d0.year, 2023), C.last)].append((max(0.0, t_out) if t_out is not None else age, t_out is not None))
        win = [sum(1 for i in out if a <= months_between(d0, U.date[i]) < b) for a, b in ((0, 6), (6, 12), (12, 18))]
        path = None
        if age >= 18:
            if not out:
                path = "never"
            elif win[2] > 0 and sum(1 for w in win if w) >= 2:
                path = "sustained"
            elif win[2] == 0 and sum(win[:2]) > 0:
                path = "short"
            else:
                path = "late"
        rows.append({"j": j, "name": next((n for n, x in names.items() if x == j), None), "date": d0.isoformat(), "age": round(age, 1), "cited": cites,
                     "mentioned": len(ments[j]), "usedOwn": len(own), "usedOutside": len(out), "windows": win, "path": path})
    mature = [r for r in rows if r["path"]]
    paths = Counter(r["path"] for r in mature)
    if rec is not None:
        rec["P4b"] = _rec(["named benchmark dated to the day", "日期精确到日的有名称基准"], ["Citations (graph), mentions and uses (full-text sentences); outside = no shared author", "引用（引用图）、提及与使用（全文句子）；外部 = 没有共同作者"],
                          [["name", "Name", "名称", "text"], ["cited", "Cited by Atlas works", "被图谱工作引用", "num"], ["mentioned", "Mentioned", "被提及", "num"], ["own", "Uses by the proposing team", "原团队使用", "num"],
                           ["outside", "Uses by outside teams", "外部团队使用", "num"], ["windows", "Outside uses in 0-6 / 6-12 / 12-18 months", "0-6/6-12/12-18 个月的外部使用", "text"], ["path", "Path", "路径", "text"]],
                          [[U.ids[r["j"]], r["date"], [r["name"], r["cited"], r["mentioned"], r["usedOwn"], r["usedOutside"], "/".join(map(str, r["windows"])), r["path"]], None, []] for r in rows])
    curves = {str(y): {"n": len(v), "median": kaplan_meier(v)[1], "at6": next((s for t, s in reversed(kaplan_meier(v)[0]) if t <= 6), 1.0),
                       "at12": next((s for t, s in reversed(kaplan_meier(v)[0]) if t <= 12), 1.0)} for y, v in sorted(km.items())}
    levels = {"released": len(rows), "cited": sum(1 for r in rows if r["cited"]), "mentioned": sum(1 for r in rows if r["mentioned"] or r["usedOwn"] or r["usedOutside"]),
              "usedAny": sum(1 for r in rows if r["usedOwn"] or r["usedOutside"]), "usedOutside": sum(1 for r in rows if r["usedOutside"])}
    allu = sum(r["usedOwn"] + r["usedOutside"] for r in rows)
    # high citation, low use against sustained use
    hi = sorted([r for r in mature if r["cited"] >= 30], key=lambda r: (r["usedOutside"] / max(1, r["cited"]), -r["cited"]))[:6]
    sus = sorted([r for r in mature if r["path"] == "sustained"], key=lambda r: -r["usedOutside"])[:6]
    case = lambda r: C.ref(r["j"], None, name=r["name"], cited=r["cited"], usedOutside=r["usedOutside"], windows=r["windows"], path=r["path"])
    return _card(len(rows), "named benchmark works with a day-precise date", len(bench) - len(rows), len(bench), "benchmarks dated by year only",
                 {"levels": levels, "paths": {k: _pct(v, len(mature)) for k, v in paths.items()}, "pathsN": dict(paths), "mature": len(mature),
                  "firstOutsideUse": curves, "ownShareOfUses": _pct(sum(r["usedOwn"] for r in rows), allu), "uses": allu,
                  "concentration": _pct(sum(sorted([r["usedOutside"] for r in rows], reverse=True)[:10]), sum(r["usedOutside"] for r in rows))},
                 evidence=[case(r) for r in sus[:3]], support=[case(r) for r in sus[3:]], counter=[case(r) for r in hi])


NEWER_MODELS = [("gpt-4o", "2024-05-13"), ("claude-3.5", "2024-06-20"), ("claude 3.5", "2024-06-20"), ("llama-3.1", "2024-07-23"), ("llama 3.1", "2024-07-23"),
                ("o1", "2024-09-12"), ("qwen2.5", "2024-09-19"), ("deepseek-v3", "2024-12-26"), ("deepseek-r1", "2025-01-20"), ("o3", "2025-04-16"),
                ("gemini-2.5", "2025-03-25"), ("gemini 2.5", "2025-03-25"), ("gpt-4.1", "2025-04-14"), ("qwen3", "2025-04-29"), ("claude-4", "2025-05-22"),
                ("claude 4", "2025-05-22"), ("claude-sonnet-4", "2025-05-22"), ("gpt-5", "2025-08-07"), ("gpt-oss", "2025-08-05"), ("claude-sonnet-4.5", "2025-09-29"),
                ("gemini-3", "2025-11-18"), ("gemini 3", "2025-11-18"), ("claude-opus-4.5", "2025-11-24")]


def rq4_tools(C, oss, meta, upkeep=None, rec=None):
    """4c: which results remain usable tools. Paper implementations (repositories linked to an Atlas work) against
    independent tools (agent-security repositories of type tool with no linked paper). Read from the repository record:
    still pushed 12 months after creation (repositories created 12 or more months before the snapshot), more than one
    contributor, issues open, archived; adapted to newer models: the README head names a model released after the
    repository was created. Running the code is not tested: these are conditions for use, not proof of it."""
    snap = dt.date.fromisoformat(oss["meta"]["latestSnapshot"])
    K = {}
    for line in open(upkeep, encoding="utf-8") if upkeep and os.path.exists(upkeep) else []:
        r = json.loads(line)
        if r.get("status") == "ok":
            K[r["repo"].lower()] = r
    M = {}
    for line in open(meta, encoding="utf-8") if meta and os.path.exists(meta) else []:
        r = json.loads(line)
        if r.get("status") == "ok":
            M[(r.get("full_name") or r["key"]).lower()] = r
    groups = {"paper": [], "tool": []}
    for r in oss["repos"]:
        if r.get("group") != "agent_security" or r.get("fork"):
            continue
        if r.get("papers"):
            groups["paper"].append(r)
        elif r.get("type") == "tool":
            groups["tool"].append(r)
    out = {}
    recrows = []
    for g, rs in groups.items():
        rows = []
        for r in rs:
            m = M.get(r["repo"].lower()) or {}
            c = (r.get("createdAt") or "")[:10]
            p = (r.get("pushedAt") or "")[:10]
            if not c:
                continue
            cd, pd = dt.date.fromisoformat(c), dt.date.fromisoformat(p) if p else None
            age = months_between(cd, snap)
            readme = (m.get("readme_head") or "").lower()
            newer = any(name in readme and dt.date.fromisoformat(rel) > cd for name, rel in NEWER_MODELS)
            k = K.get(r["repo"].lower()) or {}
            recrows.append([r["repo"], c, [g, round(age, 1), (k.get("commits12") if k and age >= 12 else None), k.get("closedIssues") if k else None, k.get("mergedPRs") if k else None,
                                           k.get("releases") if k else None, p or None], None, []])
            rows.append({"age": age, "active12": (pd is not None and months_between(cd, pd) >= 12) if age >= 12 else None,
                         "commits12": (k.get("commits12") or 0) > 0 if k and age >= 12 else None, "commits12n": k.get("commits12") if age >= 12 else None,
                         "closed": (k.get("closedIssues") or 0) > 0 if k else None, "merged": (k.get("mergedPRs") or 0) > 0 if k else None,
                         "releases": (k.get("releases") or 0) > 0 if k else None, "commits": k.get("commits"),
                         "recent": pd is not None and months_between(pd, snap) <= 6, "contributors": m.get("contributors"),
                         "issues": m.get("open_issues"), "archived": bool(r.get("archived")), "newer": newer if age >= 6 else None,
                         "stars": r.get("stars") or 0, "release": bool(r.get("latestRelease"))})
        old = [x for x in rows if x["active12"] is not None]
        six = [x for x in rows if x["newer"] is not None]
        withc = [x for x in rows if x["contributors"] is not None]
        c12 = [x for x in rows if x["commits12"] is not None]
        kn = [x for x in rows if x["closed"] is not None]
        out[g] = {"repos": len(rows), "old12": len(old), "active12": _pct(sum(1 for x in old if x["active12"]), len(old)),
                  "commitsAfter12": _pct(sum(1 for x in c12 if x["commits12"]), len(c12)), "commitsAfter12Base": len(c12),
                  "medianCommitsAfter12": sorted(x["commits12n"] or 0 for x in c12)[len(c12) // 2] if c12 else None,
                  "closedIssues": _pct(sum(1 for x in kn if x["closed"]), len(kn)), "mergedPRs": _pct(sum(1 for x in kn if x["merged"]), len(kn)),
                  "releases": _pct(sum(1 for x in kn if x["releases"]), len(kn)), "upkeepKnown": len(kn),
                  "pushedLast6": _pct(sum(1 for x in rows if x["recent"]), len(rows)), "multiContrib": _pct(sum(1 for x in withc if x["contributors"] >= 2), len(withc)),
                  "contribKnown": len(withc), "archived": _pct(sum(1 for x in rows if x["archived"]), len(rows)),
                  "newerModels": _pct(sum(1 for x in six if x["newer"]), len(six)), "release": _pct(sum(1 for x in rows if x["release"]), len(rows)),
                  "medianStars": sorted(x["stars"] for x in rows)[len(rows) // 2] if rows else None,
                  "byAge": {k: _pct(sum(1 for x in rows if x["age"] >= a and x["recent"]), sum(1 for x in rows if x["age"] >= a)) for k, a in (("12m", 12), ("24m", 24))}}
    if rec is not None:
        rec["P4c"] = _rec(["agent-security repository", "agent 安全仓库"], ["Open-source landscape records and the GitHub API (upkeep_v1)", "开源版图记录与 GitHub API（upkeep_v1）"],
                          [["group", "Paper implementation or independent tool", "论文实现或独立工具", "text"], ["age", "Months since creation", "创建后月数", "num"],
                           ["commits12", "Commits after the first year", "第一年后的提交", "num"], ["closed", "Closed issues", "关闭的 issue", "num"], ["merged", "Merged pull requests", "合并的 PR", "num"],
                           ["releases", "Releases", "发布版本", "num"], ["pushed", "Last push", "最近推送", "text"]], recrows)
    return _card(sum(v["repos"] for v in out.values()), "agent-security repositories: paper implementations and independent tools", None, None, None,
                 {"groups": out, "snapshot": snap.isoformat()})


def rq4_revision(prev):
    """4d: whether claims are revised after open problems and outside counter-evidence; the joint analysis J6, the revision
    check and the open-problem responses of the same analysis version, gathered under this question"""
    cards = ((prev or {}).get("evidence") or {}).get("cards") or {}
    jr = cards.get("jrespond") or {}
    st = jr.get("stats") or {}
    op = ((prev or {}).get("tail") or {}).get("open") or {}
    return _card(jr.get("base"), jr.get("baseLabel"), jr.get("missing"), jr.get("missingOf"), jr.get("missingWhy"),
                 {"counter": st.get("counter"), "baseline": st.get("baseline"), "matched": st.get("matched"), "revision": st.get("revision"),
                  "open": {k: v for k, v in (op.get("stats") or {}).items() if k in ("recurring", "byAnswer", "byStatus", "responseForms", "responsesCoded", "worksRead", "problems", "grouping")}
                  if isinstance(op, dict) else None},
                 evidence=jr.get("evidence") or [], support=jr.get("support") or [], counter=jr.get("counter") or [])


# ======================================================================================================== the section
def paper_section(U, routes, names, facets, axes, protocol, chains, cites_items, cites_labels, works, oss, oss_meta, prev,
                  novelty=None, bounds=None, inherit=None, upkeep=None):
    C = Ctx(U, facets, axes)
    rec = {}
    out = {"meta": {"question": "growth -> accumulation", "units": "requirement x mechanism x scenario", "firstYear": FIRST_YEAR, "partialYear": C.last,
                    "classicYear": CLASSIC_YEAR, "seed": SEED}}
    rq1 = {"growth": rq1_growth(C), "names": rq1_novel_names(C, novelty, rec), "pioneers": rq1_pioneers(C, oss, rec), "early": rq1_early(prev)}
    ladder_card, L = rq2_ladder(C, protocol, cites_items, cites_labels, bounds, rec)
    rq2 = {"sources": rq2_sources(C, protocol, chains, rec), "defence": rq2_defence(C, rec), "ladder": ladder_card, "outside": rq2_outside(C, cites_items, cites_labels),
           "cases": rq2_cases(C, protocol, L, routes, names, rec)}
    inh, _ = rq3_inherit(C, works, inherit, rec)
    rq3 = {"inherit": inh, "routes": rq3_routes(C, routes, cites_items, cites_labels),
           "routesThreads": rq3_routes(C, routes, cites_items, cites_labels, thread_groups(C), "candidate clusters", rec, "P3b"),
           "newDirections": rq3_new_directions(C, routes, cites_items, cites_labels, rec=rec),
           "digitalPhysical": rq3_digital_physical(C, cites_items, cites_labels, rec)}
    rq4 = {"durable": rq4_durable(C, routes, cites_items, cites_labels, rec=rec), "benchmarks": rq4_benchmarks(C, routes, names, cites_items, cites_labels, rec),
           "tools": rq4_tools(C, oss, oss_meta, upkeep, rec), "revision": rq4_revision(prev)}
    out.update({"rq1": rq1, "rq2": rq2, "rq3": rq3, "rq4": rq4, "web": web_subset(C, routes, names, L, cites_items, cites_labels, rec)})
    out["_records"] = rec  # item-level records (data/records/P*.json); build_findings moves them out of the report
    return out


# ======================================================================================================== reading corpora
# what the three readings of label_paper_readings.py are given (written once; the readings are merged back by id)
LIMIT_HEAD = re.compile(r"\n\s*(?:\d+(?:\.\d+)*\.?\s*)?(Limitations?|Discussion|Conclusions?|Failure (?:Cases|Modes|Analysis)|Broader Impacts?|Future Work|Threats to Validity)[^\n]{0,60}\n", re.I)
LIMIT_CUE = re.compile(r"\bfail|limitation|cannot|can not|vulnerab|bypass|evad|adaptive attack|assum|does not (hold|work|defend|protect|generali)|not robust|weakness|circumvent", re.I)


def boundary_passages(text, cap=8000):
    out, used = [], 0
    for m in LIMIT_HEAD.finditer(text):
        chunk = text[m.start(): m.start() + 2500]
        out.append(chunk)
        used += len(chunk)
        if used > cap * 0.7:
            break
    sents = re.split(r"(?<=[.!?])\s+", text)
    for s in sents:
        if used >= cap:
            break
        if LIMIT_CUE.search(s) and len(s) < 600 and not any(s[:80] in o for o in out):
            out.append(s)
            used += len(s)
    return " ".join(" ".join(out).split())[:cap]


def write_corpora(U, facets, axes, works, protocol_ids, fulltext_path, refs_head, folder, seed=SEED):
    import gzip
    C = Ctx(U, facets, axes)
    os.makedirs(folder, exist_ok=True)
    abstract = lambda i: (U.s2[i] or {}).get("abstract") or U.byid[U.ids[i]].get("summary") or ""
    sets = new_name_works(C)
    with open(os.path.join(folder, "novelty_corpus.jsonl"), "w", encoding="utf-8") as f:
        for i in sorted(set().union(*sets.values())):
            f.write(json.dumps({"id": U.ids[i], "title": U.title[i], "text": "Abstract: " + abstract(i), "names": [k for k, v in sets.items() if i in v]}, ensure_ascii=False) + "\n")
    n_b = 0
    with open(os.path.join(folder, "boundary_corpus.jsonl"), "w", encoding="utf-8") as f:
        for pid in protocol_ids:
            i = U.pos.get(pid)
            path = fulltext_path(U, i) if i is not None else None
            if not path:
                continue
            t = gzip.open(path, "rt", encoding="utf-8", errors="ignore").read()
            m = refs_head.search(t, len(t) // 3)
            body = t[:m.start()] if m else t
            p = boundary_passages(body)
            if p:
                f.write(json.dumps({"id": pid, "title": U.title[i], "text": "Passages: " + p}, ensure_ascii=False) + "\n")
                n_b += 1
    n_i = write_inherit_corpus(U, C, works, fulltext_path, folder, 4, seed)
    return {"novelty": sum(1 for _ in open(os.path.join(folder, "novelty_corpus.jsonl"))), "boundary": n_b, "inherit": n_i}


# ======================================================================================================== the Web subset
def web_subset(C, routes, names, ladder, cites_items, cites_labels, rec=None):
    """the same core analyses on the Web subset (digital agents studying browsers, tools and APIs, external web content, or
    memory and retrieval), next to the whole collection: how large it is, whether its growth opens new combinations, how fast
    its risks meet defences, how far its defences climb the ladder, and how its evaluation resources are found and reused"""
    U = C.U
    W = {i for i in range(C.n) if C.web(i)}
    obj = {k: {i for i in W if k in C.web_objects(i)} for k in WEB_OBJECTS}
    years = []
    for y in range(2021, C.last + 1):
        ys = [i for i in range(C.n) if U.year[i] == y]
        years.append({"year": y, "works": len(ys), "web": sum(1 for i in ys if i in W), "share": _pct(sum(1 for i in ys if i in W), len(ys)),
                      **{k: sum(1 for i in ys if i in obj[k]) for k in WEB_OBJECTS}, "partial": y == C.last})
    roles = Counter(C.role(i) for i in W)
    if rec is not None:
        rec["PWeb"] = _rec(["work in the Web subset", "Web 子集中的工作"], ["Digital agents studying browsers or computer use, tools and APIs, external web content, or memory and retrieval (labels, settings, title)",
                                                                          "研究浏览器/computer use、工具与 API、外部网页内容或记忆与检索的数字 agent 工作（标签、设定、标题）"],
                           [["objects", "Web objects", "Web 对象", "text"], ["role", "Role", "角色", "text"]],
                           [[U.ids[i], _d(U, i), [", ".join(sorted(C.web_objects(i))), C.role(i)], None, []] for i in sorted(W, key=lambda i: U.ids[i])])
    # 1a: Web works classified against every earlier work of the collection
    order = sorted((i for i in range(C.n) if U.year[i] and C.cells(i)), key=lambda i: (U.date[i], U.ids[i]))
    cell_n, pair_n, kind = Counter(), Counter(), {}
    by_year = defaultdict(list)
    for i in order:
        by_year[U.year[i]].append(i)
    for y in sorted(by_year):
        for i in by_year[y]:
            nc = {c for c in C.cells(i) if cell_n[c] < 1}
            kind[i] = "dense" if not nc else ("newMechanism" if any(pair_n[c[:2]] < 1 for c in nc) else "newScene")
        for i in by_year[y]:
            for c in C.cells(i):
                cell_n[c] += 1
                pair_n[c[:2]] += 1
    growth = []
    for y in range(2021, C.last + 1):
        ws = [i for i in W if U.year[i] == y and i in kind]
        cl = Counter(kind[i] for i in ws)
        growth.append({"year": y, "works": len(ws), **{k + "Share": _pct(cl[k], len(ws)) for k in ("dense", "newScene", "newMechanism")}, "partial": y == C.last})
    # 2b: response lag over requirement x mechanism pairs, Web works only
    T = [i for i in W if C.role(i) in THREAT_ROLES and U.year[i]]
    D = [i for i in W if C.role(i) == "defense" and U.year[i]]
    lag = response_lag(C, T, D)
    # 2c: the ladder on Web defences with a protocol card
    lw = [i for i in ladder if i in W]
    mat = [i for i in lw if ladder[i]["mature"]]
    prof = {k: _pct(sum(1 for i in (mat if k in ("L4", "L5") else lw) if ladder[i][k]), len(mat) if k in ("L4", "L5") else len(lw)) for k in ("L2", "L3", "L4", "L5")}
    alive, cum = list(mat), [_pct(len(mat), len(mat))]
    for k in ("L2", "L3", "L4", "L5"):
        alive = [i for i in alive if ladder[i][k]]
        cum.append(_pct(len(alive), len(mat)))
    adv = [i for i in lw if ladder[i]["adv"]]
    ladder_w = {"n": len(lw), "mature": len(mat), "profile": prof, "ladder": cum, "adaptive": _pct(sum(1 for i in adv if ladder[i]["L2"]), len(adv)),
                "realSystem": _pct(sum(1 for i in lw if (C.F.get(i) or {}).get("evaluation") == "real_system"), len(lw)),
                "byObject": {k: {"n": sum(1 for i in lw if i in obj[k]), "L2": _pct(sum(1 for i in lw if i in obj[k] and ladder[i]["L2"]), sum(1 for i in lw if i in obj[k])),
                                 "L3": _pct(sum(1 for i in lw if i in obj[k] and ladder[i]["L3"]), sum(1 for i in lw if i in obj[k]))} for k in WEB_OBJECTS}}
    # 4b: discovery and reuse of the Web subset's evaluation resources
    bench = rq4_benchmarks(C, routes, {n: j for n, j in names.items() if j in W}, cites_items, cites_labels)
    out = {"works": len(W), "share": _pct(len(W), C.n), "objects": {k: len(v) for k, v in obj.items()}, "roles": roles.most_common(), "years": years,
           "growth": growth, "lag": lag, "ladder": ladder_w, "benchmarks": {k: bench["stats"][k] for k in ("levels", "paths", "pathsN", "mature", "ownShareOfUses", "concentration", "uses")},
           "benchmarkCases": bench["evidence"] + bench["counter"][:3]}
    ev = [C.ref(i, None, objects=sorted(C.web_objects(i))) for i in sorted(W, key=lambda i: -(U.cites[i] or 0))[:4]]
    return _card(len(W), "works on digital agents that study browsers or computer use, tools and APIs, external web content, or memory and retrieval", None, None, None, out, evidence=ev)


def write_inherit_corpus(U, C, works, fulltext_path, folder, per_family=20, seed=SEED):
    """3a sample: per mechanism, the first `per_family` defences with no visible link in a fixed shuffled order (the first four
    of the same order were the pilot, so a larger sample keeps them; owner approved 20 per mechanism on 2026-10-21)"""
    import gzip
    abstract = lambda i: (U.s2[i] or {}).get("abstract") or U.byid[U.ids[i]].get("summary") or ""
    _, member = rq3_inherit(C, works)
    rnd = random.Random(seed)
    refs = lambda i: [(r.get("title") or "") for r in ((works.get(U.ids[i]) or {}).get("references") or [])][:80]
    n_i = 0
    with open(os.path.join(folder, "inherit_corpus.jsonl"), "w", encoding="utf-8") as f:
        for key, label, mech, stage, agent_rx, classic_rx in FAMILIES:
            pool = sorted(member[key]["none"])
            rnd.shuffle(pool)
            arx = re.compile(agent_rx, re.I)
            for i in pool[:per_family]:
                path = fulltext_path(U, i)
                ps = []
                if path:
                    t = gzip.open(path, "rt", encoding="utf-8", errors="ignore").read()
                    ps = [s for s in re.split(r"(?<=[.!?])\s+", t) if arx.search(s) and len(s) < 600][:12]
                text = "Mechanism: " + label + "\n\nAbstract: " + abstract(i) + "\n\nPassages: " + " ".join(ps) + "\n\nReference titles: " + " | ".join(refs(i))
                f.write(json.dumps({"id": U.ids[i], "title": U.title[i], "text": text[:12000], "family": key}, ensure_ascii=False) + "\n")
                n_i += 1
    return n_i
