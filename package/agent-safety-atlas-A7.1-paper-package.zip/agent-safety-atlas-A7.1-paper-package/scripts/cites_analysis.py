#!/usr/bin/env python3
"""Evidence-board cards from why works cite each other (intake/screening/label_cites.py, rules cites-v1).
DeepSeek flash read every citation in scope from its citing sentences (Semantic Scholar contexts). Claude Opus 5.5 read a
stratified sample of 199 as a check: 95.5% agreement on the main intent. That sample is the second reading under
"other definitions". Cards follow the shape of evidence_analysis.py.

  cbench     F18: when a benchmark is cited, is it used? (intent of citations to Atlas benchmarks)
  cmigrate   F23: across clusters, do methods move or only words? (adopted or used, against background mentions)
  ccounter   F24: counter-evidence against defences: how often, under the same conditions or changed ones, and is it answered?
"""
import json
import os
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from evidence_analysis import _card, _pct, _records  # noqa: E402

ENGAGED = ("uses_artifact", "adopts_method", "compares")


def _load(path):
    out = {}
    if path and os.path.exists(path):
        for l in open(path, encoding="utf-8"):
            r = json.loads(l)
            if r.get("labels"):
                out[r["id"]] = r["labels"]
    return out


def cites_section(U, corpus_path, path, second=None, routes=None, verify=None, verify_bg=None):
    """verify: Claude Opus 5.5 under the stricter rules cites-v2 on every citation DeepSeek read as engaged, supportive or
    counter-evidence; verify_bg: the same on a random 1,000 of those DeepSeek read as background, to estimate misses."""
    if not (os.path.exists(corpus_path) and os.path.exists(path)):
        return {}
    items = {json.loads(l)["id"]: json.loads(l) for l in open(corpus_path)}
    D, B = _load(path), _load(second)
    V, VB = _load(verify), _load(verify_bg)
    if not D:
        return {}
    A = {**D, **V, **VB}  # the stricter reading wherever it exists
    bg_n = sum(1 for i, d in D.items() if d["intent"] == "background" and "counterevidence" not in d.get("also", []))
    def miss_in(sub, pred):  # citations in `sub` that DeepSeek read as background but the stricter reading would not: sample rate x unsampled
        sub = set(sub)
        bgs = [i for i in sub if i in D and D[i]["intent"] == "background" and "counterevidence" not in D[i].get("also", [])]
        vb = [i for i in bgs if i in VB]
        return sum(1 for i in vb if pred(VB[i])) / len(vb) * (len(bgs) - len(vb)) if vb else 0
    pos = lambda pid: U.pos.get(pid)
    ref = lambda it, quote, **kw: {"id": it["citing"], "title": it["citingTitle"], "year": U.year[pos(it["citing"])] if pos(it["citing"]) is not None else None, "quote": quote, "cited": it["citedTitle"][:80], **kw}
    use_routes = {(U.ids[i], U.ids[j]) for (i, j), r in (routes or {}).items() if r["kind"] == "use"}
    cards = {}
    dist = lambda ids, R: Counter(R[i]["intent"] for i in ids if i in R)
    # ---------------------------------------------------------------- F18: citations to benchmarks
    bids = [i for i, it in items.items() if "benchmark" in it["kinds"]]
    lab = [i for i in bids if i in A]
    d = dist(lab, A)
    eng = sum(d[k] for k in ENGAGED)
    all_to_bench = sum(1 for (i, j) in U.links if U.form[j] == "benchmark")
    per = defaultdict(Counter)
    for i in lab:
        per[items[i]["cited"]][A[i]["intent"] in ENGAGED] += 1
    top = sorted(per.items(), key=lambda kv: -sum(kv[1].values()))[:12]
    rows = [{"id": b, "title": U.title[pos(b)] if pos(b) is not None else b, "citations": sum(c.values()), "engaged": c[True], "share": _pct(c[True], sum(c.values()))} for b, c in top]
    routed = [i for i in lab if (items[i]["citing"], items[i]["cited"]) in use_routes]
    labB = [i for i in bids if i in B]
    dB = dist(labB, B)
    bg = [i for i in lab if A[i]["intent"] == "background"]
    us = [i for i in lab if A[i]["intent"] == "uses_artifact"]
    cards["cbench"] = _card(len(lab), "citations from one Atlas work to an Atlas benchmark, with citing sentences, read for their intent", all_to_bench - len(lab), all_to_bench,
                            "citations to Atlas benchmarks without citing sentences (Semantic Scholar did not parse the citing text) or not read",
                            {"intents": {k: _pct(v, len(lab)) for k, v in d.most_common()}, "engaged": _pct(eng, len(lab)), "used": _pct(d["uses_artifact"], len(lab)),
                             "background": _pct(d["background"], len(lab)), "benchmarks": rows,
                             "routeCheck": {"withUseRoute": len(routed), "readAsUse": _pct(sum(1 for i in routed if A[i]["intent"] in ENGAGED or "uses_artifact" in A[i]["also"]), len(routed))}},
                            evidence=[ref(items[i], A[i].get("evidence")) for i in bg[:3]],
                            support=[ref(items[i], A[i].get("evidence")) for i in bg[3:9]],
                            counter=[ref(items[i], A[i].get("evidence")) for i in us[:6]],
                            alt=[{"key": "secondReader", "value": _pct(dB["background"], len(labB)), "base": len(labB), "label": "background"},
                                 {"key": "usesOrCompares", "value": _pct(d["uses_artifact"] + d["compares"], len(lab)), "base": len(lab)},
                                 {"key": "anyUseIntent", "value": _pct(sum(1 for i in lab if A[i]["intent"] == "uses_artifact" or "uses_artifact" in A[i]["also"]), len(lab)), "base": len(lab)},
                                 {"key": "s2Methodology", "value": _pct(sum(1 for i in lab if "methodology" in items[i]["s2intents"]), len(lab)), "base": len(lab)},
                                 {"key": "missCorrected", "value": _pct(eng + miss_in(lab, lambda d: d["intent"] in ENGAGED), len(lab)), "base": len(lab)},
                                 {"key": "firstReader", "value": _pct(sum(1 for i in lab if i in D and D[i]["intent"] in ENGAGED), len(lab)), "base": len(lab)}])
    # ---------------------------------------------------------------- F23: across clusters
    cross = [i for i, it in items.items() if "cross" in it["kinds"] and i in A]
    within = [i for i, it in items.items() if "cross" not in it["kinds"] and i in A]  # within-cluster citations to benchmarks and defences
    cross_bd = [i for i in cross if {"benchmark", "defense"} & set(items[i]["kinds"])]
    eng_s = lambda ids, R=A: _pct(sum(1 for i in ids if R[i]["intent"] in ENGAGED), len(ids))
    by_year = defaultdict(list)
    for i in cross:
        y = U.year[pos(items[i]["citing"])] if pos(items[i]["citing"]) is not None else None
        if y:
            by_year[y].append(i)
    flows = Counter()
    for i in cross:
        if A[i]["intent"] in ("adopts_method", "uses_artifact"):
            a, b = pos(items[i]["cited"]), pos(items[i]["citing"])
            if a is not None and b is not None and U.ptopics[a] and U.ptopics[b]:
                flows[(U.ptopics[a][0], U.ptopics[b][0])] += 1
    crossB = [i for i in cross if i in B]
    mig = [i for i in cross if A[i]["intent"] == "adopts_method"]
    bgc = [i for i in cross if A[i]["intent"] == "background"]
    cards["cmigrate"] = _card(len(cross), "citations between works that share no cluster, with citing sentences, read for their intent", sum(1 for i, it in items.items() if "cross" in it["kinds"] and i not in A),
                              sum(1 for it in items.values() if "cross" in it["kinds"]), "cross-cluster citations with sentences whose intent could not be read",
                              {"intents": {k: _pct(v, len(cross)) for k, v in dist(cross, A).most_common()}, "engaged": eng_s(cross), "withinEngaged": eng_s(within),
                               "crossBDEngaged": eng_s(cross_bd), "byYear": [{"year": y, "citations": len(v), "engaged": eng_s(v)} for y, v in sorted(by_year.items()) if len(v) >= 30],
                               "flows": [{"from": a, "to": b, "citations": n} for (a, b), n in flows.most_common(10)]},
                              evidence=[ref(items[i], A[i].get("evidence")) for i in mig[:3]],
                              support=[ref(items[i], A[i].get("evidence")) for i in mig[3:9]],
                              counter=[ref(items[i], A[i].get("evidence")) for i in bgc[:6]],
                              alt=[{"key": "secondReader", "value": eng_s(crossB, B), "base": len(crossB)},
                                   {"key": "sameTargets", "value": eng_s(cross_bd), "base": len(cross_bd)},
                                   {"key": "withinCluster", "value": eng_s(within), "base": len(within)}])
    # ---------------------------------------------------------------- F24: counter-evidence against defences
    dids = [i for i, it in items.items() if "defense" in it["kinds"] and i in A]
    ce = [i for i in dids if A[i]["intent"] == "counterevidence" or ("counterevidence" in A[i]["also"] and i in V)]
    crit = [i for i in dids if A[i]["intent"] == "critique"]
    ce_first = [i for i in dids if i in D and (D[i]["intent"] == "counterevidence" or "counterevidence" in D[i].get("also", []))]
    same = Counter(A[i].get("same_conditions") for i in ce)
    authors = lambda pid: {a.lower() for a in (U.byid[pid].get("authors") or []) if isinstance(a, str)}
    answered, aware = 0, []
    for i in ce:
        c, d0 = pos(items[i]["citing"]), pos(items[i]["cited"])
        if c is None or d0 is None or not U.date[c]:
            continue
        team = authors(items[i]["cited"])
        later_by_team = [k for k in U.cited_by[c] if U.date[k] and U.date[k] >= U.date[c] and team & authors(U.ids[k])]
        answered += bool(later_by_team)
        # later works that cite the defence: do they also cite the counter-evidence?
        later = [k for k in U.cited_by[d0] if U.date[k] and U.date[k] > U.date[c] and k != c]
        if later:
            aware.append(_pct(sum(1 for k in later if c in U.refs[k]), len(later)))
    most = Counter(items[i]["cited"] for i in ce).most_common(8)
    dB = [i for i, it in items.items() if "defense" in it["kinds"] and i in B]
    ceB = [i for i in dB if B[i]["intent"] == "counterevidence" or "counterevidence" in B[i]["also"]]
    changed = [i for i in ce if A[i].get("same_conditions") == "no"]
    samec = [i for i in ce if A[i].get("same_conditions") == "yes"]
    med = lambda v: sorted(v)[len(v) // 2] if v else None
    cards["ccounter"] = _card(len(dids), "citations to Atlas defences, with citing sentences, read for their intent", sum(1 for it in items.values() if "defense" in it["kinds"]) - len(dids),
                              sum(1 for it in items.values() if "defense" in it["kinds"]), "citations to defences whose intent could not be read",
                              {"counter": len(ce), "share": _pct(len(ce), len(dids)), "critique": len(crit), "critiqueShare": _pct(len(crit), len(dids)), "firstReaderCounter": len(ce_first), "sameConditions": dict(same), "changedShare": _pct(same["no"], len(ce)), "unclearShare": _pct(same["unclear"], len(ce)),
                               "answeredByTeam": _pct(answered, len(ce)), "laterAwareMedian": med(aware), "defences": [{"id": b, "title": U.title[pos(b)] if pos(b) is not None else b, "counter": n} for b, n in most]},
                              evidence=[ref(items[i], A[i].get("evidence"), conditions=A[i].get("conditions")) for i in changed[:3]],
                              support=[ref(items[i], A[i].get("evidence"), conditions=A[i].get("conditions")) for i in changed[3:9]],
                              counter=[ref(items[i], A[i].get("evidence"), conditions=A[i].get("conditions")) for i in samec[:6]],
                              alt=[{"key": "firstReaderLoose", "value": _pct(len(ce_first), len(dids)), "base": len(dids)},
                                   {"key": "missCorrectedCounter", "value": _pct(len(ce) + miss_in(dids, lambda d: d["intent"] == "counterevidence"), len(dids)), "base": len(dids)},
                                   {"key": "withCritique", "value": _pct(len(ce) + len(crit), len(dids)), "base": len(dids)},
                                   {"key": "mainIntentOnly", "value": _pct(sum(1 for i in dids if A[i]["intent"] == "counterevidence"), len(dids)), "base": len(dids)},
                                   {"key": "sameOfKnown", "value": _pct(same["yes"], same["yes"] + same["no"]), "base": same["yes"] + same["no"]}])
    # ---------------------------------------------------------------- item-level records behind F18, F23 and F24: one row per citation
    day = lambda pid: U.date[pos(pid)].isoformat() if pos(pid) is not None and U.date[pos(pid)] else None
    reader = lambda i: "Claude Opus 5.5 (cites-v2)" if i in V or i in VB else "DeepSeek (cites-v1)"
    basis = ["Citing sentences from Semantic Scholar; DeepSeek reads every one (rules cites-v1) and Claude Opus 5.5 re-reads every citation read as use, engagement, support or counter-evidence under stricter rules (cites-v2).",
             "引用句来自 Semantic Scholar；DeepSeek 读每一条（规则 cites-v1），凡读为使用、参与、支持或反证的，由 Claude Opus 5.5 按收严规则（cites-v2）重读。"]
    cols = [["cited", "Cited work", "被引工作", "paper"], ["intent", "Intent", "引用意图", "text"], ["also", "Also", "次要意图", "list"], ["reader", "Read by", "读取", "text"]]
    row = lambda i, extra=(): [items[i]["citing"], day(items[i]["citing"]), [items[i]["cited"], A[i]["intent"], ", ".join(A[i].get("also") or []), reader(i), *extra], A[i].get("evidence"), []]
    recs = {"F18": _records(["citation to a benchmark", "对基准的一次引用"], basis, cols, [row(i) for i in lab]),
            "F23": _records(["citation between works that share no cluster", "不共享星团的两项工作之间的一次引用"], basis, cols, [row(i) for i in cross]),
            "F24": _records(["citation to a defence that reports counter-evidence or criticises it", "报告反证或批评防御的一次引用"], basis,
                            cols + [["sameConditions", "Same conditions as the claim", "与原主张条件相同", "text"], ["conditions", "Conditions", "检验条件", "text"]],
                            [row(i, (A[i].get("same_conditions") or "", A[i].get("conditions") or "")) for i in ce + crit])}
    # ---------------------------------------------------------------- J6 (G4): a challenge and the defence team's later work
    # Joined per citation to a defence: is the defence's team active after the citing work (a later Atlas work sharing an
    # author), and does that later work cite it? Counter-evidence is set against the other citations to the same defences
    # (use, comparison, adoption, support, background), under the same rule, so a low rate is not read as silence when the
    # team simply published nothing later (owner, 2026-10-19: "补吧")
    by_author = defaultdict(list)
    for k in range(U.n):
        for a in authors(U.ids[k]):
            by_author[a].append(k)
    def follow(i):
        c, d0 = pos(items[i]["citing"]), pos(items[i]["cited"])
        if c is None or d0 is None or not U.date[c]:
            return None
        team = authors(items[i]["cited"])
        if team & authors(items[i]["citing"]):
            return None  # the team citing itself is not a challenge from outside, nor a baseline citation from outside
        later = {k for a in team for k in by_author[a] if k not in (c, d0) and U.date[k] and U.date[k] > U.date[c]}
        return {"i": i, "active": len(later), "cites": any(c in U.refs[k] for k in later)}
    other_intents = {"background", "uses_artifact", "compares", "adopts_method", "supports"}
    chall = [x for x in map(follow, ce) if x]
    base = [x for x in map(follow, [i for i in dids if A[i]["intent"] in other_intents and i not in ce]) if x]
    rate = lambda xs: {"citations": len(xs), "active": _pct(sum(1 for x in xs if x["active"]), len(xs)), "activeN": sum(1 for x in xs if x["active"]),
                       "citedByActive": _pct(sum(1 for x in xs if x["active"] and x["cites"]), sum(1 for x in xs if x["active"]))}
    by_cond = {k: rate([x for x in chall if A[x["i"]].get("same_conditions") == k]) for k in ("yes", "no", "unclear")}
    # matched on the defence: for defences with both kinds, the share of active-team cases that cite, per kind
    dfs = defaultdict(lambda: {"c": [], "b": []})
    for x in chall:
        dfs[items[x["i"]]["cited"]]["c"].append(x)
    for x in base:
        if items[x["i"]]["cited"] in dfs:
            dfs[items[x["i"]]["cited"]]["b"].append(x)
    both = {d: v for d, v in dfs.items() if any(x["active"] for x in v["c"]) and any(x["active"] for x in v["b"])}
    m_c = [sum(x["cites"] for x in v["c"] if x["active"]) / sum(1 for x in v["c"] if x["active"]) for v in both.values()]
    m_b = [sum(x["cites"] for x in v["b"] if x["active"]) / sum(1 for x in v["b"] if x["active"]) for v in both.values()]
    # did the challenged defence change? its arXiv versions after the first counter-evidence, and where there is one, the two
    # abstracts compared by Claude Opus 5.5 (intake/screening/check_revisions.py)
    rev_path = os.path.join(os.path.dirname(os.path.dirname(path)), "revisions", "revisions_v1.jsonl")
    revs = [json.loads(l) for l in open(rev_path, encoding="utf-8")] if os.path.exists(rev_path) else []
    later = [r for r in revs if r.get("labels")]
    revision = {"checked": len(revs), "noLater": sum(1 for r in revs if "no_later_version" in r["issues"]),
                "undecidable": sum(1 for r in revs if "first_version_after_challenge" in r["issues"] or any(i.startswith("fetch_failed") for i in r["issues"])),
                "later": len(later), "change": dict(Counter(r["labels"]["change"] for r in later)),
                "addresses": sum(1 for r in later if r["labels"].get("addresses_challenge") == "yes"),
                "cases": [{"id": r["id"], "title": U.title[pos(r["id"])] if pos(r["id"]) is not None else r["id"], "arxiv": r["arxiv"], "from": r["before"]["v"], "to": r["after"]["v"],
                           "change": r["labels"]["change"], "addresses": r["labels"].get("addresses_challenge"), "summary": r["labels"].get("summary"), "evidence": r["labels"].get("evidence")} for r in later]} if revs else None
    cards["jrespond"] = _card(len(chall), "outside counter-evidence against an Atlas defence (citing work by no author of the defence)", len(ce) - len(chall), len(ce),
                              "counter-evidence by the defence's own authors, or without a date",
                              {"counter": rate(chall), "baseline": rate(base), "byConditions": by_cond,
                               "matched": {"defences": len(both), "counterCited": round(100 * sum(m_c) / len(m_c), 1) if m_c else None, "baselineCited": round(100 * sum(m_b) / len(m_b), 1) if m_b else None},
                               "revision": revision})
    recs["J6"] = _records(["citation to a defence by an outside work", "外部工作对防御的一次引用"],
                          ["Joined per citation: the citing sentence's intent (counter-evidence or another intent), whether the defence's team has a later Atlas work after the citing work (shared author), and whether that later work cites it.",
                           "按引用连接：引用句意图（反例或其他意图）、引用之后防御团队是否有新的 Atlas 工作（共享作者），以及这些新工作是否引用了它。"],
                          [["cited", "Defence", "防御", "paper"], ["kind", "Citation", "引用类型", "text"], ["laterTeamWorks", "Later works by the team", "团队后来的工作数", "num"], ["citedBack", "Cited by the team later", "团队后来引用", "text"]],
                          [[items[x["i"]]["citing"], day(items[x["i"]]["citing"]), [items[x["i"]]["cited"], "counterevidence" if x in chall else A[x["i"]]["intent"], x["active"], "yes" if x["cites"] else ("no" if x["active"] else "")],
                            A[x["i"]].get("evidence"), [] if x["active"] else ["citedBack"]] for x in chall + base])
    return {"rules": "cites-v1 + cites-v2 verification", "citations": len(A), "verified": len(V), "backgroundSample": len(VB), "cards": cards, "records": recs}
