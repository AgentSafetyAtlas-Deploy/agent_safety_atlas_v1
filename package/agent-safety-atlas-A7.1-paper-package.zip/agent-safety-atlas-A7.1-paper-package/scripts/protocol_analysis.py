#!/usr/bin/env python3
"""Evidence-board cards from the experiment protocol cards (intake/screening/label_protocol.py, rules protocol-v1).
Claude Opus 5.5 is the reader; DeepSeek flash read the same passages and serves as the second reading under "other definitions".
Cards follow the shape of evidence_analysis.py (denominator, missing, result, evidence, cases, other definitions, no difference).

  pjudging   how safety outcomes are decided, and how open the model judges are (disclosed, validated, prompt, sensitivity)
  pjudged    judging level 2: does a judge grade a model of its own family? (judge -> judged, as the paper states it)
  pcompare   F16: can two papers on the same benchmark be compared? (version, criterion, judge, target models)
  putility   F19: is safety reported with utility, for the same configurations?
  pthreat    F20: the attacker's access and budget; are defences tested against adaptive attackers?
  player     F21: at which layer is safety measured (output, tool call, environment state, consequence)?
  pchains    F22: risks tested across components (where a risk enters, where the harm shows)
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from evidence_analysis import _card, _pct, _records  # noqa: E402


def _load(path):
    out = {}
    if path and os.path.exists(path):
        for l in open(path, encoding="utf-8"):
            r = json.loads(l)
            if r.get("labels"):
                out[r["id"]] = r["labels"]
    return out


def _bname(s):
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower().split("(")[0])


def _adaptive(A, path):
    """the adaptive-attacker field re-read on its own (relabel_adaptive.py, rules adaptive-v2) replaces the first reading, whose
    evidence was shared with the attacker's access and budget; adaptive_evidence is the phrase showing the experiment"""
    v2 = _load(os.path.join(os.path.dirname(path), "adaptive_v2.jsonl")) if path else {}
    return {p: ({**d, "adaptive_attack": v2[p]["adaptive"], "adaptive_evidence": v2[p].get("evidence") or None, "adaptive_rules": "adaptive-v2"} if p in v2 else d) for p, d in A.items()}


def _judgecheck(A, path):
    """the two checks on a model judge re-read on their own (relabel_judge_checks.py, rules judgecheck-v2) replace the first
    reading, whose only evidence was the judging method as a whole; each answer keeps the phrase it rests on"""
    v2 = _load(os.path.join(os.path.dirname(path), "judgecheck_v2.jsonl")) if path else {}
    return {p: ({**d, "judge_prompt_released": v2[p]["prompt_released"], "prompt_evidence": v2[p].get("prompt_evidence") or None,
                 "human_validation": v2[p]["human_validation"], "human_evidence": v2[p].get("human_evidence") or None, "judgecheck_rules": "judgecheck-v2"} if p in v2 else d)
            for p, d in A.items()}


def _filled(A, path):
    """the benchmark uses with the fields the evaluation passages left unstated, filled from elsewhere in the paper (appendices
    included) by fill_benchmark_fields.py; a field is filled only where it was missing and the text states it"""
    if not path or not os.path.exists(path):
        return A
    fills = {}
    for line in open(path, encoding="utf-8"):
        r = json.loads(line)
        if r.get("fields"):
            fills[(r["id"], r["benchmark"])] = (r["missing"], r["fields"])
    out = {}
    for p, d in A.items():
        uses = []
        for b in d.get("benchmark_uses") or []:
            got = fills.get((p, _bname(b.get("name")))) if isinstance(b, dict) else None
            if got:
                miss, f = got
                b = dict(b)
                ev = {}  # the phrase behind each filled field, kept for the item-level record
                if "version" in miss and f.get("version_or_subset"):
                    b["version_or_subset"] = f["version_or_subset"]; ev["version"] = f.get("version_evidence")
                if "criterion" in miss and f.get("success_criterion"):
                    b["success_criterion"] = f["success_criterion"]; ev["criterion"] = f.get("criterion_evidence")
                if "targets" in miss and f.get("target_models"):
                    b["target_models"] = f["target_models"]; ev["targets"] = f.get("targets_evidence")
                b["fill_evidence"] = ev
            uses.append(b)
        out[p] = {**d, "benchmark_uses": uses}
    return out


def protocol_section(U, facets, path, second=None, G=None, norm=None, roles=None, models_meta=None, canon_path=None, claims_path=None, claims_second=None):
    A, B = _judgecheck(_adaptive(_load(path), path), path), _load(second)
    if not A:
        return {}
    pats = [(k, re.compile(p)) for k, _, _, _, _, p, _ in (G or [])]
    fam_of = lambda name: {models_meta[k]["family"] for k, p in pats if p.search(norm(name or ""))} if models_meta else set()
    pos = {pid: U.pos[pid] for pid in A if pid in U.pos}
    role = lambda pid: (facets.get(pos[pid]) or {}).get("role_primary") if pid in pos else None
    ref = lambda pid, quote=None, **kw: {"id": pid, "title": U.title[pos[pid]] if pid in pos else pid, "year": U.year[pos[pid]] if pid in pos else None, "quote": quote, **kw}
    n = len(A)
    scope = None  # the papers the run was asked about (parsed or not) are in the labels file; the unparsed are missing
    total = len({json.loads(l)["id"] for l in open(path)}) if os.path.exists(path) else n  # papers asked about (retries repeat lines)
    cards = {}

    def share(R, key, val, among=None):
        ids = [p for p in R if among is None or among(p, R[p])]
        return _pct(sum(1 for p in ids if R[p].get(key) == val), len(ids)), len(ids)

    # ---------------------------------------------------------------- how outcomes are decided
    prim = Counter(d.get("primary_method") for d in A.values())
    llm = [p for p, d in A.items() if "llm_judge" in (d.get("verdict_methods") or [])]
    by_role = {r: Counter(A[p].get("primary_method") for p in A if role(p) == r) for r in ("attack", "defense", "benchmark", "measurement")}
    open_ = {k: _pct(sum(1 for p in llm if A[p].get(k) in v), len(llm)) for k, v in (("judge_disclosed", ("model_and_version",)), ("human_validation", ("yes",)),
                                                                                    ("judge_prompt_released", ("yes",)), ("sensitivity_reported", ("yes",)), ("multiple_judges", ("yes",)))}
    unvalid = [p for p in llm if A[p].get("human_validation") != "yes"]
    valid = [p for p in llm if A[p].get("human_validation") == "yes" and A[p].get("sensitivity_reported") == "yes"]
    llmB = [p for p, d in B.items() if "llm_judge" in (d.get("verdict_methods") or [])]
    cards["pjudging"] = _card(n, "2026 attack, defence, benchmark and measurement papers with experiments whose protocol card was read", total - n + prim[None], total,
                              "papers whose card could not be read, or whose passages do not say how the main results are decided",
                              {"primary": dict(prim.most_common()), "byRole": {r: dict(c.most_common()) for r, c in by_role.items()}, "llmPapers": len(llm), "llmShare": _pct(len(llm), n), "open": open_},
                              evidence=[ref(p, A[p].get("judging_evidence")) for p in llm[:3]],
                              support=[ref(p, (A[p].get("judges") or [{}])[0].get("evidence"), judge=[j.get("name") for j in A[p].get("judges") or []]) for p in unvalid[:6]],
                              counter=[ref(p, A[p].get("human_agreement") or A[p].get("judging_evidence")) for p in valid[:6]],
                              alt=[{"key": "secondReader", "value": _pct(sum(1 for p in llmB if B[p].get("human_validation") == "yes"), len(llmB)), "base": len(llmB)},
                                   {"key": "primaryLLM", "value": _pct(sum(1 for p in A if A[p].get("primary_method") == "llm_judge" and A[p].get("human_validation") == "yes"), prim["llm_judge"]), "base": prim["llm_judge"]},
                                   {"key": "validatedAmongLLM", "value": open_["human_validation"], "base": len(llm)}])
    # ---------------------------------------------------------------- level 2: judge -> judged
    def judged_rel(R):
        rows = []
        for p, d in R.items():
            subj = set()
            if roles and p in roles and models_meta:
                subj = {models_meta[g]["family"] for g, rs in roles[p].items() if "subject" in rs}
            for j in d.get("judges") or []:
                if j.get("kind") != "llm_judge":
                    continue
                jf = fam_of(j.get("name"))
                judged = j.get("judged") or []
                allm = any("all" in (x or "").lower() for x in judged)
                tf = set().union(*[fam_of(x) for x in judged]) if judged else set()
                if allm:
                    tf |= subj
                rows.append({"paper": p, "judge": j.get("name"), "jf": jf, "tf": tf, "stated": bool(judged), "all": allm, "evidence": j.get("evidence")})
        return rows
    rel = judged_rel(A)
    known = [r for r in rel if r["jf"] and r["tf"]]
    same = [r for r in known if r["jf"] & r["tf"]]
    papers_known = {r["paper"] for r in known}
    papers_same = {r["paper"] for r in same}
    relB = judged_rel(B)
    knownB = [r for r in relB if r["jf"] and r["tf"]]
    no_all = [r for r in known if not r["all"]]
    cards["pjudged"] = _card(len(papers_known), "papers with a model judge whose family and whose judged models' families are known", len({r["paper"] for r in rel}) - len(papers_known), len({r["paper"] for r in rel}),
                             "papers with a model judge whose model, or the models it judges, the passages do not name",
                             {"judges": len(known), "sameFamilyJudges": _pct(len(same), len(known)), "sameFamilyPapers": _pct(len(papers_same), len(papers_known)),
                              "families": dict(Counter(f for r in same for f in r["jf"] & r["tf"]).most_common(6))},
                             evidence=[ref(r["paper"], r["evidence"], judge=[r["judge"]], subject=sorted(r["tf"])) for r in same[:3]],
                             support=[ref(r["paper"], r["evidence"], judge=[r["judge"]], subject=sorted(r["tf"])) for r in same[3:9]],
                             counter=[ref(r["paper"], r["evidence"], judge=[r["judge"]], subject=sorted(r["tf"])) for r in known if not (r["jf"] & r["tf"])][:6],
                             alt=[{"key": "secondReader", "value": _pct(sum(1 for r in knownB if r["jf"] & r["tf"]), len(knownB)), "base": len(knownB)},
                                  {"key": "namedOnly", "value": _pct(sum(1 for r in no_all if r["jf"] & r["tf"]), len(no_all)), "base": len(no_all)},
                                  {"key": "byJudge", "value": _pct(len(same), len(known)), "base": len(known)}])
    # ---------------------------------------------------------------- F16: same benchmark, comparable setups?
    def classes(R, min_papers=5, paper_targets=True, need_judge=False):
        uses = defaultdict(list)
        for p, d in R.items():
            for b in d.get("benchmark_uses") or []:
                k = _bname(b.get("name"))
                if k:
                    tf = set().union(*[fam_of(x) for x in (b.get("target_models") or [])]) if b.get("target_models") else set()
                    from_paper = False
                    if not tf and paper_targets and roles and p in roles and models_meta:  # the paper names its studied models once, not per benchmark
                        tf = {models_meta[g]["family"] for g, rs in roles[p].items() if "subject" in rs}
                        from_paper = bool(tf)
                    uses[k].append({"paper": p, "name": b.get("name"), "version": bool(b.get("version_or_subset")), "criterion": bool(b.get("success_criterion")),
                                    "judge": bool(b.get("judge")), "rule": bool(b.get("success_criterion") or b.get("judge")), "targets": tf, "fromPaper": from_paper,
                                    "access": b.get("attacker_access"), "budget": bool(b.get("budget")), "evidence": b.get("evidence"), "fillEv": b.get("fill_evidence") or {},
                                    "versionText": (b.get("version_or_subset") or "").strip(), "criterionText": (b.get("success_criterion") or "").strip()})
        cls, per_bench, stated = Counter(), {}, Counter()
        for k, us in uses.items():
            us = list({u["paper"]: u for u in us}.values())
            for u in us:
                for f in ("version", "criterion", "judge", "rule", "budget"):
                    stated[f] += u[f]
                stated["fromPaper"] += u["fromPaper"]
                stated["targets"] += bool(u["targets"])
                stated["uses"] += 1
            if len(us) < min_papers:
                continue
            c = Counter()
            for a in range(len(us)):
                for b in range(a + 1, len(us)):
                    x, y = us[a], us[b]
                    if not x["targets"] or not y["targets"]:
                        c["noTargets"] += 1
                    elif not (x["targets"] & y["targets"]):
                        c["otherTargets"] += 1
                    elif all(x[f] and y[f] for f in (("version", "criterion", "judge") if need_judge else ("version", "rule"))):
                        c["allReported"] += 1
                    else:
                        c["partlyReported"] += 1
            cls.update(c)
            per_bench[k] = {"name": us[0]["name"], "papers": len(us), **dict(c)}
        return cls, per_bench, stated, uses
    AF = _filled(A, os.path.join(os.path.dirname(path), "fill_v1.jsonl"))  # F16 reads the filled uses
    cls, per_bench, stated, uses = classes(AF)
    # the four classes of the owner's research document, on the benchmarks whose reported versions and criteria were grouped
    # into canonical categories (canon_benchmarks.py): same core conditions, comparable after adjustment, key differences,
    # under-reported. Reported-and-same needs the same version category and the same criterion category, plus shared targets.
    canon = json.load(open(canon_path)) if canon_path and os.path.exists(canon_path) else {}
    def four_classes(default_version=False):
        """pairs in the four classes; default_version: a version left unstated counts as the benchmark's default release"""
        out = Counter()
        for k, cn in canon.items():
            us = list({u["paper"]: u for u in uses.get(k, [])}.values())
            vmap, cmap = cn.get("version") or {}, cn.get("criterion") or {}
            for a in range(len(us)):
                for b in range(a + 1, len(us)):
                    x, y = us[a], us[b]
                    vx, vy = vmap.get(x["versionText"]), vmap.get(y["versionText"])
                    if default_version:
                        vx, vy = vx or "(default)", vy or "(default)"
                    cx, cy = cmap.get(x["criterionText"]), cmap.get(y["criterionText"])
                    if not x["targets"] or not y["targets"] or not (vx and vy and cx and cy):
                        out["underReported"] += 1
                    elif cx != cy or not (x["targets"] & y["targets"]):
                        out["keyDiff"] += 1
                    else:
                        out["sameCore" if vx == vy else "adjust"] += 1
        return out
    four, four_bench, four_ex = Counter(), [], defaultdict(list)
    four_same, cases = Counter(), defaultdict(list)  # pairs of two attacks or two defences; worked examples of differing conditions
    for k, cn in canon.items():
        us = list({u["paper"]: u for u in uses.get(k, [])}.values())
        vmap, cmap = cn.get("version") or {}, cn.get("criterion") or {}
        c = Counter()
        for a in range(len(us)):
            for b in range(a + 1, len(us)):
                x, y = us[a], us[b]
                vx, vy, cx, cy = vmap.get(x["versionText"]), vmap.get(y["versionText"]), cmap.get(x["criterionText"]), cmap.get(y["criterionText"])
                if not x["targets"] or not y["targets"] or not (vx and vy and cx and cy):
                    cl = "underReported"
                elif cx != cy or not (x["targets"] & y["targets"]):
                    cl = "keyDiff"
                elif vx == vy:
                    cl = "sameCore"
                else:
                    cl = "adjust"
                c[cl] += 1
                if len(four_ex[cl]) < 6:
                    four_ex[cl].append((x, y, k))
                if role(x["paper"]) == role(y["paper"]) and role(x["paper"]) in ("attack", "defense"):
                    four_same[cl] += 1
                    if cl in ("keyDiff", "adjust") and role(x["paper"]) == "defense":
                        diff = tuple(f for f, a_, b_ in (("version", vx, vy), ("criterion", cx, cy)) if a_ != b_) + (("targets",) if not (x["targets"] & y["targets"]) else ())
                        if diff and len(cases[(k, diff)]) < 1:
                            side = lambda u, vc, cc: {"id": u["paper"], "version": u["versionText"], "versionCat": vc, "criterion": u["criterionText"], "criterionCat": cc, "targets": sorted(u["targets"])}
                            cases[(k, diff)].append({"benchmark": cn.get("name", k), "differs": list(diff), "a": side(x, vx, cx), "b": side(y, vy, cy)})
        four.update(c)
        if us:
            four_bench.append({"key": k, "name": cn.get("name", k), "papers": len(us), "versions": len(set(vmap.values())), "criteria": len(set(cmap.values())), **dict(c)})
    four_bench.sort(key=lambda r: -r["papers"])
    n4 = sum(four.values())
    K4 = ("sameCore", "adjust", "keyDiff", "underReported")
    nb = lambda r: sum(r.get(x, 0) for x in K4)
    head_b = max(four_bench, key=nb) if four_bench else None  # the benchmark holding the most pairs
    no_top = Counter({x: four[x] - (head_b or {}).get(x, 0) for x in K4})
    eq = {x: round(sum(100 * r.get(x, 0) / nb(r) for r in four_bench if nb(r)) / max(1, sum(1 for r in four_bench if nb(r))), 1) for x in K4}
    robust = [{"key": "pairs", **{x: _pct(four[x], n4) for x in K4}, "n": n4},
              {"key": "equalBenchmarks", **eq, "n": sum(1 for r in four_bench if nb(r))},
              {"key": "withoutTop", "label": head_b["name"] if head_b else "", "topShare": _pct(nb(head_b), n4) if head_b else None, **{x: _pct(no_top[x], sum(no_top.values())) for x in K4}, "n": sum(no_top.values())},
              {"key": "sameRole", **{x: _pct(four_same[x], sum(four_same.values())) for x in K4}, "n": sum(four_same.values())}]
    pick = []  # one worked example for each way conditions differ, most-used benchmarks first
    for diff in (("version",), ("criterion",), ("targets",), ("version", "criterion")):
        got = next((v[0] for (k, d), v in sorted(cases.items(), key=lambda kv: -next((r["papers"] for r in four_bench if r["key"] == kv[0][0]), 0)) if d == diff), None)
        if got:
            pick.append(got)
    clsB, _, _, _ = classes(B)
    pairs = sum(cls.values())
    top = sorted(per_bench.values(), key=lambda r: -r["papers"])[:10]
    biggest = max(uses.items(), key=lambda kv: len(kv[1]))[0] if uses else None
    full = [u for u in uses.get(biggest, []) if u["version"] and u["rule"] and u["targets"]]
    part = [u for u in uses.get(biggest, []) if not (u["version"] and u["criterion"])]
    cards["pcompare"] = _card(pairs, "pairs of papers that run experiments on the same benchmark (benchmarks used by at least five papers)", cls["noTargets"], pairs,
                              "pairs where at least one paper does not name the models it tested on the benchmark",
                              {"classes": dict(cls), "shares": {k: _pct(v, pairs) for k, v in cls.items()}, "benchmarks": top,
                               "four": {k: four[k] for k in ("sameCore", "adjust", "keyDiff", "underReported")}, "fourShares": {k: _pct(four[k], n4) for k in ("sameCore", "adjust", "keyDiff", "underReported")},
                               "fourPairs": n4, "fourBenchmarks": four_bench[:12], "canonBenchmarks": len(canon), "robust": robust, "cases": pick[:4],
                               "stated": {f: _pct(stated[f], stated["uses"]) for f in ("version", "criterion", "judge", "rule", "budget", "targets", "fromPaper")}, "uses": stated["uses"]},
                              evidence=[ref(x["paper"], x["evidence"], benchmark=x["name"]) for x, _, _ in four_ex["keyDiff"][:3]] or [ref(u["paper"], u["evidence"], benchmark=u["name"]) for u in full[:3]],
                              support=[ref(x["paper"], x["evidence"], benchmark=x["name"]) for x, _, _ in four_ex["underReported"][:3]] + [ref(y["paper"], y["evidence"], benchmark=y["name"]) for _, y, _ in four_ex["keyDiff"][:3]],
                              counter=[ref(x["paper"], x["evidence"], benchmark=x["name"]) for x, _, _ in four_ex["sameCore"][:6]],
                              alt=[{"key": "secondReader", "value": _pct(clsB["allReported"], sum(clsB.values())), "base": sum(clsB.values())},
                                   {"key": "allReported", "value": _pct(cls["allReported"], pairs), "base": pairs},
                                   {"key": "threePapers", "value": _pct(classes(AF, 3)[0]["allReported"], sum(classes(AF, 3)[0].values())), "base": sum(classes(AF, 3)[0].values())},
                                   {"key": "benchmarkTargetsOnly", "value": _pct(classes(AF, paper_targets=False)[0]["noTargets"], sum(classes(AF, paper_targets=False)[0].values())), "base": sum(classes(AF, paper_targets=False)[0].values())},
                                   {"key": "defaultVersion", "value": _pct(four_classes(True)["underReported"], sum(four_classes(True).values())), "base": sum(four_classes(True).values()), "label": "under-reported"},
                                   {"key": "defaultVersionSame", "value": _pct(four_classes(True)["sameCore"], sum(four_classes(True).values())), "base": sum(four_classes(True).values()), "label": "same core"},
                                   {"key": "judgeRequired", "value": _pct(classes(AF, need_judge=True)[0]["allReported"], sum(classes(AF, need_judge=True)[0].values())), "base": sum(classes(AF, need_judge=True)[0].values())}])
    # ---------------------------------------------------------------- F19: safety with utility
    defs = [p for p in A if role(p) == "defense"]
    u_def, nd = share(A, "utility_reported", "yes", lambda p, d: role(p) == "defense")
    paired_def, npd = share(A, "paired_reporting", "yes", lambda p, d: role(p) == "defense")
    defsB = [p for p in B if role(p) == "defense"]
    # cost (owner, 2026-10-19: answer the cost half of the question from the cards): a defence reports cost when one of its
    # utility measures is an overhead (latency, tokens, compute, runtime, throughput, memory, money); what it needs is read
    # from the resources the card lists, grouped by keyword
    OVER = re.compile(r"latenc|overhead|token|cost|compute|runtime|run time|throughput|memory|time per|seconds|\bms\b|gpu|flops|price|dollar|\$", re.I)
    NEED = [("calls", re.compile(r"model call|llm|guard model|judge|validator|agent|inference|quer|embedding", re.I)),
            ("training", re.compile(r"fine-?tun|train|lora|dataset|data\b|labell?ed", re.I)),
            ("human", re.compile(r"human|user confirm|manual|approval|annotat", re.I)),
            ("internals", re.compile(r"white-?box|activation|hidden state|logit|gradient|weights", re.I))]
    cost = {p: any(OVER.search(m or "") for m in A[p].get("utility_metrics") or []) for p in defs}
    needs = {p: {k for k, rx in NEED if any(rx.search(x or "") for x in A[p].get("defender_resources") or [])} for p in defs}
    cost_stats = {"reported": _pct(sum(cost.values()), len(defs)), "needs": {k: _pct(sum(1 for p in defs if k in needs[p]), len(defs)) for k, _ in NEED},
                  "reportedWhenNeeds": {k: _pct(sum(1 for p in defs if k in needs[p] and cost[p]), sum(1 for p in defs if k in needs[p])) for k, _ in NEED},
                  "utilityAndCost": _pct(sum(1 for p in defs if A[p].get("utility_reported") == "yes" and cost[p]), len(defs))}
    cards["putility"] = _card(len(defs), "defence papers with a protocol card", sum(1 for p in defs if A[p].get("utility_reported") == "not_stated"), len(defs),
                              "defence papers whose passages do not say whether utility was measured",
                              {"defenceUtility": u_def, "defencePaired": paired_def, "allUtility": share(A, "utility_reported", "yes")[0], "allPaired": share(A, "paired_reporting", "yes")[0], "cost": cost_stats,
                               "byRole": {r: share(A, "utility_reported", "yes", lambda p, d, r=r: role(p) == r)[0] for r in ("attack", "defense", "benchmark", "measurement")},
                               "metrics": Counter(m.lower() for p in defs for m in A[p].get("utility_metrics") or []).most_common(10)},
                              evidence=[ref(p, A[p].get("utility_evidence")) for p in defs if A[p].get("paired_reporting") == "yes"][:3],
                              support=[ref(p, A[p].get("utility_evidence")) for p in defs if A[p].get("paired_reporting") == "yes"][3:9],
                              counter=[ref(p, A[p].get("judging_evidence")) for p in defs if A[p].get("utility_reported") == "no"][:6],
                              alt=[{"key": "secondReader", "value": _pct(sum(1 for p in defsB if B[p].get("utility_reported") == "yes"), len(defsB)), "base": len(defsB)},
                                   {"key": "notStatedAsNo", "value": u_def, "base": nd},
                                   {"key": "pairedAmongUtility", "value": _pct(sum(1 for p in defs if A[p].get("paired_reporting") == "yes"), sum(1 for p in defs if A[p].get("utility_reported") == "yes")),
                                    "base": sum(1 for p in defs if A[p].get("utility_reported") == "yes")}])
    # ---------------------------------------------------------------- F20: attacker and defender
    # adaptive testing and the attack budget are read on the defences that face an adversary, the same base as the joint
    # analysis of validation conditions (J2); a defence whose card marks the attacker as not applicable is left out
    ad = [p for p in A if role(p) in ("attack", "defense")]
    acc = Counter(A[p].get("attacker_access") for p in ad)
    dap = [p for p in defs if A[p].get("attacker_access") != "not_applicable"]
    adapt = Counter(A[p].get("adaptive_attack") for p in dap)
    known_ad = adapt["yes"] + adapt["no"]
    dapB = [p for p in defsB if B[p].get("attacker_access") != "not_applicable"]
    adaptB = Counter(B[p].get("adaptive_attack") for p in dapB)
    readers_gap = abs((_pct(adapt["yes"], known_ad) or 0) - (_pct(adaptB["yes"], adaptB["yes"] + adaptB["no"]) or 0))
    aev = lambda p: A[p].get("adaptive_evidence") or A[p].get("threat_evidence")
    # the range of models each defence facing an adversary is tested on: the studied models named in its experiments
    # (model roles matched to the registry), counted as models, families, and open-weight against API-only
    def studied(p):
        if not roles or not models_meta or p not in roles:
            return None
        gs = [g for g, rs in roles[p].items() if "subject" in rs and g in models_meta]
        return gs or None
    mr = {p: studied(p) for p in dap}
    known = [p for p in dap if mr[p]]
    fam = {p: {models_meta[g]["family"] for g in mr[p]} for p in known}
    opn = {p: {bool(models_meta[g]["open"]) for g in mr[p]} for p in known}
    med = lambda v: sorted(v)[len(v) // 2] if v else None
    model_range = {"known": len(known), "of": len(dap), "medianModels": med([len(mr[p]) for p in known]), "medianFamilies": med([len(fam[p]) for p in known]),
                   "oneFamily": _pct(sum(1 for p in known if len(fam[p]) == 1), len(known)), "threeFamilies": _pct(sum(1 for p in known if len(fam[p]) >= 3), len(known)),
                   "openAndApi": _pct(sum(1 for p in known if opn[p] == {True, False}), len(known)), "apiOnly": _pct(sum(1 for p in known if opn[p] == {False}), len(known)),
                   "openOnly": _pct(sum(1 for p in known if opn[p] == {True}), len(known)),
                   "families": {str(k): sum(1 for p in known if min(len(fam[p]), 4) == k) for k in (1, 2, 3, 4)}} if known else None
    cards["pthreat"] = _card(len(dap), "defence papers with a protocol card that face an adversary", adapt["not_stated"], len(dap), "defences whose passages do not say which attacks the defence was tested against",
                             {"adaptive": dict(adapt), "adaptiveShare": _pct(adapt["yes"], known_ad), "adaptiveOfAll": _pct(adapt["yes"], len(dap)), "access": dict(acc.most_common()),
                              "defences": len(defs), "applies": len(dap), "notApplicable": len(defs) - len(dap), "reread": sum(1 for p in dap if A[p].get("adaptive_rules")), "models": model_range,
                              "budgetStated": _pct(sum(1 for p in ad if A[p].get("attacker_budget")), len(ad)), "budgetDefences": _pct(sum(1 for p in dap if A[p].get("attacker_budget")), len(dap)),
                              "resources": Counter(x.lower() for p in defs for x in A[p].get("defender_resources") or []).most_common(8)},
                             evidence=[ref(p, aev(p)) for p in dap if A[p].get("adaptive_attack") == "no" and aev(p)][:3],
                             support=[ref(p, aev(p)) for p in dap if A[p].get("adaptive_attack") == "no" and aev(p)][3:9],
                             counter=[ref(p, aev(p)) for p in dap if A[p].get("adaptive_attack") == "yes"][:6],
                             alt=[{"key": "secondReader", "value": _pct(adaptB["yes"], adaptB["yes"] + adaptB["no"]), "base": adaptB["yes"] + adaptB["no"]},
                                  {"key": "ofAllDefences", "value": _pct(adapt["yes"], len(dap)), "base": len(dap)},
                                  {"key": "budgetStated", "value": _pct(sum(1 for p in ad if A[p].get("attacker_budget")), len(ad)), "base": len(ad)}],
                             null_note=("The two readers disagree by %.0f points on adaptive testing; the share uses the main reader (Claude Opus 5.5), whose labels the source audit on this card checks." % readers_gap) if readers_gap >= 10 else None)
    # ---------------------------------------------------------------- F21: the measured layer
    layer = Counter(d.get("primary_layer") for d in A.values())
    anyl = Counter(x for d in A.values() for x in d.get("measured_layers") or [])
    kind = lambda p: "physical" if set((facets.get(pos[p]) or {}).get("settings") or []) & {"embodied_robot", "driving_drone"} else "digital"
    by_kind = {k: dict(Counter(A[p].get("primary_layer") for p in A if p in pos and kind(p) == k).most_common()) for k in ("digital", "physical")}
    layB = Counter(d.get("primary_layer") for d in B.values())
    nl = sum(v for k, v in layer.items() if k)
    cards["player"] = _card(nl, "papers whose card names the layer behind the main results", layer[None] + total - n, total, "papers whose passages do not say at which layer the main results are measured",
                            {"primary": {k: _pct(v, nl) for k, v in layer.items() if k}, "any": {k: _pct(v, n) for k, v in anyl.items()}, "byKind": by_kind},
                            evidence=[ref(p, A[p].get("layer_evidence"), layer=A[p].get("primary_layer")) for p in A if A[p].get("primary_layer") in ("output_text", "tool_call") and A[p].get("layer_evidence")][:3],
                            support=[ref(p, A[p].get("layer_evidence"), layer=A[p].get("primary_layer")) for p in A if A[p].get("primary_layer") in ("output_text", "tool_call") and A[p].get("layer_evidence")][3:9],
                            counter=[ref(p, A[p].get("layer_evidence"), layer="consequence") for p in A if A[p].get("primary_layer") == "consequence"][:6],
                            alt=[{"key": "secondReader", "value": _pct(layB["output_text"], sum(v for k, v in layB.items() if k)), "base": sum(v for k, v in layB.items() if k), "label": "output_text"},
                                 {"key": "anyLayerConsequence", "value": _pct(anyl["consequence"], n), "base": n},
                                 {"key": "primaryConsequence", "value": _pct(layer["consequence"], nl), "base": nl}])
    # ---------------------------------------------------------------- F21: the layer a paper claims against the layer it measures
    CL, CL2 = _load(claims_path), _load(claims_second)
    if CL:
        rank = {k: r for r, k in enumerate(("output_text", "tool_call", "environment_state", "consequence"))}
        def matrix(C, M, any_layer=False):
            both = [p for p in M if p in C and C[p].get("primary_claim_layer") and (M[p].get("primary_layer") or (any_layer and M[p].get("measured_layers")))]
            mat, beyond, same, below = Counter(), [], [], []
            for p in both:
                c = C[p]["primary_claim_layer"]
                m = M[p].get("primary_layer")
                if any_layer:  # the claim is met if any measured layer reaches it
                    ms = M[p].get("measured_layers") or [m]
                    m = max((x for x in ms if x in rank), key=lambda x: rank[x], default=m)
                if m not in rank:
                    continue
                mat[(c, m)] += 1
                (beyond if rank[c] > rank[m] else same if c == m else below).append(p)
            return mat, beyond, same, below, both
        mat, beyond, same, below, both_ = matrix(CL, A)
        nb = len(beyond) + len(same) + len(below)
        no_claim = sum(1 for p in A if p in CL and not CL[p].get("primary_claim_layer"))
        mat_any, beyond_any, *_ , both_any = matrix(CL, A, any_layer=True)
        nb_any = sum(mat_any.values())
        mat2, beyond2, same2, below2, _ = matrix(CL2, A) if CL2 else (Counter(), [], [], [], [])
        defs_b = [p for p in beyond if role(p) == "defense"]
        defs_n = sum(1 for p in beyond + same + below if role(p) == "defense")
        kinds = Counter(CL[p].get("claim_kind") for p in A if p in CL)
        # consequence claims re-read for commitment (label_claim_commitment.py): motivation or an explicit claim at that level
        CM = _load(os.path.join(os.path.dirname(claims_path), "commitment_v1.jsonl"))
        cons = [p for p in both_ if CL[p]["primary_claim_layer"] == "consequence" and A[p].get("primary_layer") in rank]
        conseq = {"papers": len(cons), "beyond": sum(1 for p in cons if p in beyond)}
        if CM:
            got = [p for p in cons if p in CM]
            conseq.update({"read": len(got), **{k: sum(1 for p in got if CM[p]["commitment"] == k) for k in ("explicit", "motivation", "unclear")},
                           "explicitBeyond": sum(1 for p in got if CM[p]["commitment"] == "explicit" and p in beyond),
                           "motivationBeyond": sum(1 for p in got if CM[p]["commitment"] == "motivation" and p in beyond)})
            # the overall shares without the papers whose consequence claim is only motivation (their own claim is about something else)
            mot = {p for p in got if CM[p]["commitment"] == "motivation"}
            kept = [p for p in beyond + same + below if p not in mot]
            conseq.update({"keptPapers": len(kept), "beyondKept": _pct(sum(1 for p in beyond if p not in mot), len(kept)), "sameKept": _pct(sum(1 for p in same if p not in mot), len(kept))})
        cards["pclaim"] = _card(nb, "papers whose abstract states a protected layer and whose protocol card names the layer of the main results", len(A) - nb, len(A),
                                "papers whose abstract claims no particular layer, or whose measured layer is not stated",
                                {"matrix": {f"{c}|{m}": v for (c, m), v in mat.items()}, "beyond": _pct(len(beyond), nb), "same": _pct(len(same), nb), "below": _pct(len(below), nb),
                                 "noClaim": no_claim, "kinds": dict(kinds.most_common()), "consequence": conseq, "byClaim": {c: _pct(sum(v for (cc, m), v in mat.items() if cc == c and rank[m] < rank[c]), sum(v for (cc, m), v in mat.items() if cc == c)) for c in rank}},
                                evidence=[ref(p, CL[p].get("claim"), layer=f"{CL[p]['primary_claim_layer']} → {A[p].get('primary_layer')}") for p in beyond[:3]],
                                support=[ref(p, A[p].get("layer_evidence"), layer=f"{CL[p]['primary_claim_layer']} → {A[p].get('primary_layer')}") for p in beyond[3:9]],
                                counter=[ref(p, CL[p].get("claim"), layer=f"{CL[p]['primary_claim_layer']} → {A[p].get('primary_layer')}") for p in same[:6]],
                                alt=[{"key": "anyMeasuredLayer", "value": _pct(len(beyond_any), nb_any), "base": nb_any},
                                     {"key": "secondReaderClaims", "value": _pct(len(beyond2), len(beyond2) + len(same2) + len(below2)), "base": len(beyond2) + len(same2) + len(below2)},
                                     {"key": "defencesOnly", "value": _pct(len(defs_b), defs_n), "base": defs_n}])
    # ---------------------------------------------------------------- F22: chains across components
    PROMPTS = ("user_prompt", "system_prompt")
    # chains re-read with "model_output" as a place (relabel_chains.py, rules chains-v2) replace the first reading for those papers
    v2 = _load(os.path.join(os.path.dirname(path), "chains_v2.jsonl"))
    A22 = {p: ({**d, "cross_component_tests": v2[p]["cross_component_tests"]} if p in v2 else d) for p, d in A.items()}
    ch_any = [(p, c) for p, d in A22.items() for c in d.get("cross_component_tests") or [] if c.get("entry") != c.get("effect")]
    ch = [(p, c) for p, c in ch_any if c.get("entry") not in PROMPTS]  # a risk entering through another component, not the prompt
    pc = {p for p, _ in ch}
    pairs22 = Counter((c["entry"], c["effect"]) for _, c in ch)
    chB = {p for p, d in B.items() for c in d.get("cross_component_tests") or [] if c.get("entry") != c.get("effect") and c.get("entry") not in PROMPTS}
    cards["pchains"] = _card(n, "papers with a protocol card", total - n, total, "papers whose card could not be read",
                             {"papers": len(pc), "share": _pct(len(pc), n), "pairs": [{"entry": a, "effect": b, "papers": v} for (a, b), v in pairs22.most_common(10)],
                              "byRole": {r: _pct(sum(1 for p in pc if role(p) == r), sum(1 for p in A if role(p) == r)) for r in ("attack", "defense", "benchmark", "measurement")}},
                             evidence=[ref(p, c.get("evidence"), chain=f"{c['entry']} → {c['effect']}") for p, c in ch[:3]],
                             support=[ref(p, c.get("evidence"), chain=f"{c['entry']} → {c['effect']}") for p, c in ch[3:9]],
                             counter=[ref(p, A[p].get("layer_evidence")) for p in A if p not in pc and role(p) in ("attack", "defense")][:6],
                             alt=[{"key": "secondReader", "value": _pct(len(chB), len(B)), "base": len(B)},
                                  {"key": "withPrompts", "value": _pct(len({p for p, _ in ch_any}), n), "base": n},
                                  {"key": "attacksOnly", "value": _pct(sum(1 for p in pc if role(p) == "attack"), sum(1 for p in A if role(p) == "attack")), "base": sum(1 for p in A if role(p) == "attack")}])
    # ---------------------------------------------------------------- item-level records behind F9, F16, F19-F22
    day = lambda p: U.date[pos[p]].isoformat() if p in pos and U.date[pos[p]] else None
    rd = lambda p: role(p) or ""
    basis = ["Experiment protocol card: Claude Opus 5.5 reads the evaluation passages of each paper (rules protocol-v1); every field comes with a phrase copied from the paper.",
             "实验方案卡：Claude Opus 5.5 读每篇论文描述评测的段落（规则 protocol-v1），每个字段附从论文原样摘出的短语。"]
    fams = lambda s_: ", ".join(sorted(s_))
    recs = {}
    recs["F9"] = _records(["judge in a paper", "论文中的模型裁判"], basis,
                          [["judge", "Judge", "裁判", "text"], ["judgeFamily", "Judge family", "裁判家族", "text"], ["judgedFamilies", "Families it grades", "被评模型家族", "text"], ["sameFamily", "Same family", "同家族", "text"]],
                          [[r["paper"], day(r["paper"]), [r["judge"], fams(r["jf"]), fams(r["tf"]), ("yes" if r["jf"] & r["tf"] else "no") if r["jf"] and r["tf"] else ""], r["evidence"],
                            [k for k, v in (("judgeFamily", r["jf"]), ("judgedFamilies", r["tf"])) if not v]] for r in rel])
    rows16 = []
    for k, cn in canon.items():
        vmap, cmap = cn.get("version") or {}, cn.get("criterion") or {}
        for u in list({u["paper"]: u for u in uses.get(k, [])}.values()):
            before = next((b for b in A.get(u["paper"], {}).get("benchmark_uses") or [] if isinstance(b, dict) and _bname(b.get("name")) == k), {})
            filled = [f for f, a_, b_ in (("version", before.get("version_or_subset"), u["versionText"]), ("criterion", before.get("success_criterion"), u["criterionText"])) if (a_ or "").strip() != b_]
            unk = [f for f, v in (("version", vmap.get(u["versionText"])), ("criterion", cmap.get(u["criterionText"])), ("targets", u["targets"])) if not v]
            rows16.append([u["paper"], day(u["paper"]), [cn.get("name", k), u["versionText"], vmap.get(u["versionText"]) or "", u["criterionText"], cmap.get(u["criterionText"]) or "",
                                                         fams(u["targets"]), "paper's studied models" if u["fromPaper"] else "", ", ".join(filled)],
                           [["benchmark", u["evidence"]]] + [[f, e] for f, e in u["fillEv"].items() if e], unk])
    recs["F16"] = _records(["use of a most-used benchmark", "对高使用基准的一次使用"],
                           [basis[0] + " Fields the passages leave unstated are filled from elsewhere in the paper, appendices included (fill-v1); versions and criteria are grouped into canonical categories per benchmark.",
                            basis[1] + "段落未说明的字段，从论文其他部分（含附录）补读（fill-v1）；版本与判据按基准归并为标准类别。"],
                           [["benchmark", "Benchmark", "基准", "text"], ["version", "Version or subset", "版本或子集", "text"], ["versionCat", "Version category", "版本类别", "text"],
                            ["criterion", "Success criterion", "成功判据", "text"], ["criterionCat", "Criterion category", "判据类别", "text"], ["targets", "Target families", "被测模型家族", "text"],
                            ["targetsFrom", "Targets from", "被测模型来源", "text"], ["filled", "Filled from elsewhere", "从附录等处补读", "text"]], rows16)
    ns = lambda v: v in (None, "", "not_stated")
    recs["F19"] = _records(["defence paper", "防御论文"], basis,
                           [["utility", "Utility measured", "测量效用", "text"], ["paired", "Paired with safety", "与安全配对报告", "text"], ["metrics", "Utility metrics", "效用指标", "list"]],
                           [[p, day(p), [A[p].get("utility_reported") or "", A[p].get("paired_reporting") or "", ", ".join(A[p].get("utility_metrics") or [])], A[p].get("utility_evidence"),
                             [k for k, f in (("utility", "utility_reported"), ("paired", "paired_reporting")) if ns(A[p].get(f))]] for p in defs])
    recs["F20"] = _records(["defence paper", "防御论文"], basis,
                           [["adaptive", "Adaptive attacker", "自适应攻击检验", "text"], ["access", "Attacker access", "攻击者权限", "text"], ["budget", "Attack budget", "攻击预算", "text"],
                            ["resources", "Defender resources", "防御方资源", "list"]],
                           [[p, day(p), [A[p].get("adaptive_attack") or "", A[p].get("attacker_access") or "", A[p].get("attacker_budget") or "", ", ".join(A[p].get("defender_resources") or [])],
                             [x for x in (["adaptive", A[p].get("adaptive_evidence")], ["threat", A[p].get("threat_evidence")]) if x[1]] or None,
                             [k for k, f in (("adaptive", "adaptive_attack"), ("access", "attacker_access"), ("budget", "attacker_budget")) if ns(A[p].get(f))]] for p in defs])
    if CL:
        rel21 = lambda p: ("" if not (CL.get(p, {}).get("primary_claim_layer") in rank and A[p].get("primary_layer") in rank) else
                           "beyond" if rank[CL[p]["primary_claim_layer"]] > rank[A[p]["primary_layer"]] else "same" if CL[p]["primary_claim_layer"] == A[p]["primary_layer"] else "below")
        recs["F21"] = _records(["paper", "论文"], [basis[0] + " The claimed layer is read from the abstract and introduction (rules claims-v1).", basis[1] + "声称层次读自摘要与引言（规则 claims-v1）。"],
                               [["role", "Contribution", "贡献类型", "text"], ["claimKind", "Claim", "主张类型", "text"], ["claimed", "Claimed layer", "声称层次", "text"], ["measured", "Measured layer", "测量层次", "text"],
                                ["relation", "Claim against measurement", "主张与测量", "text"], ["claim", "Claim (quoted)", "主张原文", "text"]],
                               [[p, day(p), [rd(p), (CL.get(p) or {}).get("claim_kind") or "", (CL.get(p) or {}).get("primary_claim_layer") or "", A[p].get("primary_layer") or "", rel21(p), (CL.get(p) or {}).get("claim") or ""],
                                 A[p].get("layer_evidence"), [k for k, v in (("claimed", (CL.get(p) or {}).get("primary_claim_layer")), ("measured", A[p].get("primary_layer"))) if not v]] for p in A])
    chains_of = defaultdict(list)
    for p_, c_ in ch:
        chains_of[p_].append(c_)
    recs["F22"] = _records(["paper", "论文"], basis,
                           [["role", "Contribution", "贡献类型", "text"], ["chains", "Chains tested (entry → harm)", "检验的链条（进入 → 伤害）", "list"], ["layer", "Measured layer", "测量层次", "text"]],
                           [[p, day(p), [rd(p), "; ".join(f"{c_['entry']} → {c_['effect']}" for c_ in chains_of.get(p, [])), A[p].get("primary_layer") or ""],
                             (chains_of[p][0].get("evidence") if chains_of.get(p) else A[p].get("layer_evidence")), []] for p in A])
    return {"rules": "protocol-v1", "papers": n, "cards": cards, "records": recs}
