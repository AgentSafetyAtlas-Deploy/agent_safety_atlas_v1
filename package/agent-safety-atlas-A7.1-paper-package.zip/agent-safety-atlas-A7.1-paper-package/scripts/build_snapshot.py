#!/usr/bin/env python3
"""
Frozen release package of the research universe (paper outline v0.4: "a frozen first release plus a maintained platform").

A snapshot is everything needed to check or recompute the published figures for one release, without the website:
  works.jsonl         one line per active work: identifiers, dates with precision, clusters (topics), galaxy, form,
                      publication record, code/resource links, institutions (ROR) and countries, withdrawal state
  relations-NN.jsonl  typed routes (in parts under 20 MB) with their basis: citation (Semantic Scholar reference list; citing sentence and
                      intents when Semantic Scholar has them) and benchmark use (the sentence in the using work)
  clusters.json       clusters (editorial topics), galaxies (theme groups), candidate clusters (automatic, with members)
  institutions.jsonl  ROR identities used, with country and organisation type; registry matches judged wrong are left out
  findings.json       the observation report computed on this release; starmap-bands.json (per-work band signals)
  datacard.json       what the package is, how it was made, sources and their terms, coverage, known limits
  scripts/            the builders that produced it (recompute instructions in datacard.json)
  MANIFEST.json       file list with sha256 and counts; snapshot-<version>.zip holds all of the above

Paper text is never included: only identifiers, titles, editorial summaries and short quoted sentences (<= 320 chars) that
serve as evidence for a relation. E-mail addresses are removed from every quoted sentence.
  python build_snapshot.py --version v1 [--status draft|frozen]
"""
import argparse
import datetime as dt
import glob
import gzip
import hashlib
import json
import os
import re
import shutil
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "dist", "data")
CG = os.path.join(HERE, "research-paths", "citation-graph")
META = os.path.normpath(os.path.join(HERE, "..", "..", "intake", "screening", "meta"))
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+(?:@|%40)[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
SCRIPTS = ["build_findings.py", "build_starmap.py", "collect_citation_graph.py", "collect_citation_contexts.py", "embed_specter2.py",
           "build_snapshot.py"]

SOURCES = [  # terms as stated by each provider; "check" marks what must be confirmed before any public release
    {"source": "arXiv (OAI-PMH metadata)", "used_for": "titles, first-submission dates, identifiers", "terms": "arXiv states its metadata is available under CC0 1.0", "check": False},
    {"source": "Semantic Scholar Academic Graph API", "used_for": "reference lists, citation counts, citing sentences and intents", "terms": "Semantic Scholar API License Agreement; attribution required", "check": True},
    {"source": "OpenAlex", "used_for": "publication leads, abstracts for screening", "terms": "CC0 1.0", "check": False},
    {"source": "Crossref", "used_for": "DOI publication records", "terms": "bibliographic metadata facts; Crossref states most metadata has no use restrictions", "check": True},
    {"source": "dblp (monthly XML snapshot)", "used_for": "venue matching", "terms": "CC0 1.0", "check": False},
    {"source": "ROR", "used_for": "institution identities, countries, organisation types", "terms": "CC0 1.0", "check": False},
    {"source": "Conference and journal proceedings pages", "used_for": "venue, title and author verification", "terms": "bibliographic facts with source URLs; no text redistributed", "check": True},
    {"source": "GitHub API", "used_for": "repository links and stars (dated snapshots)", "terms": "GitHub Terms of Service; repository metadata only", "check": True},
    {"source": "Paper full texts (arXiv HTML/PDF, open-access copies)", "used_for": "benchmark-use sentences (read locally)", "terms": "not redistributed; only short quoted sentences as evidence", "check": True},
    {"source": "SPECTER2 (allenai/specter2)", "used_for": "content vectors for layout, candidate clusters and relevance", "terms": "model released under Apache 2.0; vectors not redistributed, 2-D positions only", "check": False},
    {"source": "Atlas editorial layer", "used_for": "scope decisions, clusters, forms, summaries, audits", "terms": "licence to be chosen by the owner (for example CC BY 4.0)", "check": True},
]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def scrub(text):
    return EMAIL.sub("[e-mail removed]", text or "")



CJK = re.compile(r"[\u3400-\u9fff\uf900-\ufaff]")  # paper-level data stays English (a citing paper's Chinese drafting note)


class Parts:
    """Write JSON lines into <stem>-01.jsonl, <stem>-02.jsonl, ... starting a new part before one passes `limit` bytes."""

    def __init__(self, out, stem, limit):
        self.out, self.stem, self.limit, self.k, self.f, self.size = out, stem, limit, 0, None, 0

    def __enter__(self):
        self._next()
        return self

    def _next(self):
        if self.f:
            self.f.close()
        self.k += 1
        self.f, self.size = open(os.path.join(self.out, f"{self.stem}-{self.k:02d}.jsonl"), "w", encoding="utf-8"), 0

    def write(self, line):
        n = len(line.encode("utf-8"))
        if self.size and self.size + n > self.limit:
            self._next()
        self.f.write(line)
        self.size += n

    def __exit__(self, *exc):
        self.f.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", default="v1")
    ap.add_argument("--status", choices=["draft", "frozen"], default="draft")
    # the snapshot follows the analysis version: release_analysis.py builds it next to a candidate report, from the
    # data release that report was computed on, and copies it to the site when the version is published
    ap.add_argument("--findings", help="the observation report to package (default dist/data/findings.json)")
    ap.add_argument("--out", help="output folder (default dist/downloads/snapshot-<version>)")
    a = ap.parse_args()
    out = a.out or os.path.join(HERE, "dist", "downloads", f"snapshot-{a.version}")
    if os.path.exists(out):
        shutil.rmtree(out)
    os.makedirs(os.path.join(out, "scripts"))
    atlas = json.load(open(os.path.join(DATA, "atlas.json"), encoding="utf-8"))
    tax = json.load(open(os.path.join(DATA, "topic-taxonomy.json"), encoding="utf-8"))
    sm = json.load(open(os.path.join(DATA, "starmap.json"), encoding="utf-8"))
    findings_path = a.findings or os.path.join(DATA, "findings.json")
    findings = json.load(open(findings_path, encoding="utf-8"))
    insights = json.load(open(os.path.join(DATA, "insights.json"), encoding="utf-8"))
    updates = json.load(open(os.path.join(DATA, "updates.json"), encoding="utf-8"))
    release = updates["releases"][0]["release"]
    assert findings["meta"]["release"] == release, f"findings.json was computed on {findings['meta']['release']}, not {release}: rerun build_findings.py"
    works = {json.loads(l)["id"]: json.loads(l) for l in open(os.path.join(CG, "works.jsonl"), encoding="utf-8")}
    # wrong registry matches are corrected in the data itself (corrections.py); nothing left to exclude here
    rejects = set()
    types = {}
    if os.path.exists(os.path.join(META, "ror_cache.jsonl")):
        for line in open(os.path.join(META, "ror_cache.jsonl"), encoding="utf-8"):
            r = json.loads(line)
            if r.get("ror_id") and r.get("types"):
                types[r["ror_id"]] = r["types"]
    team_ror = {sid: inst for inst in insights["institutions"] for sid in inst.get("sourceIds") or []}
    res_by_id = {r["id"]: r for r in atlas["resources"]}
    galaxy_of = {t: c["id"] for c in tax["categories"] for t in c["topics"]}
    active = [p for p in atlas["papers"] if p["status"] == "included" and not p["attributes"].get("withdrawal")]
    withdrawn = [p for p in atlas["papers"] if p["status"] == "included" and p["attributes"].get("withdrawal")]
    team_by_id = {t["id"]: t for t in atlas["teams"]}
    inst_rows = {}
    counts = {"works": 0, "withdrawnKept": len(withdrawn), "citationRoutes": 0, "citationWithSentence": 0, "benchmarkUseRoutes": 0,
              "institutions": 0, "candidateClusters": 0}
    # ---- works
    with open(os.path.join(out, "works.jsonl"), "w", encoding="utf-8") as f:
        for p in active + withdrawn:
            insts, countries = [], set()
            for tid in p["teams"]:
                t = team_by_id.get(tid) or {}
                inst = team_ror.get(tid)
                if inst and inst["id"] not in rejects:
                    insts.append(inst["id"])
                    loc = next((l for l in t.get("locations") or [] if l.get("countryCode")), None)
                    inst_rows.setdefault(inst["id"], {"ror": inst["id"], "name": inst["name"], "country": loc and loc["countryCode"],
                                                      "types": types.get(inst["id"], [])})
                for l in t.get("locations") or []:
                    if l.get("countryCode") and l.get("source") not in rejects and not (inst and inst["id"] in rejects):
                        countries.add(l["countryCode"])
            s2 = (works.get(p["id"]) or {}).get("s2") or {}
            topics = [t for t in tax["paperTopics"].get(p["id"], []) if galaxy_of.get(t) and galaxy_of[t] != "other"]
            pub = p.get("publication") or {}
            row = {"id": p["id"], "workId": p.get("workId"), "title": p.get("originalTitle") or p["title"], "authors": [scrub(x) for x in (p.get("authors") or p.get("originalAuthors") or [])],
                   "date": p.get("date"), "datePrecision": {10: "day", 7: "month", 4: "year"}.get(len(p.get("date") or ""), None),
                   "clusters": topics, "galaxies": sorted({galaxy_of[t] for t in topics}), "form": tax["paperForms"].get(p["id"]),
                   # a summary holding an e-mail is the paper's author block captured by mistake: left out and flagged
                   "summary": None if EMAIL.search(p.get("summary") or "") else p.get("summary"),
                   "summaryIssue": "author block captured as summary; left out" if EMAIL.search(p.get("summary") or "") else None,
                   "url": p.get("url"), "arxiv": p["attributes"].get("arxiv_id"),
                   "doi": p["attributes"].get("doi"), "semanticScholar": s2.get("paperId"),
                   "publication": {k: pub.get(k) for k in ("status", "venueName", "venueGroup", "year", "track", "url")},
                   "resources": [{"kind": res_by_id[r]["kind"], "url": res_by_id[r]["url"]} for r in p["resources"] if r in res_by_id],
                   "institutions": sorted(set(insts)), "countries": sorted(countries),
                   "withdrawnOnArxiv": bool(p["attributes"].get("withdrawal"))}
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            counts["works"] += 1
            counts["summariesLeftOut"] = counts.get("summariesLeftOut", 0) + bool(row["summaryIssue"])
    with open(os.path.join(out, "institutions.jsonl"), "w", encoding="utf-8") as f:
        for r in sorted(inst_rows.values(), key=lambda x: x["name"]):
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    counts["institutions"] = len(inst_rows)
    # ---- relations: citations (with Semantic Scholar contexts when collected) and benchmark use
    s2pid = {w["s2"]["paperId"]: wid for wid, w in works.items() if w.get("s2") and w["s2"].get("paperId")}
    ax = {w["s2"]["externalIds"]["ArXiv"]: wid for wid, w in works.items() if w.get("s2") and (w["s2"].get("externalIds") or {}).get("ArXiv")}
    ctx = {}
    if os.path.exists(os.path.join(CG, "contexts.jsonl")):
        for line in open(os.path.join(CG, "contexts.jsonl"), encoding="utf-8"):
            r = json.loads(line)
            for x in r["refs"]:
                ctx[(r["id"], s2pid.get(x["paperId"]))] = x
    active_ids = {p["id"] for p in active}
    for old in glob.glob(os.path.join(out, "relations*.jsonl")):
        os.remove(old)
    with Parts(out, "relations", 20 * 2 ** 20) as f:  # parts stay under the site's per-file limit
        for wid, w in works.items():
            if wid not in active_ids:
                continue
            seen = set()
            for ref in w.get("references") or []:
                j = s2pid.get(ref.get("paperId")) or ax.get(ref.get("arxiv") or "")
                if not j or j == wid or j in seen or j not in active_ids:
                    continue
                seen.add(j)
                c = ctx.get((wid, j)) or {}
                row = {"type": "cites", "from": wid, "to": j, "basis": "Semantic Scholar reference list of the citing work",
                       "contexts": [scrub(x) for x in c.get("contexts") or [] if not CJK.search(x)], "intents": c.get("intents") or [], "influential": c.get("influential")}
                counts["citationRoutes"] += 1
                counts["citationWithSentence"] += bool(row["contexts"])
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        rp = os.path.join(HERE, "research-paths", "findings", "benchmark-routes.jsonl")
        for line in open(rp, encoding="utf-8") if os.path.exists(rp) else []:
            r = json.loads(line)
            if r["kind"] != "use":
                continue
            f.write(json.dumps({"type": "uses_benchmark", "from": r["user"], "to": r["benchmark"], "name": r["name"],
                                "basis": "sentence in the using work's full text (read locally)", "evidence": scrub(r["evidence"])},
                               ensure_ascii=False) + "\n")
            counts["benchmarkUseRoutes"] += 1
    # ---- clusters
    ids = sm["ids"]
    cand = [{"id": t["id"], "cluster": t["topic"], "label": t.get("label"), "members": [ids[m] for m in t["members"]],
             "attached": [ids[m] for m in t.get("attached") or []]} for t in sm["threads"] if t.get("members") and not t.get("unclustered")]
    counts["candidateClusters"] = len(cand)
    json.dump({"galaxies": [{"id": c["id"], "name": c["en"], "clusters": c["topics"]} for c in tax["categories"] if not c.get("other")],
               "candidateClusters": cand,
               "note": "Clusters are editorial topics; a work can belong to several. Candidate clusters are automatic (HDBSCAN on SPECTER2 vectors) and are candidates, not an expert taxonomy."},
              open(os.path.join(out, "clusters.json"), "w", encoding="utf-8"), ensure_ascii=False)
    shutil.copy(findings_path, os.path.join(out, "findings.json"))
    if os.path.exists(os.path.join(DATA, "starmap-bands.json")):
        shutil.copy(os.path.join(DATA, "starmap-bands.json"), os.path.join(out, "starmap-bands.json"))
    for s in SCRIPTS:
        if os.path.exists(os.path.join(HERE, s)):
            shutil.copy(os.path.join(HERE, s), os.path.join(out, "scripts", s))
    # ---- data card
    m = findings["meta"]
    card = {
        "name": "Agent Safety Atlas research universe", "version": a.version, "status": a.status, "release": release,
        "cutoff": atlas["meta"].get("cutoff"), "worksDatedThrough": findings["universe"]["asOf"],
        "builtOn": dt.date.today().isoformat(),
        # the per-work policy versions (the atlas header field lags behind policy changes)
        "scopePolicy": ", ".join(f"{k} ({v:,} works)" for k, v in sorted(__import__("collections").Counter(
            p["attributes"].get("scope_policy_version") or "unrecorded" for p in active).items(), key=lambda kv: -kv[1])),
        "description": "Deduplicated research works on the safety and security of LLM-based and learned agents, with typed relations that keep their basis, editorial clusters, automatic candidate clusters, institutions, and the observation report computed on this release.",
        "counts": counts,
        "relationTypes": {"cites": "A's Semantic Scholar reference list contains B; contexts and intents are Semantic Scholar's when available (record-level otherwise)",
                          "uses_benchmark": f"a sentence in A's full text evaluates on, adopts or reports results on benchmark B; spot-check precision {findings['audit']['precision'] if findings.get('audit') else 'n/a'}% (n = {findings['audit']['checked'] if findings.get('audit') else 0}), roughly half of uses found"},
        "definitions": {"newStarMonths": m["novaMonths"], "referenceGroup": "(cluster, publication year, form), falling back to (cluster, year) then year",
                        "minGroup": m["minGroup"], "clusters": len(m["clusters"]), "galaxies": len(m["galaxies"])},
        "sources": SOURCES,
        "knownLimits": ["Coverage depends on the sources; a missing relation means not recorded, not unrelated.",
                        "Institution addresses are not nationalities; 21% of works have no located institution.",
                        "Benchmark use is matched by name in local full texts: a lower bound with ~85% precision.",
                        "Attack/defence labels in the onset analysis are title keywords and are not audited.",
                        "Statuses of hypotheses are observations on one release, not tests on held-out data.",
                        f"{(atlas['meta'].get('corrections') or {}).get('teamsSplit', 0)} registry (ROR) matches judged wrong were corrected: {(atlas['meta'].get('corrections') or {}).get('papersMoved', 0)} papers re-attributed to the institution printed in the paper (data-sources/corrections/)."],
        "recompute": ["python collect_citation_graph.py   # Semantic Scholar records (ids cached)",
                      "python collect_citation_contexts.py # citing sentences (optional)",
                      ".venv-specter2/bin/python embed_specter2.py",
                      "python build_starmap.py && python build_findings.py",
                      f"python build_snapshot.py --version {a.version} --status {a.status}"],
        "citation": "DOI to be assigned when the release is deposited",
    }
    json.dump(card, open(os.path.join(out, "datacard.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    # ---- manifest and zip
    files = []
    for root, _, names in os.walk(out):
        for n in sorted(names):
            pth = os.path.join(root, n)
            files.append({"path": os.path.relpath(pth, out), "bytes": os.path.getsize(pth), "sha256": sha(pth)})
    manifest = {"version": a.version, "status": a.status, "release": release, "analysisVersion": findings["meta"].get("analysisVersion"),
                "builtOn": card["builtOn"], "counts": counts, "files": files}
    json.dump(manifest, open(os.path.join(out, "MANIFEST.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    zpath = os.path.join(out, f"snapshot-{a.version}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for fobj in files + [{"path": "MANIFEST.json"}]:
            z.write(os.path.join(out, fobj["path"]), f"snapshot-{a.version}/{fobj['path']}")
    for fobj in files:
        assert fobj["bytes"] < 24 * 2 ** 20, f"{fobj['path']} is too large for the site"
        if fobj["path"].endswith((".json", ".jsonl")):
            assert not EMAIL.search(open(os.path.join(out, fobj["path"]), encoding="utf-8").read()), f"{fobj['path']}: e-mail address left"
    print(f"snapshot {a.version} ({a.status}) from {release}: {counts}; zip {os.path.getsize(zpath) // 1024} KB")


if __name__ == "__main__":
    main()
