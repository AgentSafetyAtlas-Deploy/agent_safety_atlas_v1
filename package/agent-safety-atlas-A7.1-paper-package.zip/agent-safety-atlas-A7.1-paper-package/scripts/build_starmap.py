#!/usr/bin/env python3
"""
Research paths star map: layout, candidate research threads ("constellations") and per-work relations.

Inputs
  dist/data/atlas.json, dist/data/topic-taxonomy.json        active works, topics, theme groups, years
  research-paths/starmap/embeddings.npy (+ embedding-ids.json) SPECTER2 vectors (embed_specter2.py)
  research-paths/citation-graph/works.jsonl                   Semantic Scholar records and reference lists

What each output means
  position     2-D UMAP of the SPECTER2 vectors (cosine): nearby stars have similar titles and abstracts. It is not a
               citation distance, and empty space is not a research gap.
  star size    Semantic Scholar citation count on the collection date; unknown stays unknown (-1), never zero.
  colour       theme group of the work's first Atlas topic.
  threads      per topic, HDBSCAN on a topic-local UMAP of the same vectors; automatic candidates labelled with
               class-based TF-IDF keywords of their titles and abstracts. Not an expert taxonomy. Works HDBSCAN leaves
               out join their nearest thread as "attached" when they are as close to its centre as its weakest fifth
               of core members; the rest stay outside every thread.
  thread lines a spanning tree over the thread's brightest stars; every line keeps its basis: a citation inside the Atlas,
               shared references (count), or content similarity (cosine).
  relations    per work: references and citing works inside the Atlas; bibliographic coupling (shared references,
               IDF-weighted cosine, raw shared count kept); co-citation inside the Atlas (works citing both);
               SPECTER2 nearest neighbours; references outside the Atlas cited by at least two Atlas works ("background").

Outputs (dist/data/): starmap.json, starmap-rel-<n>.json (relation shards of SHARD works), starmap-background.json
  python build_starmap.py
"""
import json
import math
import os
import re
from collections import Counter, defaultdict

import numpy as np
import scipy.sparse as sp

HERE = os.path.dirname(os.path.abspath(__file__))
SM = os.path.join(HERE, "research-paths", "starmap")
CG = os.path.join(HERE, "research-paths", "citation-graph")
DATA = os.path.join(HERE, "dist", "data")
SEED = 20261010
SHARD = 600
TOPK = 25
GENERIC = set("""agent agents agentic llm llms language model models large based using use used paper propose proposed approach approaches
method methods results show shows study studies work framework frameworks system systems novel new existing performance task tasks
evaluate evaluation evaluating demonstrate experiments experimental also however can may via across within without well first two three
large language models language models large language ai safety safe""".split())


def load():
    atlas = json.load(open(os.path.join(DATA, "atlas.json"), encoding="utf-8"))
    tax = json.load(open(os.path.join(DATA, "topic-taxonomy.json"), encoding="utf-8"))
    ids = json.load(open(os.path.join(SM, "embedding-ids.json")))
    emb = np.load(os.path.join(SM, "embeddings.npy"))
    byid = {p["id"]: p for p in atlas["papers"]}
    works = {}
    if os.path.exists(os.path.join(CG, "works.jsonl")):
        for line in open(os.path.join(CG, "works.jsonl"), encoding="utf-8"):
            r = json.loads(line)
            works[r["id"]] = r
    return atlas, tax, ids, emb, byid, works


def year_of(p):
    y = p.get("displayYear") or (p.get("date") or "")[:4]
    try:
        return int(str(y)[:4])
    except ValueError:
        return None


def topk_rows(mat, k, exclude_self=True):
    """Top-k (index, value) per row of a dense matrix, value > 0."""
    out = []
    for i in range(mat.shape[0]):
        row = mat[i].copy()
        if exclude_self:
            row[i] = -np.inf
        idx = np.argpartition(-row, min(k, len(row) - 1))[:k]
        idx = idx[np.argsort(-row[idx])]
        out.append([(int(j), float(row[j])) for j in idx if row[j] > 0])
    return out


def ctfidf_labels(docs_by_cluster, all_docs):
    from sklearn.feature_extraction.text import CountVectorizer
    vec = CountVectorizer(ngram_range=(1, 2), stop_words="english", min_df=2, token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z\-]{2,}\b")
    vec.fit(all_docs)
    keys = list(docs_by_cluster)
    tf = vec.transform([" ".join(docs_by_cluster[k]) for k in keys]).astype(float)
    tf = sp.csr_matrix(tf.multiply(1 / np.maximum(tf.sum(axis=1), 1)))
    f = np.asarray(vec.transform(all_docs).sum(axis=0)).ravel()
    avg = f.sum() / len(all_docs)
    idf = np.log(1 + avg / np.maximum(f, 1))
    score = tf.multiply(idf).tocsr()
    terms = vec.get_feature_names_out()
    labels = {}
    for r, k in enumerate(keys):
        row = score.getrow(r)
        order = row.indices[np.argsort(-row.data)]
        picked = []
        for j in order:
            t = terms[j]
            words = t.split()
            if all(w in GENERIC for w in words) or any(t in p or p in t for p in picked):
                continue
            picked.append(t)
            if len(picked) == 3:
                break
        labels[k] = picked
    return labels


def main():
    import sys
    sys.path[:] = [p for p in sys.path if os.path.abspath(p or ".") != HERE]  # platform/coverage.py would shadow the package numba imports
    import hdbscan
    import umap
    from scipy.sparse.csgraph import minimum_spanning_tree
    atlas, tax, ids, emb, byid, works = load()
    n = len(ids)
    pos = {pid: i for i, pid in enumerate(ids)}
    topics = [t for c in tax["categories"] if not c.get("other") for t in c["topics"]]
    theme_of_topic = {t: ci for ci, c in enumerate(tax["categories"]) for t in c["topics"]}
    ptopics = [[t for t in tax["paperTopics"].get(pid, []) if t in topics] for pid in ids]

    # ---------------- relations from the citation graph
    s2pid, ax, doi = {}, {}, {}
    for pid in ids:
        r = works.get(pid) or {}
        s = r.get("s2") or {}
        if s.get("paperId"):
            s2pid[s["paperId"]] = pos[pid]
        ext = s.get("externalIds") or {}
        if ext.get("ArXiv"):
            ax[ext["ArXiv"]] = pos[pid]
        if ext.get("DOI"):
            doi[ext["DOI"].lower()] = pos[pid]
        a = byid[pid]["attributes"]
        if a.get("arxiv_id"):
            ax.setdefault(a["arxiv_id"], pos[pid])
    refs_in = [set() for _ in range(n)]
    refs_ext = [set() for _ in range(n)]
    ext_meta = {}
    listed = 0
    for pid in ids:
        r = works.get(pid) or {}
        if r.get("referencesListed"):
            listed += 1
        i = pos[pid]
        for ref in r.get("references") or []:
            j = s2pid.get(ref.get("paperId")) if ref.get("paperId") else None
            j = j if j is not None else ax.get(ref.get("arxiv") or "") if ref.get("arxiv") else j
            j = j if j is not None else doi.get(ref.get("doi") or "") if ref.get("doi") else j
            if j is not None and j != i:
                refs_in[i].add(j)
            elif ref.get("paperId"):
                refs_ext[i].add(ref["paperId"])
                ext_meta.setdefault(ref["paperId"], (ref.get("title"), ref.get("year")))
    cited_by = [set() for _ in range(n)]
    for i in range(n):
        for j in refs_in[i]:
            cited_by[j].add(i)
    # bibliographic coupling on all references (Atlas and outside), IDF-weighted cosine
    allref = {}
    rows, cols = [], []
    for i in range(n):
        for key in [("a", j) for j in refs_in[i]] + [("e", e) for e in refs_ext[i]]:
            rows.append(i)
            cols.append(allref.setdefault(key, len(allref)))
    R = sp.csr_matrix((np.ones(len(rows), dtype=np.float32), (rows, cols)), shape=(n, max(len(allref), 1)))
    df = np.asarray(R.sum(axis=0)).ravel()
    Rw = R.multiply(np.log((n + 1) / (df + 1)).astype(np.float32)).tocsr()
    norms = np.sqrt(np.asarray(Rw.multiply(Rw).sum(axis=1)).ravel())
    norms[norms == 0] = 1
    Rw = sp.diags(1 / norms) @ Rw
    coupling = (Rw @ Rw.T).toarray()
    shared = (R @ R.T).toarray()
    # co-citation inside the Atlas: works cited together by the same Atlas work
    Cin = sp.csr_matrix((np.ones(sum(len(s) for s in refs_in), dtype=np.float32),
                         ([i for i in range(n) for _ in refs_in[i]], [j for i in range(n) for j in refs_in[i]])), shape=(n, n))
    cocount = (Cin.T @ Cin).toarray()
    cdeg = np.asarray(Cin.sum(axis=0)).ravel()
    cocite = cocount / np.sqrt(np.maximum(np.outer(cdeg, cdeg), 1))
    semantic = emb @ emb.T
    top_coup, top_coc, top_sem = topk_rows(coupling, TOPK), topk_rows(cocite, TOPK), topk_rows(semantic, TOPK)

    # ---------------- global layout
    xy = umap.UMAP(n_neighbors=25, min_dist=0.08, metric="cosine", random_state=SEED).fit_transform(emb)
    xy = (xy - xy.mean(axis=0)) / np.abs(xy - xy.mean(axis=0)).max()

    # ---------------- threads per topic
    tx = {json.loads(l)["id"]: json.loads(l) for l in open(os.path.join(SM, "texts.jsonl"), encoding="utf-8")}
    texts = [tx[pid]["title"] + ". " + tx[pid]["text"] for pid in ids]
    abstract_src = json.load(open(os.path.join(SM, "text-sources.json")))
    cites = []
    for pid in ids:
        c = ((works.get(pid) or {}).get("s2") or {}).get("citationCount")
        cites.append(c if isinstance(c, int) else -1)
    years = [year_of(byid[pid]) for pid in ids]
    threads = []
    for t in topics:
        members = [i for i in range(n) if t in ptopics[i]]
        if len(members) < 12:
            continue
        sub = emb[members]
        red = umap.UMAP(n_neighbors=min(15, len(members) - 1), n_components=8, min_dist=0.0, metric="cosine",
                        random_state=SEED).fit_transform(sub)
        mcs = max(6, round(len(members) * 0.025))
        lab = hdbscan.HDBSCAN(min_cluster_size=mcs, min_samples=3, cluster_selection_method="leaf").fit_predict(red)
        groups = defaultdict(list)
        for m, l in zip(members, lab):
            if l >= 0:
                groups[int(l)].append(m)
        labels = ctfidf_labels({k: [texts[m] for m in v] for k, v in groups.items()}, [texts[m] for m in members])
        # works HDBSCAN leaves as noise join their nearest thread when they are at least as close to its centre as the
        # thread's own weakest fifth of core members; the rest stay outside every thread
        cents = {k: emb[v].mean(axis=0) / np.linalg.norm(emb[v].mean(axis=0)) for k, v in groups.items()}
        floor = {k: float(np.percentile(emb[v] @ cents[k], 20)) for k, v in groups.items()}
        attached = defaultdict(list)
        noise = [m for m, l in zip(members, lab) if l < 0]
        for m in noise:
            if not cents:
                break
            k, sim = max(((k, float(emb[m] @ c)) for k, c in cents.items()), key=lambda kv: kv[1])
            if sim >= floor[k]:
                attached[k].append(m)
        for k, mem in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            cen = emb[mem].mean(axis=0)
            central = sorted(mem, key=lambda m: -float(emb[m] @ cen))
            bright = sorted(mem, key=lambda m: (-(cites[m] if cites[m] >= 0 else -1), central.index(m)))[:8]
            # spanning tree over the bright stars; each edge keeps its strongest real basis
            cand = {}
            for a_ in range(len(bright)):
                for b_ in range(a_ + 1, len(bright)):
                    i, j = bright[a_], bright[b_]
                    if j in refs_in[i] or i in refs_in[j]:
                        cand[(a_, b_)] = (1.0, "cites", int(j in refs_in[i]))
                    elif shared[i, j] >= 2:
                        cand[(a_, b_)] = (0.5 + 0.5 * float(coupling[i, j]), "shared_refs", int(shared[i, j]))
                    else:
                        cand[(a_, b_)] = (0.5 * max(float(semantic[i, j]), 0.0), "similar", round(float(semantic[i, j]), 3))
            W = np.zeros((len(bright), len(bright)))
            for (a_, b_), (s_, _, _) in cand.items():
                W[a_, b_] = 1.0001 - s_
            mst = minimum_spanning_tree(sp.csr_matrix(W)).tocoo()
            edges = []
            for a_, b_ in zip(mst.row, mst.col):
                a_, b_ = int(min(a_, b_)), int(max(a_, b_))
                s_, kind, val = cand[(a_, b_)]
                i, j = bright[a_], bright[b_]
                if kind == "cites" and not val:
                    i, j = j, i  # keep the real direction: i cites j
                edges.append([i, j, kind, val if kind != "cites" else 1])
            yrs = sorted(y for y in (years[m] for m in mem) if y)
            threads.append({"topic": t, "id": f"{topics.index(t):02d}-{len([x for x in threads if x['topic'] == t]) + 1:02d}",
                            "label": labels.get(k, []), "members": sorted(mem, key=lambda m: central.index(m)),
                            "attached": sorted(attached[k], key=lambda m: -float(emb[m] @ cents[k])),
                            "bright": bright, "edges": edges, "medianYear": yrs[len(yrs) // 2] if yrs else None,
                            "unclustered": False})
        joined = {m for v in attached.values() for m in v}
        rest = [m for m in noise if m not in joined]
        if rest:
            threads.append({"topic": t, "id": f"{topics.index(t):02d}-00", "label": [], "members": rest, "bright": [], "edges": [],
                            "medianYear": None, "unclustered": True})
        print(f"{t}: {len(members)} works, {len(groups)} threads, {len(joined)} attached, {len(rest)} outside threads", flush=True)

    # ---------------- outside-Atlas background: references cited by at least two Atlas works
    ext_count = Counter(e for s in refs_ext for e in s)
    bg = {e: k for k, (e, c) in enumerate(sorted(((e, c) for e, c in ext_count.items() if c >= 2), key=lambda x: -x[1]))}
    cjk = re.compile(r"[\u3400-\u9fff]")  # public data files stay English (validate_platform_data.py); such titles keep only their link
    background = [{"s2": e, "title": ext_meta[e][0] if ext_meta[e][0] and not cjk.search(ext_meta[e][0]) else "(non-English title; open on Semantic Scholar)",
                   "year": ext_meta[e][1], "atlasCiting": ext_count[e]} for e in bg]

    # ---------------- write
    topic_pts = {}
    for t in topics:
        m = [i for i in range(n) if t in ptopics[i]]
        if m:
            topic_pts[t] = {"x": round(float(np.median(xy[m, 0])), 4), "y": round(float(np.median(xy[m, 1])), 4), "count": len(m)}
    found = sum(1 for pid in ids if (works.get(pid) or {}).get("status") == "found")
    meta = {"release": atlas["meta"]["researchRelease"], "cutoff": atlas["meta"]["cutoff"], "works": n,
            "layout": "UMAP (cosine, n_neighbors 25, min_dist 0.08, seed %d) of SPECTER2 title+abstract vectors" % SEED,
            "model": json.load(open(os.path.join(SM, "model.json"))),
            "citationSource": "Semantic Scholar Academic Graph", "citationObserved": "2026-10-10",
            "coverage": {"foundOnSemanticScholar": found, "withReferenceList": listed,
                         "atlasCitationLinks": int(sum(len(s) for s in refs_in)),
                         "worksWithAtlasLink": int(sum(1 for i in range(n) if refs_in[i] or cited_by[i])),
                         "backgroundWorks": len(background), "textSources": Counter(abstract_src.values())},
            "threadMethod": "per topic: UMAP 8-d + HDBSCAN (leaf, min cluster 2.5% of topic, at least 6); c-TF-IDF keyword labels",
            "shards": math.ceil(n / SHARD), "shardSize": SHARD}
    out = {"meta": meta, "themes": [{"id": c["id"], "en": c["en"], "color": c["color"]} for c in tax["categories"]],
           "topics": [{"name": t, "theme": theme_of_topic[t], **topic_pts.get(t, {})} for t in topics],
           "ids": ids, "x": [round(float(v), 4) for v in xy[:, 0]], "y": [round(float(v), 4) for v in xy[:, 1]],
           "cites": cites, "year": years, "theme": [theme_of_topic[pt[0]] if pt else len(tax["categories"]) - 1 for pt in ptopics],
           "topics_of": [[topics.index(t) for t in pt] for pt in ptopics], "threads": threads}
    json.dump(out, open(os.path.join(DATA, "starmap.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    for s in range(meta["shards"]):
        rel = {}
        for i in range(s * SHARD, min(n, (s + 1) * SHARD)):
            rel[i] = {"refs": sorted(refs_in[i]), "citedBy": sorted(cited_by[i]),
                      "coupling": [[j, int(shared[i, j]), round(v, 3)] for j, v in top_coup[i] if shared[i, j] >= 2],
                      "cocited": [[j, int(cocount[i, j]), round(v, 3)] for j, v in top_coc[i]],
                      "similar": [[j, round(v, 3)] for j, v in top_sem[i]],
                      "background": sorted(bg[e] for e in refs_ext[i] if e in bg),
                      "refsOutside": len(refs_ext[i])}
        json.dump(rel, open(os.path.join(DATA, f"starmap-rel-{s}.json"), "w"), separators=(",", ":"))
    json.dump(background, open(os.path.join(DATA, "starmap-background.json"), "w"), ensure_ascii=False, separators=(",", ":"))
    print(json.dumps(meta["coverage"]), f"threads: {sum(1 for t in threads if not t['unclustered'])}", flush=True)


if __name__ == "__main__":
    main()
