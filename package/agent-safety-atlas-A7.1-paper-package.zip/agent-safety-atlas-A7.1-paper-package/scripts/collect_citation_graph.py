#!/usr/bin/env python3
"""
Citation graph for the Research paths star map.

For every active Atlas work (included, not withdrawn) this fetches its Semantic Scholar record (paperId, external ids,
year, citation count, abstract) and its reference list (paperId, external ids, title, year). Lookup order: arXiv id,
then DOI (Graph API batch endpoint, 500 ids per request, no key), then an exact normalised-title match through
search/match (accepted only when a listed author surname also matches). Only paper identifiers and titles are sent.

Reference lists the batch endpoint leaves empty (it does so for many papers that have references) are fetched one
paper at a time from /paper/{id}/references. Citation lists are not fetched: the batch endpoint returns them unreliably (empty or capped at 9,999), so co-citation
is computed inside the Atlas corpus from the reference lists.

Raw responses are cached (research-paths/citation-graph/raw/*.json.gz) so a rerun only asks for what is missing.
Output: research-paths/citation-graph/works.jsonl, one line per Atlas work with lookup status.
Data source attribution: Semantic Scholar Academic Graph (https://www.semanticscholar.org/product/api).
  python collect_citation_graph.py [--limit N] [--skip-title] [--skip-refs]
"""
import argparse
import glob
import gzip
import hashlib
import json
import os
import re
import time
import unicodedata

import requests

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "research-paths", "citation-graph")
RAW = os.path.join(OUT, "raw")
API = "https://api.semanticscholar.org/graph/v1"
FIELDS = ("paperId,externalIds,title,year,publicationDate,citationCount,referenceCount,abstract,"
          "references.paperId,references.externalIds,references.title,references.year")
UA = {"User-Agent": "agent-safety-atlas-research/1.0"}


def norm(t):
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()
    return " ".join(re.sub(r"[^a-z0-9]+", " ", t).split())


def surname(n):
    parts = (n or "").replace(",", " ").split()
    return parts[-1].lower() if parts else ""


def active_works():
    atlas = json.load(open(os.path.join(HERE, "dist/data/atlas.json"), encoding="utf-8"))
    out = []
    for p in atlas["papers"]:
        if p["status"] != "included" or p["attributes"].get("withdrawal"):
            continue
        a = p["attributes"]
        doi = (a.get("doi") or (p.get("publication") or {}).get("doi") or "").lower() or None
        out.append({"id": p["id"], "arxiv": a.get("arxiv_id"), "doi": doi, "title": p.get("originalTitle") or p["title"],
                    "authors": p.get("originalAuthors") or p.get("authors") or []})
    return out


def cached_lookups():
    """Every earlier batch answer, keyed by the request id (ARXIV:x, DOI:y or a paperId). Batches are stored with their
    request ids; older files without them are matched back through the returned external ids. A request answered with
    null is remembered as not found only when its batch kept the ids."""
    out = {}
    for path in glob.glob(os.path.join(RAW, "batch_*.json.gz")):
        d = json.load(gzip.open(path, "rt", encoding="utf-8"))
        if isinstance(d, dict):
            out.update(zip(d["ids"], d["data"]))
            continue
        for rec in d:
            if not rec:
                continue
            ext = rec.get("externalIds") or {}
            if ext.get("ArXiv"):
                out["ARXIV:" + ext["ArXiv"]] = rec
            if ext.get("DOI"):
                out["DOI:" + ext["DOI"].lower()] = rec
            out[rec["paperId"]] = rec
    return out


def post(session, ids, key):
    path = os.path.join(RAW, f"batch_{key}.json.gz")
    if os.path.exists(path):
        d = json.load(gzip.open(path, "rt", encoding="utf-8"))
        return d["data"] if isinstance(d, dict) else d
    for attempt in range(8):
        try:
            r = session.post(f"{API}/paper/batch", params={"fields": FIELDS}, json={"ids": ids}, headers=UA, timeout=300)
        except requests.RequestException as e:
            print(f"  {key}: {type(e).__name__}, retrying", flush=True)
            time.sleep(20 * (attempt + 1))
            continue
        if r.status_code == 200:
            data = r.json()
            json.dump({"ids": ids, "data": data}, gzip.open(path, "wt", encoding="utf-8"))
            time.sleep(3)
            return data
        print(f"  {key}: HTTP {r.status_code}, waiting", flush=True)
        time.sleep(20 * (attempt + 1))
    return None


def fetch_refs(session, pid):
    """The batch endpoint returns an empty reference list for many papers that do have references; the per-paper
    endpoint returns them. Cached per paper."""
    path = os.path.join(RAW, f"refs_{pid}.json.gz")
    if os.path.exists(path):
        return json.load(gzip.open(path, "rt", encoding="utf-8"))
    out, offset = [], 0
    while offset is not None:
        for attempt in range(8):
            try:
                r = session.get(f"{API}/paper/{pid}/references", params={"fields": "paperId,externalIds,title,year", "limit": 1000,
                                "offset": offset}, headers=UA, timeout=120)
            except requests.RequestException:
                time.sleep(10 * (attempt + 1))
                continue
            if r.status_code == 429 or r.status_code >= 500:
                time.sleep(10 * (attempt + 1))
                continue
            break
        else:
            return None
        if r.status_code != 200:
            return None
        d = r.json()
        out += [x.get("citedPaper") or {} for x in d.get("data") or []]
        offset = d.get("next")
        time.sleep(1.0)
    json.dump(out, gzip.open(path, "wt", encoding="utf-8"))
    return out


def match_title(session, w):
    key = hashlib.sha1(norm(w["title"]).encode()).hexdigest()[:16]
    path = os.path.join(RAW, f"match_{key}.json.gz")
    if os.path.exists(path):
        hit = json.load(gzip.open(path, "rt", encoding="utf-8"))
    else:
        hit = None
        for attempt in range(6):
            try:
                r = session.get(f"{API}/paper/search/match", params={"query": w["title"], "fields": "paperId,title,authors"},
                                headers=UA, timeout=60)
            except requests.RequestException:
                time.sleep(10 * (attempt + 1))
                continue
            if r.status_code == 429:
                time.sleep(10 * (attempt + 1))
                continue
            hit = (r.json().get("data") or [None])[0] if r.status_code == 200 else {}
            break
        if hit is None:
            return None
        json.dump(hit, gzip.open(path, "wt", encoding="utf-8"))
        time.sleep(1.2)
    if not hit or norm(hit.get("title")) != norm(w["title"]):
        return None
    mine = {surname(a) for a in w["authors"] if surname(a)}
    theirs = {surname(a.get("name")) for a in hit.get("authors") or []}
    return hit["paperId"] if (not mine or mine & theirs) else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int)
    ap.add_argument("--skip-title", action="store_true", help="write works.jsonl from the arXiv/DOI lookups only (title matching continues later)")
    ap.add_argument("--skip-refs", action="store_true", help="do not fetch the reference lists the batch endpoint leaves empty")
    a = ap.parse_args()
    os.makedirs(RAW, exist_ok=True)
    works = active_works()[:a.limit] if a.limit else active_works()
    s = requests.Session()
    found = {}
    cache = cached_lookups()

    def run(kind, items):
        # answers already cached per request id are reused; only new ids are asked (so an update adding a few papers
        # sends a few ids, not the whole corpus again)
        for wid, rid in items:
            if rid in cache and cache[rid]:
                found[wid] = (kind, cache[rid])
        items = [x for x in items if x[1] not in cache]
        print(f"  {kind}: {len(items)} ids not cached yet", flush=True)
        for i in range(0, len(items), 500):
            chunk = items[i:i + 500]
            ids = [x[1] for x in chunk]
            key = f"{kind}_" + hashlib.sha1("|".join(ids).encode()).hexdigest()[:16]
            data = post(s, ids, key)
            if data is None:
                print(f"  {kind} batch {i // 500 + 1}: failed, left for the next run", flush=True)
                continue
            for (wid, _), rec in zip(chunk, data):
                if rec:
                    found[wid] = (kind, rec)
            print(f"  {kind}: {min(i + 500, len(items))}/{len(items)} asked, {len(found)} found so far", flush=True)

    run("arxiv", [(w["id"], "ARXIV:" + w["arxiv"]) for w in works if w["arxiv"]])
    run("doi", [(w["id"], "DOI:" + w["doi"]) for w in works if w["id"] not in found and w["doi"]])
    def fill_refs():
        todo = [rec for _, rec in found.values() if not rec.get("references") and (rec.get("referenceCount") or 0) > 0]
        print(f"reference lists to fetch one by one: {len(todo)}", flush=True)
        got = 0
        for n, rec in enumerate(todo, 1):
            refs = fetch_refs(s, rec["paperId"])
            if refs:
                rec["references"] = refs
                got += 1
            if n % 200 == 0:
                print(f"  references {n}/{len(todo)}: {got} filled", flush=True)
        print(f"  references filled for {got} of {len(todo)}", flush=True)

    if not a.skip_refs:
        fill_refs()
    rest = [w for w in works if w["id"] not in found and not a.skip_title]
    print(f"title match for {len(rest)} works", flush=True)
    by_pid = []
    for n, w in enumerate(rest, 1):
        pid = match_title(s, w)
        if pid:
            by_pid.append((w["id"], pid))
        if n % 100 == 0:
            print(f"  title match {n}/{len(rest)}: {len(by_pid)} matched", flush=True)
    run("title", by_pid)
    if by_pid and not a.skip_refs:
        fill_refs()

    with open(os.path.join(OUT, "works.jsonl"), "w", encoding="utf-8") as f:
        for w in works:
            kind, rec = found.get(w["id"], (None, None))
            row = {"id": w["id"], "lookup": kind, "status": "found" if rec else "not_found"}
            if rec:
                row["s2"] = {k: rec.get(k) for k in ("paperId", "externalIds", "title", "year", "publicationDate", "citationCount",
                                                    "referenceCount", "abstract")}
                row["references"] = [{"paperId": r.get("paperId"), "arxiv": (r.get("externalIds") or {}).get("ArXiv"),
                                      "doi": ((r.get("externalIds") or {}).get("DOI") or "").lower() or None,
                                      "title": r.get("title"), "year": r.get("year")} for r in rec.get("references") or []]
                row["referencesListed"] = rec.get("references") is not None
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    n_found = sum(1 for w in works if w["id"] in found)
    n_refs = sum(1 for w in works if w["id"] in found and found[w["id"]][1].get("references"))
    print(f"done: {n_found}/{len(works)} works found on Semantic Scholar; {n_refs} with a reference list", flush=True)


if __name__ == "__main__":
    main()
